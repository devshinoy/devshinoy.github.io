#fitem_id_availabilityconditionsjson .availability_grade input[type=text]{width:3em}.que.calculated
.answer{padding:0.3em;width:auto;display:inline}.que.calculated .answer input[type="text"]{width:30%}#page-question-type-calculated.dir-rtl input[name^="answer"],
#page-question-type-calculated.dir-rtl input[name^="unit"],
#page-question-type-calculated.dir-rtl input[name^="multiplier"],
#page-question-type-calculated.dir-rtl input[name^="calcmax"],
#page-question-type-calculated.dir-rtl input[name^="calcmin"],
#page-question-type-calculated.dir-rtl input[name^="number"],
#page-question-type-calculated.dir-rtl input[name^="tolerance"]{direction:ltr;text-align:left}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel label,
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answertolerance_] label[for^='id_tolerance_'],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_'],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-calculated div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answerdisplay_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answerdisplay_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-calculated div[id^=fitem_id_][id*=feedback_],
body#page-question-type-calculatedmulti div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.calculatedmulti .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.calculatedmulti .answer .specificfeedback
*{display:inline;background:#FFF3BF}.que.calculatedmulti .answer .specificfeedback
script{display:none}.que.calculatedmulti .answer div.r0,
.que.calculatedmulti .answer
div.r1{padding:0.3em}.que.calculatedsimple
.answer{padding:0.3em;width:auto;display:inline}.que.calculatedsimple .answer input[type="text"]{width:30%}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answertolerance_] label[for^='id_tolerance_'],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answerdisplay_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-calculatedsimple div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.ddimageortext
.qtext{margin-bottom:0.5em;display:block}.que.ddimageortext div.droparea img, form.mform fieldset#id_previewareaheader div.droparea
img{border:1px
solid #000;max-width:none}.que.ddimageortext .draghome, form.mform fieldset#id_previewareaheader
.draghome{vertical-align:top;margin:5px;visibility:hidden}.que.ddimageortext div.draghome, form.mform fieldset#id_previewareaheader
div.draghome{border:1px
solid black;cursor:move;background-color:#B0C4DE;display:inline-block;height:auto;width:auto;zoom:1}.que.ddimageortext .group1, form.mform fieldset#id_previewareaheader
.group1{background-color:#FFF}.que.ddimageortext .group2, form.mform fieldset#id_previewareaheader
.group2{background-color:#B0C4DE}.que.ddimageortext .group3, form.mform fieldset#id_previewareaheader
.group3{background-color:#DCDCDC}.que.ddimageortext .group4, form.mform fieldset#id_previewareaheader
.group4{background-color:#D8BFD8}.que.ddimageortext .group5, form.mform fieldset#id_previewareaheader
.group5{background-color:#87CEFA}.que.ddimageortext .group6, form.mform fieldset#id_previewareaheader
.group6{background-color:#DAA520}.que.ddimageortext .group7, form.mform fieldset#id_previewareaheader
.group7{background-color:#FFD700}.que.ddimageortext .group8, form.mform fieldset#id_previewareaheader
.group8{background-color:#F0E68C}.que.ddimageortext .drag, form.mform fieldset#id_previewareaheader
.drag{border:1px
solid black;cursor:move;z-index:2}.que.ddimageortext .dragitems.readonly
.drag{cursor:auto}.que.ddimageortext div.ddarea, form.mform fieldset#id_previewareaheader
div.ddarea{text-align:center}.que.ddimageortext .dropbackground, form.mform fieldset#id_previewareaheader
.dropbackground{margin:0
auto}.que.ddimageortext
.dropzone{border:1px
solid black;position:absolute;z-index:1}.que.ddimageortext .dropzone:focus,
.que.ddimageortext .dropzone.yui3-dd-drop-over.yui3-dd-drop-active-valid{border-color:#0a0;box-shadow:0 0 5px 5px rgba(255, 255, 150, 1)}.que.ddimageortext div.dragitems div.draghome, .que.ddimageortext div.dragitems div.drag,
form.mform fieldset#id_previewareaheader div.draghome, form.mform fieldset#id_previewareaheader
div.drag{font:13px/1.231 arial,helvetica,clean,sans-serif}form.mform fieldset#id_previewareaheader div.drag.yui3-dd-dragging,
.que.ddimageortext div.drag.yui3-dd-dragging{z-index:3;box-shadow:3px 3px 4px #000}body#page-question-type-ddimageortext div[id^=fgroup_id_][id*=drags_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-ddimageortext div[id^=fgroup_id_][id*=drags_] .fgrouplabel
label{font-weight:bold}body#page-question-type-ddimageortext div[id^=fitem_id_][id*=dragitem_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-ddimageortext div[id^=fitem_id_][id*=draglabel_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.ddmarker
.qtext{margin-bottom:0.5em;display:block}.que.ddmarker div.droparea img, form.mform fieldset#id_previewareaheader div.droparea
img{border:1px
solid #000;max-width:none}.que.ddmarker .draghome img, .que.ddmarker .draghome
span{visibility:hidden}.que.ddmarker .dragitems
.dragitem{cursor:move;position:absolute;z-index:2}.que.ddmarker .dragitems
.draghome{margin:10px}.que.ddmarker
.dragitems{margin-top:10px}.que.ddmarker .dragitems.readonly
.dragitem{cursor:auto}.que.ddmarker div.ddarea, form.mform fieldset#id_previewareaheader
div.ddarea{text-align:center}form.mform fieldset#id_previewareaheader div.ddarea
.markertexts{min-height:80px}.que.ddmarker .dropbackground, form.mform fieldset#id_previewareaheader
.dropbackground{margin:0
auto}.que.ddmarker div.dragitems div.draghome, .que.ddmarker div.dragitems div.dragitem,
form.mform fieldset#id_previewareaheader div.draghome, form.mform fieldset#id_previewareaheader
div.drag{font:13px/1.231 arial,helvetica,clean,sans-serif}.que.ddmarker div.dragitems span.markertext,
.que.ddmarker div.markertexts span.markertext,
form.mform fieldset#id_previewareaheader div.markertexts
span.markertext{margin:0
5px;z-index:3;background-color:white;border:2px
solid black;padding:5px;display:inline-block;zoom:1;border-radius:10px}.que.ddmarker div.markertexts
span.markertext{z-index:2;background-color:yellow;border-style:solid;border-width:2px;border-color:khaki}.que.ddmarker
span.wrongpart{background-color:yellow;border-style:solid;border-width:2px;border-color:khaki;padding:5px;border-radius:10px;filter:alpha(opacity=60);opacity:0.6;margin:5px;display:inline-block}.que.ddmarker div.dragitems
img.target{position:absolute;left:-7px;top:-7px}.que.ddmarker div.dragitems div.draghome
img.target{display:none}.que.ddmarker .dragitem.yui3-dd-dragging
span.markertext{z-index:3;box-shadow:3px 3px 4px #000}#page-question-type-ddmarker .ddarea
.grid{position:absolute;background:url(/sunguru/theme/image.php/archaius/qtype_ddmarker/1531975376/grid) repeat scroll 0 0}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hint_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hint_] .fitemtitle{font-weight:bold}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hintoptions_],
body#page-question-type-ddmarker div[id^=fitem_id_][id*=hintshownumcorrect_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hintclearwrong_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}body#page-question-type-ddmarker
#fitem_id_penalty{margin-bottom:2em}.que.ddwtos
.qtext{margin-bottom:0.5em;display:block}.que.ddwtos
.draghome{margin-bottom:1em}.que.ddwtos
.answertext{margin-bottom:0.5em}.que.ddwtos
.drop{display:inline-block;text-align:center;border:1px
solid #000;margin-bottom:2px}.que.ddwtos .draghome, .que.ddwtos
.drag{display:inline-block;text-align:center;background:transparent;border:0}.que.ddwtos .draghome, .que.ddwtos
.drag.unplaced{border:1px
solid #000}.que.ddwtos
.draghome{visibility:hidden}.que.ddwtos
.drag{z-index:2}.que.ddwtos .drag.yui3-dd-dragging{z-index:3;box-shadow:3px 3px 4px #000}.que.ddwtos .drop:focus,
.que.ddwtos .drop.yui3-dd-drop-over.yui3-dd-drop-active-valid{border-color:#0a0;box-shadow:0 0 5px 5px rgba(255, 255, 150, 1)}.que.ddwtos .notreadonly
.drag{cursor:move}.que.ddwtos .readonly
.drag{cursor:default}.que.ddwtos
span.incorrect{background-color:#faa}.que.ddwtos
span.correct{background-color:#afa}.que.ddwtos
.group1{background-color:#FFF}.que.ddwtos
.group2{background-color:#DCDCDC}.que.ddwtos
.group3{background-color:#B0C4DE}.que.ddwtos
.group4{background-color:#D8BFD8}.que.ddwtos
.group5{background-color:#87CEFA}.que.ddwtos
.group6{background-color:#DAA520}.que.ddwtos
.group7{background-color:#FFD700}.que.ddwtos
.group8{background-color:#F0E68C}.que.ddwtos sub,
.que.ddwtos
sup{font-size:80%;position:relative;vertical-align:baseline}.que.ddwtos
sup{top:-0.4em}.que.ddwtos
sub{bottom:-0.2em}.que.essay
textarea.qtype_essay_response{width:100%}.que.essay
textarea.qtype_essay_response.qtype_essay_plain{white-space:pre-wrap;font:inherit}.que.essay
textarea.qtype_essay_response.qtype_essay_monospaced{white-space:pre;font-family:Andale Mono,Monaco,Courier New,DejaVu Sans Mono,monospace}.que.essay
.qtype_essay_response{min-height:3em}.que.essay
.qtype_essay_response.readonly{background-color:white}.que.essay div.qtype_essay_response
textarea{width:100%}.que.gapselect
.qtext{line-height:2em;margin-top:1px;margin-bottom:0.5em;display:block}.que.gapselect
.answercontainer{line-height:2em;margin-bottom:1em;display:block}.que.gapselect
.answertext{padding-bottom:0.5em}.que.sddl
.control{padding:0.2em}body#page-question-type-match div[id^=fitem_id_][id*=subquestions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-match div[id^=fitem_id_][id*=subquestions_] .fitemtitle{font-weight:bold}body#page-question-type-match div[id^=fitem_id_][id*=subanswers_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.multianswer
.feedbackspan{display:block;max-width:70%;background:#fff3bf;padding:0.5em;margin-top:1em;box-shadow:0.5em 0.5em 1em #000}body.ie6 .que.multianswer .feedbackspan,
body.ie7 .que.multianswer .feedbackspan,
body.ie8 .que.multianswer .feedbackspan,
body.ie9 .que.multianswer
.feedbackspan{width:70%}.que.multianswer .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.multianswer .answer .specificfeedback
*{display:inline;background:#FFF3BF}.que.multianswer .answer .specificfeedback
script{display:none}.que.multianswer .answer div.r0,
.que.multianswer .answer
div.r1{padding:0.3em}.que.multianswer
table.answer{margin-bottom:0;width:100%}.que.multichoice .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.multichoice .answer div.r0,
.que.multichoice .answer
div.r1{padding:0.3em 0 0.3em 25px;text-indent:-25px}.que.multichoice .answer div.r0 label,
.que.multichoice .answer div.r1 label,
.que.multichoice .answer div.r0 div.specificfeedback,
.que.multichoice .answer div.r1
div.specificfeedback{text-indent:0}.que.multichoice .answer div.r0 input,
.que.multichoice .answer div.r1
input{margin:0
5px;padding:0;width:15px}.dir-rtl .que.multichoice .answer div.r0,
.dir-rtl .que.multichoice .answer
div.r1{padding:0.3em 25px 0.3em 0}body#page-question-type-multichoice div[id^=fitem_id_][id*=answer_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-multichoice div[id^=fitem_id_][id*=answer_] .fitemtitle{font-weight:bold}body#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{margin-left:0px;margin-right:0px;padding-left:6px;padding-right:0px}body.dir-rtl#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{margin-left:0px;margin-right:0px;padding-left:0px;padding-right:6px}body#page-question-type-multichoice div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-multichoice div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.numerical
.answer{padding:0.3em;width:auto;display:inline}.que.numerical .answer input[type="text"]{width:30%}#page-question-type-numerical.dir-rtl input[name="unitpenalty"],
#page-question-type-numerical.dir-rtl input[name^="answer"],
#page-question-type-numerical.dir-rtl input[name^="tolerance"],
#page-question-type-numerical.dir-rtl input[name^="multiplier"],
#page-question-type-numerical.dir-rtl input[name^="unit"]{direction:ltr;text-align:left}body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body.path-question-type div#fgroup_id_penaltygrp label[for^=id_unitpenalty],
body.path-question-type div[id^=fgroup_id_units_] label[for^='id_unit_'],
body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-numerical div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-numerical div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.shortanswer
.answer{padding:0.3em;width:auto;display:inline}.que.shortanswer .answer
input{width:80%}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-shortanswer div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-shortanswer div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.truefalse .answer div.r0,
.que.truefalse .answer
div.r1{padding:0.3em}.path-mod-assign div.gradingnavigation
div{float:left;margin-left:2em}.path-mod-assign div.submissionstatustable,
.path-mod-assign div.submissionfull,
.path-mod-assign div.submissionlinks,
.path-mod-assign div.usersummary,
.path-mod-assign div.feedback,
.path-mod-assign
div.gradingsummary{margin-bottom:5em}.path-mod-assign div.submissionstatus .generaltable,
.path-mod-assign div.submissionlinks .generaltable,
.path-mod-assign div.feedback .generaltable,
.path-mod-assign div.submissionsummarytable .generaltable,
.path-mod-assign div.attempthistory table,
.path-mod-assign div.gradingsummary
.generaltable{width:100%}.path-mod-assign table.generaltable table
td{border:0px
none}.path-mod-assign .gradingsummarytable,
.path-mod-assign .feedbacktable,
.path-mod-assign .lockedsubmission,
.path-mod-assign
.submissionsummarytable{margin-top:1em}.path-mod-assign div.submissionsummarytable table tbody tr
td.c0{width:30%}.path-mod-assign
.submittedlate{color:red;font-weight:900}.path-mod-assign.jsenabled .gradingoptionsform
.fsubmit{display:none}.path-mod-assign.jsenabled .gradingtable .c1
select{display:none}.path-mod-assign .quickgradingform .mform
fieldset{margin:0px;padding:0px}.path-mod-assign .gradingbatchoperationsform .mform
fieldset{margin:0px;padding:0px}.path-mod-assign td.submissionstatus,
.path-mod-assign div.submissionstatus,
.path-mod-assign a:link.submissionstatus{color:black;background-color:#efefef}.path-mod-assign td.submissionstatusdraft,
.path-mod-assign div.submissionstatusdraft,
.path-mod-assign a:link.submissionstatusdraft{color:black;background-color:#efefcf}.path-mod-assign td.submissionstatussubmitted,
.path-mod-assign div.submissionstatussubmitted,
.path-mod-assign a:link.submissionstatussubmitted{color:black;background-color:#cfefcf}.path-mod-assign td.submissionlocked,
.path-mod-assign
div.submissionlocked{color:black;background-color:#efefcf}.path-mod-assign td.submissionreopened,
.path-mod-assign
div.submissionreopened{color:black;background-color:#efefef}.path-mod-assign td.submissiongraded,
.path-mod-assign
div.submissiongraded{color:black;background-color:#cfefcf}.path-mod-assign td.submissionnotgraded,
.path-mod-assign
div.submissionnotgraded{color:black;background-color:#efefef}.path-mod-assign td.latesubmission,
.path-mod-assign a:link.latesubmission,
.path-mod-assign
div.latesubmission{color:black;background-color:#efcfcf}.path-mod-assign td.earlysubmission,
.path-mod-assign
div.earlysubmission{color:black;background-color:#cfefcf}.path-mod-assign .gradingtable
.c0{display:none}.path-mod-assign.jsenabled .gradingtable
.c0{display:table-cell}.path-mod-assign
.gradingbatchoperationsform{display:none}.path-mod-assign.jsenabled
.gradingbatchoperationsform{display:block}.path-mod-assign .gradingtable tr.selectedrow
td{background-color:#fec}.path-mod-assign .gradingtable tr.unselectedrow
td{background-color:white}.path-mod-assign .gradingtable .c0
div.selectall{margin-left:7px}.path-mod-assign .gradingtable .yui3-menu
ul{margin:0px}.path-mod-assign .gradingtable .yui3-menu-label{padding-left:0px;line-height:12px}.path-mod-assign .gradingtable .yui3-menu-label
img{padding:0
3px}.path-mod-assign .gradingtable .yui3-menu
li{list-style-type:none}.path-mod-assign.jsenabled .gradingtable .yui3-loading{display:none}.path-mod-assign .gradingtable .yui3-menu .yui3-menu-content{border:0px;padding-top:0}.path-mod-assign div.gradingtable tr
.quickgrademodified{background-color:#FC9}.path-mod-assign
td.submissioneditable{color:red}.path-mod-assign
.expandsummaryicon{cursor:pointer;display:none}.path-mod-assign.jsenabled
.expandsummaryicon{display:inline}.path-mod-assign
.hidefull{display:none}.path-mod-assign .quickgradingform form .commentscontainer input,
.path-mod-assign .quickgradingform form .commentscontainer
textarea{display:none}.path-mod-assign.jsenabled .quickgradingform form .commentscontainer input,
.path-mod-assign.jsenabled .quickgradingform form .commentscontainer
textarea{display:inline}.path-mod-assign
.previousfeedbackwarning{font-size:140%;font-weight:bold;text-align:center;color:#500}.path-mod-assign
.submissionhistory{background-color:#b0b0b0}.path-mod-assign .submissionhistory
.cell.historytitle{background-color:#808080}.path-mod-assign .submissionhistory
.cell{background-color:#d0d0d0}.path-mod-assign.jsenabled .mod-assign-history-link{display:block;cursor:pointer;margin-bottom:7px}.path-mod-assign.jsenabled .mod-assign-history-link
h4{display:inline}.path-mod-assign.jsenabled .attempthistory
h4{margin-bottom:7px;text-align:left}.path-mod-assign.jsenabled.dir_rtl .attempthistory
h4{text-align:right}.path-mod-assign.dir-rtl.jsenabled .mod-assign-history-link
h4{text-align:right}.path-mod-assign.jsenabled .mod-assign-history-link-open{padding:0
5px 0 20px;background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/expanded) 2px center no-repeat}.path-mod-assign.jsenabled .mod-assign-history-link-closed{padding:0
5px 0 20px;background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed) 2px center no-repeat}.path-mod-assign.dir-rtl.jsenabled .mod-assign-history-link-closed{padding:0
20px 0 5px;background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_rtl) 2px center no-repeat}.path-mod-assign
.submithelp{padding:1em}.path-mod-assign
.feedbacktitle{font-weight:bold}.path-mod-assign .submitconfirm,
.path-mod-assign .submissionlinks,
.path-mod-assign
.submissionaction{text-align:center}.path-mod-assign .submissionsummarytable .c0,
.path-mod-assign .mod-assign-history-panel
.c0{width:150px}.path-mod-assign .gradingtable .moodle-actionmenu{white-space:nowrap}.path-mod-assign .gradingtable .moodle-actionmenu[data-enhanced].show .menu
a{padding-left:12px;padding-right:12px}.path-mod-assign .gradingtable .menu-action
img{display:none}.path-mod-assign .editsubmissionform input[name="submissionstatement"]{vertical-align:top}.path-mod-assign .editsubmissionform label[for="id_submissionstatement"]{display:inline-block}.path-mod-assign.layout-option-nonavbar{padding-top:0px}.path-mod-assign [data-region="user-selector"] select{margin-bottom:0px}.path-mod-assign [data-region="user-selector"] .alignment{float:right;width:320px;text-align:center;margin-top:7px}.path-mod-assign [data-region="user-selector"] [data-action="previous-user"],
.path-mod-assign [data-region="user-selector"] [data-action="next-user"]{font-size:26px}.path-mod-assign [data-region="user-selector"] [data-action="next-user"]{margin-left:-10px}.dir-rtl.path-mod-assign [data-region="user-selector"] [data-action="next-user"]{margin-right:-10px}.dir-rtl.path-mod-assign [data-region="user-selector"] .alignment{float:left}.path-mod-assign [data-region="user-selector"] .alignment
input{margin-bottom:5px}.path-mod-assign [data-region="user-selector"] .alignment .form-autocomplete-downarrow{top:0}.path-mod-assign [data-region="user-selector"] .form-autocomplete-selection{display:none}.path-mod-assign [data-region="user-selector"] .form-autocomplete-suggestions{text-align:left}.path-mod-assign [data-region="user-selector"] .form-autocomplete-suggestions{margin-left:48px}.dir-rtl.path-mod-assign [data-region="user-selector"] .form-autocomplete-suggestions{margin-right:64px}.path-mod-assign [data-region="user-filters"]{font-size:small}.path-mod-assign [data-region="configure-filters"]{display:none;text-align:left;width:auto;background-color:#fff;background-clip:padding-box;box-shadow:0 5px 10px rgba(0, 0, 0, 0.2);border-radius:6px;position:absolute;margin-top:28px;margin-left:-140px;padding:10px
0;z-index:1}.path-mod-assign [data-region="configure-filters"]::before,
.path-mod-assign [data-region="configure-filters"]::after{position:absolute;left:auto;display:inline-block;content:'';border-style:solid;border-color:transparent;border-top:none}.path-mod-assign [data-region="configure-filters"]::before{top:-7px;right:12px;border-width:7px;border-bottom-color:rgba(0, 0, 0, 0.2)}.path-mod-assign [data-region="configure-filters"]::after{top:-6px;right:13px;border-width:6px;border-bottom-color:#fff}.path-mod-assign.dir-rtl [data-region="configure-filters"]{text-align:right;margin-left:0;margin-right:-140px}.path-mod-assign [data-region="configure-filters"] label{padding:3px
20px}.path-mod-assign .alignment [data-region="configure-filters"] input{margin-bottom:0}.path-mod-assign [data-region="grading-navigation-panel"]{position:absolute;top:0;left:0;width:100%;height:6em;margin:0;border-bottom:1px solid #ddd}.path-mod-assign [data-region="grading-navigation"]{padding:1em}.path-mod-assign [data-region="user-info"]{height:60px}.path-mod-assign [data-region="user-info"] a{text-decoration:none}.path-mod-assign [data-region="user-info"] .img-rounded{display:block;float:left;margin-top:-3px;margin-right:10px}.dir-rtl.path-mod-assign [data-region="user-info"] .img-rounded{float:right;margin-left:10px}.path-mod-assign [data-region="user-info"] em{display:block;font-style:normal}.path-mod-assign [data-region="grading-actions-form"] label{display:inline-block}.path-mod-assign.pagelayout-embedded{overflow:hidden}.path-mod-assign [data-region="review-panel"]{position:absolute;top:85px;bottom:60px;left:0;width:70%;box-sizing:border-box}.path-mod-assign [data-region="review-panel"] .pageheader{border-right:1px solid #ddd}.path-mod-assign [data-region="review-panel"] .drawingregion{left:0;right:0;border-color:#ddd}.path-mod-assign [data-region="grade-panel"].fullwidth{position:absolute;top:7em;left:0;right:0;width:99%;overflow:auto;bottom:7em}.path-mod-assign [data-region="grade-panel"].fullwidth [data-region="grade"]{max-width:800px;margin-left:auto;margin-right:auto}.path-mod-assign [data-region="grade-panel"]{position:absolute;top:85px;bottom:60px;right:0;width:30%;overflow:auto;box-sizing:border-box;background-color:#f5f5f5;padding:15px;padding-top:0px}.path-mod-assign [data-region="grade-panel"] h3{font-size:18px;font-weight:500}.path-mod-assign [data-region="grade-panel"] div.submissionstatustable{margin-bottom:2em}.path-mod-assign [data-region="grade-panel"] .submissionsummarytable{margin-left:5px;margin-right:5px}.path-mod-assign [data-region="grade-panel"] .submissionsummarytable table.generaltable
td{padding:8px
0;background-color:transparent}.path-mod-assign [data-region="grade-panel"] .submissionsummarytable .generaltable tbody > tr:nth-child(2n+1) > td,
.path-mod-assign [data-region="grade-panel"] .submissionsummarytable .generaltable tbody tr:hover>td{background-color:transparent}.path-mod-assign [data-region="grade-panel"] div.submissionsummarytable table tbody tr
td.c0{width:auto}.path-mod-assign [data-region="grade-panel"] div.submissionsummarytable table tbody tr.lastrow td.c0,
.path-mod-assign [data-region="grade-panel"] div.submissionsummarytable table tbody tr.lastrow
td.c1{border-bottom:1px solid #ddd}.path-mod-assign [data-region="grade-panel"] td.submissionnotgraded,
.path-mod-assign [data-region="grade-panel"] div.submissionnotgraded{color:red;background-color:transparent}.path-mod-assign [data-region="grade-panel"] #id_gradeheader{display:table-cell;min-width:0}.path-mod-assign [data-region="grade-panel"] #id_gradeheader>legend{visibility:hidden;height:0;margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .comment-area textarea[cols]{width:100%;box-sizing:border-box}.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_ftext,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_f,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_feditor,
.path-mod-assign [data-region="grade-panel"] .mform
.fitem.fitem_ffilemanager{background-color:#fff;border:1px
solid #ddd;margin-bottom:20px}.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_ftext .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_f .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_feditor .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_ffilemanager
.fitemtitle{padding-left:5px;padding-right:5px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_ftext .felement,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_f .felement,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_feditor .felement,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_ffilemanager
.felement{padding:6px
10px 10px;box-sizing:border-box}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_ftext .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_f .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_feditor .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_ffilemanager
.fitemtitle{border-bottom:1px solid #ddd;box-shadow:0 1px 1px rgba(0,0,0,0.05);padding:6px
10px 3px;box-sizing:border-box}.path-mod-assign #page-content [data-region="grade-panel"] [data-region="popout-button"] img{margin-left:2px;margin-right:2px;margin-top:-2px}.path-mod-assign #page-content [data-region="grade-panel"] .popout [data-region="popout-button"] img{margin-left:-6px;margin-right:-6px;margin-top:4px}.path-mod-assign [data-region="grade-panel"] .fitem .fstaticlabel,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem .fitemtitle
label{font-weight:500}.path-mod-assign [data-region="grade-panel"] .mform
#fitem_id_grade.fitem{padding-top:5px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #fitem_id_grade.fitem
.fitemtitle{display:inline-block;width:auto;border-bottom:none;box-shadow:none}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #fitem_id_grade.fitem
.felement{width:auto;float:right}.path-mod-assign #page-content .mform:not(.unresponsive) #fitem_id_grade.fitem .felement
input{width:80px;margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric{padding-bottom:0;max-width:none}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion
.description{font-weight:500;min-width:150px}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion
.levels{background-color:#fff}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion,
.path-mod-assign [data-region="grade-panel"] .gradingform_rubric
.criterion.even{background-color:transparent}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric.evaluate .criterion .levels .level:hover{background-color:#dff0d8}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion .levels
.level.checked{background-color:#dff0d8;border:none;border-left:1px solid #ddd}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion .levels .level
.score{color:#468847;font-weight:500;font-style:normal;margin-top:20px}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion .remark
textarea{margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .gradingform_guide{margin-bottom:10px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .descriptionreadonly,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide .remark,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.score{display:block}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.descriptionreadonly{padding-top:10px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.criteriondescription{margin-top:5px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.criteriondescriptionmarkers{width:auto;margin-top:5px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.markingguideremark{margin-bottom:10px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .remark
.commentchooser{float:right;margin-top:2px;margin-left:0}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.score{float:left;padding-bottom:8px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .score input,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide .score
div{display:inline-block}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .criterion,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.criterion.even{background-color:transparent;border-width:0 0 1px 0;padding:8px
0}.path-mod-assign [data-region="grade-panel"] .showmarkerdesc,
.path-mod-assign [data-region="grade-panel"] .showstudentdesc{background-color:#f5f5f5;padding:10px}.path-mod-assign [data-region="grade-panel"] .fitem.fitem_ffilemanager{margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .fitem.popout{position:fixed;left:20%;right:20%;top:20%;bottom:20%;z-index:1000;border:1px
solid rgba(0, 0, 0, 0.3);border-radius:6px;box-shadow:0 3px 7px rgba(0, 0, 0, 0.3)}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout
.fitemtitle{text-align:center;padding-left:15px;padding-right:15px;height:45px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout .fitemtitle
label{font-size:16px;line-height:30px}.path-mod-assign #page-content [data-region="grade-panel"] [data-region="popout-button"]{float:right}.dir-rtl.path-mod-assign #page-content [data-region="grade-panel"] [data-region="popout-button"]{float:left}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.popout .fitemtitle [data-region="popout-button"] img{margin-top:-10px;margin-right:-7px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout
.felement{padding:10px
15px 15px;height:calc(100% - 54px);overflow:auto}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout .felement
.gradingform_rubric{overflow:visible}.path-mod-assign [data-region="grade-panel"] #id_attemptsettings>legend{font-size:18px;font-weight:500;line-height:40px;border-bottom:0;margin-bottom:10px}.path-mod-assign [data-region="grade-panel"] #id_attemptsettings
.fcontainer{display:table;width:100%;padding-left:5px;padding-right:5px;margin-bottom:10px;box-sizing:border-box}.path-mod-assign [data-region="grade-panel"] .mform #id_attemptsettings
.fitem{display:table-row}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem
.felement{display:table-cell;float:none;border-top:1px solid #ddd;padding:8px
0}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem:last-of-type .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem:last-of-type
.felement{border-bottom:1px solid #ddd}.path-mod-assign [data-region="grade-panel"] #id_attemptsettings .fitem .fstaticlabel,
.path-mod-assign [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem .fitemtitle
label{font-weight:400}.path-mod-assign [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem .felement
select{margin-bottom:0}.path-mod-assign [data-region="grade-panel"] [data-region="attempt-chooser"]{margin-bottom:10px;vertical-align:text-bottom}.path-mod-assign [data-region="grade-actions-panel"]{border-top:1px solid #ddd;position:absolute;bottom:0;left:0;width:100%;height:60px}.path-mod-assign [data-region="grade-actions"]{padding:1em;text-align:center}.path-mod-assign [data-region="submissions-list"]{text-align:inherit}.path-mod-assign [data-region="submissions-list"] label.radio
input{margin-top:4px;min-width:inherit}.path-mod-assign [data-region="overlay"]{display:none;z-index:100;position:absolute;top:0em;left:0;width:100%;overflow:auto;bottom:0em;background-color:#ddd;opacity:0.4;padding-top:4em;text-align:center}@media (max-width: 767px){.path-mod-assign.pagelayout-embedded{overflow:auto}.path-mod-assign [data-region="assignment-info"]{border-bottom:1px solid #ddd;padding-bottom:5px}.path-mod-assign .page-context-header .page-header-headings{margin-top:13px}.path-mod-assign [data-region="grading-navigation-panel"],
.path-mod-assign [data-region="review-panel"],
.path-mod-assign [data-region="grade-panel"],
.path-mod-assign [data-region="grade-actions-panel"]{position:inherit;width:100%;top:0;left:0;overflow:auto;height:auto;margin-bottom:1em}.path-mod-assign [data-region="grading-navigation"]{padding:0;text-align:center}.path-mod-assign [data-region="grade-panel"]{margin-bottom:2em}.path-mod-assign [data-region="grade-panel"] [data-region="popout-button"]{display:none}.path-mod-assign [data-region="review-panel"] .pageheader{border-right:none}.path-mod-assign.pagelayout-popup{overflow:inherit}.path-mod-assign [data-region="grading-navigation"] [data-region="user-info"]{text-align:left;width:auto;display:inline-block;margin:0
auto}.path-mod-assign [data-region="user-selector"] .alignment{float:none;margin:0
auto 10px}}.path-mod-assign [data-region="grade-panel"] .mform .fitem
.fitemtitle{display:block;margin-top:4px;margin-bottom:4px;text-align:left;width:100%}.path-mod-assign [data-region="grade-panel"] .mform .fitem
.felement{margin-left:0;width:100%;float:left;padding-left:0;padding-right:0}.path-mod-assign [data-region="grade-panel"] .mform .fitem .fstatic:empty{display:none}.path-mod-assign [data-region="grade-panel"] .mform .fitem .fcheckbox > span,
.path-mod-assign [data-region="grade-panel"] .mform .fitem .fradio > span,
.path-mod-assign [data-region="grade-panel"] .mform .fitem .fgroup>span{margin-top:4px}.path-mod-assign [data-region="grade-panel"] .mform .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:8px}.path-mod-assign [data-region="grade-panel"] .mform .femptylabel
.felement{display:inline-block;margin-top:4px;padding-top:5px;width:auto}.path-mod-assign [data-region="grade-panel"] .mform .fitem_fcheckbox .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem_fcheckbox
.felement{display:inline-block;width:auto}.path-mod-assign [data-region="grade-panel"] .mform .fitem_fcheckbox
.felement{padding:6px}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .femptylabel
.fitemtitle{margin-right:0px;margin-left:8px}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .fitem
.fitemtitle{text-align:right}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .fitem
.felement{margin-right:0;float:right;padding-right:0;padding-left:0}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .fitem_checkbox
.felement{float:right}.path-mod-assign #page,
.path-mod-assign #page-content{position:inherit}.path-mod-attendance
.attbtn{border:1px
solid #AAA;margin-left:2px;margin-right:2px;padding:5px;-moz-border-radius:5px;-webkit-border-radius:5px;-opera-border-radius:5px;-khtml-border-radius:5px;border-radius:5px}.path-mod-attendance
.attcurbtn{margin-left:2px;margin-right:2px;padding:5px}.path-mod-attendance
.attfiltercontrols{margin-bottom:10px !important;margin-right:auto;margin-left:auto}.path-mod-attendance .attfiltercontrols
#currentdate{display:inline}.path-mod-attendance
.attwidth{width:90%;margin:auto}.path-mod-attendance .userwithoutenrol,
.path-mod-attendance .userwithoutenrol
a{color:gray}.path-mod-attendance .userwithoutdata,
.path-mod-attendance .userwithoutdata
a{color:red}.path-mod-attendance .takelist
td{vertical-align:middle}.path-mod-attendance .takelist
.userpicture{margin:0
3px;vertical-align:middle}.path-mod-attendance .takegrid
input{margin:0
3px 0 6px}.path-mod-attendance .takegrid
.fullname{font-size:0.8em}.path-mod-attendance
table.controls{width:100%;text-align:center}.path-mod-attendance table.controls
tr{vertical-align:top}.path-mod-attendance table.controls td.right,
.path-mod-attendance table.controls
td.left{padding:4px}.path-mod-attendance table.controls
.right{text-align:right}.path-mod-attendance .filtercontrols
td{padding:6px}.path-mod-attendance
.takecontrols{width:800px;margin:0
auto 20px auto}.path-mod-attendance .takecontrols
table{margin:0
auto}.path-mod-attendance .takecontrols
.c0{width:500px;text-align:left}.path-mod-attendance .takecontrols
.c1{text-align:right}.path-mod-attendance .inline,
.path-mod-attendance .inline form,
.path-mod-attendance .inline
div{display:inline}.path-mod-attendance
table.userinfobox{border:1px
solid #EEE;padding:0}.path-mod-attendance table.userinfobox
td.left{background-color:#EEE;padding:30px
10px}.path-mod-attendance table.attlist
td.c0{text-align:right}#page-mod-attendance-preferences
.generalbox{text-align:center}.path-mod-attendance .attsessions_manage_table .action-icon
img.smallicon{margin-left:5px}#page-mod-attendance-sessions input[type="checkbox"]{margin-right:2px}.path-mod-attendance
.setallstatuses{text-align:right}.path-mod-attendance
.remarkholder{position:relative}.path-mod-attendance .remarkholder
.remarkcontent{display:none;position:absolute;border:1px
solid #ccc;border-radius:3px;box-shadow:3px 3px 5px #ccc;background-color:white;left:20px;top:0;padding:5px;width:150px;z-index:5000}.path-mod-attendance .remarkholder:hover
.remarkcontent{display:inline-block}.path-mod-attendance .attendancestatus-P{color:green}.path-mod-attendance .attendancestatus-E{color:#00AEE3}.path-mod-attendance .attendancestatus-L{color:#F7931E}.path-mod-attendance .attendancestatus-A{color:red}.path-mod-attendance .summaryreport
.c5{background-color:#EAEAEA}.path-mod-attendance .summaryreport
.c6{background-color:#EAEAEA}.path-mod-attendance .summaryreport
.c7{background-color:#EAEAEA}.path-mod-book .navtop img.icon,
.path-mod-book .navbottom
img.icon{margin-right:4px;margin-left:4px;border:0;padding:0}.path-mod-book .navbottom,
.path-mod-book
.navtop{text-align:right}.dir-rtl.path-mod-book .navbottom,
.dir-rtl.path-mod-book
.navtop{text-align:left}.path-mod-book
.navtop{margin-bottom:0.5em}.path-mod-book
.navbottom{margin-top:0.5em}.path-mod-book .block_book_toc
ul{margin:0
0 0 5px;padding-left:0;padding-right:0}.dir-rtl.path-mod-book .block_book_toc
ul{margin:0
5px 0 0}.path-mod-book .block_book_toc
li{clear:both;list-style:none;margin-top: .5em}.path-mod-book .block_book_toc li
li{list-style:none}.path-mod-book .block_book_toc .action-list{float:right}.dir-rtl.path-mod-book .block_book_toc .action-list{float:left}.path-mod-book .block_book_toc .action-list
img.smallicon{margin:0
3px}.path-mod-book .book_toc_none ul ul,
.dir-rtl.path-mod-book .book_toc_none ul
ul{margin-left:0;margin-right:0}.path-mod-book .book_toc_bullets ul
ul{margin-left:20px}.dir-rtl.path-mod-book .book_toc_bullets ul
ul{margin-left:0;margin-right:20px}.path-mod-book .book_toc_bullets li
li{list-style:circle}.path-mod-book .book_toc_bullets li li:before{display:none}.path-mod-book .book_toc_indented
ul{margin-left:5px}.dir-rtl.path-mod-book .book_toc_indented
ul{margin-left:0;margin-right:5px}.path-mod-book .book_toc_indented ul
ul{margin-left:15px}.dir-rtl.path-mod-book .book_toc_indented ul
ul{margin-left:0;margin-right:15px}.path-mod-book .book_toc_indented li
li{list-style:none}.navtop.navtext .chaptername,
.navbottom.navtext
.chaptername{font-weight:bolder}.navtop.navtext a,
.navbottom.navtext
a{display:inline-block;max-width:45%}.navtop.navtext a.bookprev,
.navbottom.navtext
a.bookprev{float:left;text-align:left}.dir-rtl .navtop.navtext a.bookprev,
.dir-rtl .navbottom.navtext
a.bookprev{float:right;text-align:right}@media (max-width: 480px){.path-mod-book .navbottom,
.path-mod-book .navtop,
.dir-rtl.path-mod-book .navbottom,
.dir-rtl.path-mod-book
.navtop{text-align:center}.navtop.navtext a,
.navbottom.navtext
a{display:block;max-width:100%;margin:auto}.navtop.navtext a.bookprev,
.navbottom.navtext a.bookprev,
.dir-rtl .navtop.navtext a.bookprev,
.dir-rtl .navbottom.navtext
a.bookprev{float:none}}.path-mod-chat .chat-event .picture,
.path-mod-chat .chat-message
.picture{width:40px}.path-mod-chat .chat-event
.text{text-align:left}.path-mod-chat #messages-list,
.path-mod-chat #users-list{list-style-type:none;padding:0;margin:0}.path-mod-chat #chat-header{overflow:hidden}.path-mod-chat #chat-input-area table.generaltable
td.cell{padding:1px}@media all and (max-device-width: 320px){.path-mod-chat #input-message{width:150px}}@media all and (min-device-width: 321px) and (max-device-width: 640px){.path-mod-chat #input-message{width:175px}}#page-mod-chat-view .chatcurrentusers
.chatuserdetails{vertical-align:middle}#page-mod-chat-gui_basic #participants
ul{margin:0;padding:0;list-style-type:none}#page-mod-chat-gui_basic #participants ul
li{list-style-type:none;display:inline;margin-right:10px}#page-mod-chat-gui_basic #participants ul li
.userinfo{display:inline}#page-mod-chat-gui_basic
#messages{padding:0;margin:0}#page-mod-chat-gui_basic #messages
dl{padding:0;margin:6px
0}#page-mod-chat-gui_basic #messages
dt{margin-left:0;margin-right:5px;padding:0;display:inline}#page-mod-chat-gui_basic #messages
dd{padding:0;margin:0}#page-mod-chat-gui_header_js-jsupdate .chat-event,
#page-mod-chat-gui_header_js-jsupdate .chat-message{width:100%}.path-mod-chat .yui-layout-unit-top{background:#FFE39D}.path-mod-chat .yui-layout-unit-right{background:#FFD46B}.path-mod-chat .yui-layout-unit-bottom{background:#FFCB44}.path-mod-chat .yui-layout .yui-layout-hd{border:0}.path-mod-chat .yui-layout .yui-layout-unit div.yui-layout-bd{border:0;background:transparent}.path-mod-chat .yui-layout .yui-layout-unit div.yui-layout-unit-right{background:white}ol.checklist{margin-top:10px;margin-bottom:0}ol.checklist
ol.checklist{margin-top:0}ol.checklist
li{list-style-type:none}ol.checklist
.useritem{font-style:italic;color:#404090}ol.checklist
.note{font-style:italic;color:#a0a0e0;padding:0
0 0 20px}ol.checklist
.itemoptional{font-style:italic}ol.checklist
.itemheading{font-weight:bold}ol.checklist
.itemblack{color:#000}ol.checklist
.itemblack.itemoptional{color:#a0a0a0}ol.checklist
.itemred{color:#f00}ol.checklist
.itemred.itemoptional{color:#ffa0a0}ol.checklist
.itemorange{color:#ffba00}ol.checklist
.itemorange.itemoptional{color:#ffdaa0}ol.checklist
.itemgreen{color:#0f0}ol.checklist
.itemgreen.itemoptional{color:#a0ffa0}ol.checklist
.itempurple{color:#d000ff}ol.checklist
.itempurple.itemoptional{color:#d0a0ff}ol.checklist
.teachercomment{color:black;background-color:#ffffb0;border:solid black 1px;margin:0
0 0 20px}ol.checklist
.itemauto.itemdisabled{text-decoration:line-through;background-color:#bcc4c4}ol.checklist
.itemauto{background-color:#d6e6e7}ol.checklist li
.itemuserdate{background-color:#b0ffb0;position:absolute;width:10em;left:75%;z-index:100}ol.checklist li
.itemteacherdate{background-color:#b0ffb0;position:absolute;width:10em;left:60%;z-index:100}ol.checklist li
.itemteachername{background-color:#b0ffb0;position:absolute;width:10em;left:45%;z-index:100}.checklist-itemdue{font-style:italic;color:#095C09}.checklist-itemoverdue{font-style:italic;color:#C71212}.checklistreport
.header{background-color:#e1e1df}.checklistreport
.head0{font-weight:bold}.checklistreport
.head1{font-weight:normal}.checklistreport
.head2{font-weight:normal;font-style:italic}.checklistreport
.cell.reportheading{background-color:black}.checklistreport
.cell.level0{background-color:#e7e7e7}.checklistreport
.cell.level1{background-color:#c7c7c7}.checklistreport
.cell.level2{background-color:#afafaf}.checklistreport .cell.level0-checked{background-color:#0f0}.checklistreport .cell.level1-checked{background-color:#00df00}.checklistreport .cell.level2-checked{background-color:#00bf00}.checklistreport .cell.level0-unchecked{background-color:#f00}.checklistreport .cell.level1-unchecked{background-color:#df0000}.checklistreport .cell.level2-unchecked{background-color:#bf0000}.checklist_progress_heading{display:block;float:left;width:150px}.checklist_progress_outer{border-width:1px;border-style:solid;border-color:black;width:300px;background-color:transparent;height:15px;float:left;overflow:hidden;position:relative;box-shadow:2px 2px 3px #ccc;border-radius:5px}.checklist_progress_inner{background-color:#229b15;background-image:url(/sunguru/theme/image.php/archaius/mod_checklist/1531975376/progress);height:100%;width:100%;background-repeat:repeat-x;background-position:top;z-index:10;display:block;position:absolute;top:0;left:0;box-shadow:0 0 4px #229b15;border-radius:2px}.checklist_progress_anim{background-color:#98c193;background-image:url(/sunguru/theme/image.php/archaius/mod_checklist/1531975376/progress-fade);height:15px;width:0;background-repeat:repeat-x;background-position:top;position:absolute;left:0;top:0;z-index:5;display:block;box-shadow:0 0 4px #98c193;border-radius:2px}.checklistimportexport{text-align:right;width:90%}p.checklistwarning{margin-top:1em;color:#800000;font-weight:bold}.checklist_progress_percent{padding-left:0.5em}.jsenabled
#checklistsavechecks{display:none}#checklistspinner{display:none;position:absolute;top:5px;left:5px;width:16px;height:16px;background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/loading_small)}.checklistbox{position:relative;top:0;left:0}ol.checklist
label{display:inline}.checklist-extendedit .checklist-edititem{border:1px
solid #ddd;padding:10px
0 5px;margin:5px
0}.checklist-groupingname{color:#ccc}.path-mod-choice
.results{border-collapse:separate}.path-mod-choice .results
.data{vertical-align:top;white-space:nowrap}.path-mod-choice
.button{text-align:center}.path-mod-choice
.attemptcell{width:5px;white-space:nowrap}.path-mod-choice .anonymous,
.path-mod-choice
.names{margin-left:auto;margin-right:auto;width:80%}.path-mod-choice
.downloadreport{border-width:0;margin-left:10%}.path-mod-choice
.choiceresponse{width:100%}.path-mod-choice .choiceresponse
.picture{width:10px;white-space:nowrap}.path-mod-choice .choiceresponse
.fullname{width:100%;white-space:nowrap}.path-mod-choice
.responseheader{width:100%;text-align:center;margin-top:10px}.path-mod-choice .choices .option
label{vertical-align:top}.path-mod-choice .choices .option
input{vertical-align:middle}.path-mod-choice .horizontal,
.path-mod-choice
.vertical{margin-left:10%;margin-right:10%}.path-mod-choice .horizontal .choices
.option{padding-right:20px;display:inline-block;white-space:normal}.path-mod-choice .horizontal .choices
.button{margin-top:10px}.path-mod-choice ul.choices
li{list-style:none}.path-mod-choice
.results{text-align:center}.path-mod-choice .results.anonymous
.graph.horizontal{vertical-align:middle;text-align:left;width:70%}.path-mod-choice .results.anonymous .graph.vertical,
.path-mod-choice
.cell{vertical-align:bottom;text-align:center}.path-mod-choice .results.anonymous
th.header{border:1px
solid inherit}.path-mod-choice .results.names
.header{width:10%;white-space:normal}.path-mod-choice .results.names
.cell{vertical-align:top;text-align:left}.path-mod-choice .results.names .user,
.path-mod-choice
#yourselection{padding:5px}.path-mod-choice .results.names .user .attemptaction,
.path-mod-choice .results.names .user .image,
.path-mod-choice .results.names .user
.fullname{float:left}.path-mod-choice .results.names .user
.fullname{padding-left:5px}.path-mod-choice .results
.data.header{width:10%}.path-mod-choice
.responseaction{text-align:center}.path-mod-choice .results
.option{white-space:normal}.path-mod-choice
.response{overflow:auto}.path-mod-choice .results .option,
.path-mod-choice .results .numberofuser,
.path-mod-choice .results
.percentage{font-weight:bold;font-size:108%}#page-mod-choice-report .downloadreport ul
li{list-style:none;padding:0
20px;display:inline;float:left}.path-mod-choice
.clearfloat{float:none;clear:both}.path-mod-choice.dir-rtl .horizontal .choices
.option{padding-right:0px;padding-left:20px;float:right}.path-mod-choice.dir-rtl .results.anonymous
.graph.horizontal{text-align:right}.path-mod-choice.dir-rtl
.results.anonymous{text-align:center}.path-mod-choice.dir-rtl .results.names
.cell{text-align:right}.path-mod-choice.dir-rtl .results.names .user .attemptaction,
.path-mod-choice.dir-rtl .results.names .user .image,
.path-mod-choice.dir-rtl .results.names .user .fullname,
.path-mod-choice.dir-rtl .results.names .user
.fullname{padding-left:0px;padding-right:5px}.path-mod-choice.dir-rtl
.downloadreport{margin-left:0;margin-right:25%}#page-mod-choice-report.dir-rtl .downloadreport ul
li{float:right}#page-mod-choice-view.dir-rtl
.reportlink{text-align:left}.path-mod-data .fieldadd,
.path-mod-data .sortdefault,
.path-mod-data .defaulttemplate,
#page-mod-data-view .datapreferences,
#page-mod-data-preset
.presetmapping{text-align:center}.path-mod-data-field .c0,
#page-mod-data-view #sortsearch
.c0{text-align:right}#page-mod-data-view .approve
img.icon{width:34px;height:34px}#page-mod-data-view
img.list_picture{border:0px}#page-mod-data-view
div.search_none{display:none}#page-mod-data-view div.search_inline,
#page-mod-data-view
form#latlongfieldbrowse{display:inline}#page-mod-data-view
div#data_adv_form{margin-left:auto;margin-right:auto}#page-mod-data-edit
.basefieldinput{width:300px}#page-mod-data-preset .presetmapping
table{text-align:left;margin-left:auto;margin-right:auto}#page-mod-data-preset
.overwritesettings{margin-bottom:1em}#page-mod-data-preset
table.presets{margin-left:auto;margin-right:auto}#page-mod-data-view .datapreferences
label{display:inline-block}.path-mod-data-field .fieldadd,
.path-mod-data-field
.sortdefault{margin:1em
0}.path-mod-data-field .fieldadd select,
.path-mod-data-field .sortdefault
select{margin-left:1em}.path-mod-data-field .fieldname,
.path-mod-data-field
.fielddescription{width:300px}.path-mod-data-field
textarea.optionstextarea{width:300px;height:150px}.path-mod-data-field
input.textareafieldsize{width:50px}.path-mod-data-field
input.picturefieldsize{width:70px}.path-mod-data .action-icon img.portfolio-add-icon{margin-left:0}#page-mod-data-export #notice
span{padding:0
10px}#page-mod-data-edit input[id*="url"]{text-align:left;direction:ltr}.mod-data-default-template
td{vertical-align:top}.mod-data-default-template .template-field{text-align:right}.mod-data-default-template .template-token{text-align:left}.mod-data-default-template
.controls{text-align:center}.mod-data-default-template
searchcontrols{text-align:right}.mod-data-default-template.notapproved{background-color:#FCC}#page-mod-data-templates td.save_template,
#page-mod-data-templates
.template_heading{text-align:center}#page-mod-data-templates
#availabletags_wrapper{max-width:250px}.dir-rtl .mod-data-default-template .template-field{text-align:left}.dir-rtl .mod-data-default-template .template-token{text-align:right}.dir-rtl .mod-data-default-template
searchcontrols{text-align:left}#page-mod-data-edit
.req{cursor:help}#page-mod-data-edit .inline-req
.req{position:absolute}#page-mod-data-edit .inline-req{text-align:left}#page-mod-data-edit .mod-data-input{margin-left:10px}.dir-rtl#page-mod-data-edit .inline-req{text-align:right}.dir-rtl#page-mod-data-edit .mod-data-input{margin-left:0px;margin-right:10px}.path-mod-feedback
span.feedback_info{font-weight:bold}.path-mod-feedback
div.feedback_is_dependent{background:#DDD}.path-mod-feedback
span.feedback_depend{color:#f00}.path-mod-feedback
hr.feedback_pagebreak{height:4px;color:#aaa;background-color:#aaa;border:0;margin:0}.path-mod-feedback
.drag_target_active{opacity: .25}.path-mod-feedback
.drag_item_active{opacity: .5}.path-mod-feedback
.feedback_bar_image{height:10px}.path-mod-feedback #analysis-form
label{display:inline}.path-mod-feedback .mform.feedback_form .fitem
.fitemtitle{display:block;margin-top:4px;margin-bottom:4px;text-align:left;width:100%}.path-mod-feedback .mform.feedback_form .fitem
.felement{margin-left:0;width:100%;float:left;padding-left:0;padding-right:0}.path-mod-feedback .mform.feedback_form .fitem .fstatic:empty{display:none}.path-mod-feedback .mform.feedback_form .fitem .fcheckbox > span,
.path-mod-feedback .mform.feedback_form .fitem .fradio > span,
.path-mod-feedback .mform.feedback_form .fitem .fgroup>span{margin-top:4px}body.path-mod-feedback #region-main .mform.feedback_form .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:0}.path-mod-feedback .mform.feedback_form .femptylabel
.felement{display:inline-block;margin-top:4px;padding-top:5px;width:auto}body.path-mod-feedback #region-main .mform.feedback_form .feedback-item-pagebreak
.felement{width:100%}.path-mod-feedback .mform.feedback_form .fitem_fcheckbox .fitemtitle,
.path-mod-feedback .mform.feedback_form .fitem_fcheckbox
.felement{display:inline-block;width:auto}.path-mod-feedback .mform.feedback_form .fitem_fcheckbox
.felement{padding:6px}body.dir-rtl.path-mod-feedback #region-main .mform.feedback_form .femptylabel
.fitemtitle{margin-right:0px;margin-left:0}.dir-rtl.path-mod-feedback .mform.feedback_form .fitem
.fitemtitle{text-align:right}.dir-rtl.path-mod-feedback .mform.feedback_form .fitem
.felement{margin-right:0;float:right;padding-right:0;padding-left:0}.dir-rtl.path-mod-feedback .mform.feedback_form .fitem_fcheckbox
.felement{float:right}.path-mod-feedback .mform.feedback_form#feedback_viewresponse_form .fitem.feedback_hasvalue:not(.feedback-item-captcha) .felement{background:#FBFBF1;min-height:1em;box-sizing:border-box;padding:3px;border:1px
solid #ddd}.path-mod-feedback .mform.feedback_form .fitem.feedback_hasvalue .fstatic:empty{display:inherit}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem:hover{background:#f5f5f5}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle
label{width:100%}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle
.itemtitle{position:relative;width:100%}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle .itemtitle .itemdd,
.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle .itemtitle
.itemname{float:left}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle .itemtitle
.itemactions{float:right}.path-mod-feedback .templateslist td.cell.action,
.path-mod-feedback .templateslist
th.header.action{width:10%}.path-mod-feedback
table.analysis{width:100%;border-top:1px solid #aaa;margin-top:10px}.path-mod-feedback table.analysis tr:first-child
th{padding-top:10px}.path-mod-feedback table.analysis tr:hover{background:#f5f5f5}.path-mod-feedback table.analysis td.singlevalue:before,
.path-mod-feedback table.analysis td.optionname:before{content:'- '}.path-mod-feedback table.analysis.itemtype_textarea
td{padding:4px
0}.path-mod-feedback table.analysis
tr.isempty{display:none}.path-mod-feedback #showentrytable td.cell.completed_timemodified,
.path-mod-feedback #showentryanontable
td.cell.random_response{font-weight:bold}.path-mod-feedback #showentrytable td.cell.userpic,
.path-mod-feedback #showentrytable td.cell.deleteentry,
.path-mod-feedback #showentryanontable
td.cell.deleteentry{width:10px}.path-mod-feedback
.response_navigation{margin: .5em 0}.path-mod-feedback .response_navigation
a{display:inline-block}.path-mod-feedback .response_navigation
a.back_to_list{margin:auto;float:right;left:-50%;position:relative}.dir-rtl.path-mod-feedback .response_navigation .next_response:after,
.path-mod-feedback .response_navigation .prev_response:before{content:' ◄ '}.dir-rtl.path-mod-feedback .response_navigation .prev_response:before,
.path-mod-feedback .response_navigation .next_response:after{content:' ► '}.dir-rtl.path-mod-feedback .response_navigation .prev_response,
.path-mod-feedback .response_navigation
.next_response{float:right}.dir-rtl.path-mod-feedback .response_navigation .next_response,
.path-mod-feedback .response_navigation
.prev_response{float:left}.forumpost{display:block;position:relative;margin:0
0 1em 0;padding:0;border:1px
solid #000;max-width:100%}.forumpost
.row{width:100%;position:relative}.forumpost .row
.left{float:left;width:43px;overflow:hidden}.forumpost .row .left .grouppictures
a{text-align:center;display:block;margin:6px
2px 0 2px}.forumpost .row .left
.grouppicture{width:20px;height:20px}.forumpost .row .topic,
.forumpost .row .content-mask,
.forumpost .row
.options{margin-left:43px}.forumpost .picture
img{margin:4px}.forumpost .options .commands,
.forumpost .content .attachments,
.forumpost .options .footer,
.forumpost .options
.link{text-align:right}.forumpost .options .forum-post-rating{float:left}.forumpost .content
.posting{overflow:auto;max-width:100%}.forumpost .content .attachedimages
img{max-width:100%}.forumpost .post-word-count{font-size: .85em;font-style:italic}.forumpost .shortenedpost .post-word-count{display:inline;padding:0
.3em}.dir-rtl .forumpost .row .topic,
.dir-rtl .forumpost .row .content-mask,
.dir-rtl .forumpost .row
.options{margin-right:43px;margin-left:0}.dir-rtl .forumpost .row
.left{float:right}.dir-rtl.path-mod-forum
.indent{margin-right:3%;margin-left:0}.path-mod-forum .forumolddiscuss,
#page-mod-forum-search
.c0{text-align:right}.path-mod-forum
.indent{margin-left:3%}.path-mod-forum
.forumheaderlist{width:100%;border-width:1px;border-style:solid;border-collapse:separate;margin-top:10px}.path-mod-forum .forumheaderlist
td{border-width:1px 0px 0px 1px;border-style:solid}.path-mod-forum .forumheaderlist th.header.replies
.iconsmall{margin:0
.3em}.path-mod-forum .forumheaderlist
.picture{width:35px}.path-mod-forum .forumheaderlist .discussion
.starter{vertical-align:middle}.path-mod-forum .forumheaderlist .discussion .pinned
img{padding:5px}.path-mod-forum .forumheaderlist .discussion
.lastpost{white-space:nowrap;text-align:right}.path-mod-forum .forumheaderlist .replies,
.path-mod-forum .forumheaderlist .discussion
.author{white-space:nowrap}.path-mod-forum .forumheaderlist thead
.discussionsubscription{text-align:center}#page-mod-forum-subscribers .subscriberdiv,
#page-mod-forum-subscribers
.subscribertable{width:100%;vertical-align:top}#page-mod-forum-subscribers .subscribertable tr
td{vertical-align:top}#page-mod-forum-subscribers .subscribertable tr
td.actions{width:16%;padding-top:3em}#page-mod-forum-subscribers .subscribertable tr td.actions
.actionbutton{margin:0.3em 0;padding:0.5em 0;width:100%}#page-mod-forum-subscribers .subscribertable tr td.existing,
#page-mod-forum-subscribers .subscribertable tr
td.potential{width:42%}#page-mod-forum-discuss
.discussioncontrols{width:100%;margin:5px}#page-mod-forum-discuss .discussioncontrols
.controlscontainer{width:100%;float:right}#page-mod-forum-discuss .discussioncontrols
.discussioncontrol{float:left}#page-mod-forum-discuss
.discussioncontrol.exporttoportfolio{text-align:left}#page-mod-forum-discuss
.discussioncontrol.displaymode{padding-right:10px}#page-mod-forum-discuss
.discussioncontrol.movediscussion{padding-right:10px}#page-mod-forum-discuss .discussioncontrol.movediscussion
.movediscussionoption{}#page-mod-forum-view
.forumaddnew{margin-bottom:20px}#page-mod-forum-view
.groupmenu{float:left;text-align:left;white-space:nowrap}#page-mod-forum-index .subscription,
#page-mod-forum-view
.subscription{float:right;text-align:right;white-space:nowrap;margin:5px
0}#page-mod-forum-search
.introcontent{padding:15px;font-weight:bold}#page-mod-forum-index .unread a:first-child,
#page-mod-forum-view .unread a:first-child{padding-right:10px}#page-mod-forum-index .unread img,
#page-mod-forum-view .unread
img{margin-left:5px}#page-mod-forum-view .unread
img{margin-left:5px}.dir-rtl#page-mod-forum-view .unread
img{margin-right:5px;margin-left:0}#email
.unsubscribelink{margin-top:20px}#page-mod-forum-view .unread,
.forumpost.unread .row.header,
.path-course-view .unread,span.unread{background-color:#FFD}.forumpost.unread
.row.header{border-bottom:1px solid #DDD}.path-mod-forum :target~.forumpost:before{display:block;content:'';width:4px;position:absolute;background:#0070a8;left:-1px;top:-1px;bottom:-1px}.path-mod-forum .discussion-nav{margin: .5em 0}.path-mod-forum .discussion-nav
ul{margin:0;list-style:none}.dir-rtl.path-mod-forum .discussion-nav .next-discussion:after,
.path-mod-forum .discussion-nav .prev-discussion:before{content:' ◄ '}.dir-rtl.path-mod-forum .discussion-nav .prev-discussion:before,
.path-mod-forum .discussion-nav .next-discussion:after{content:' ► '}.dir-rtl.path-mod-forum .discussion-nav .prev-discussion,
.path-mod-forum .discussion-nav .next-discussion{float:right}.dir-rtl.path-mod-forum .discussion-nav .next-discussion,
.path-mod-forum .discussion-nav .prev-discussion{float:left}.path-mod-forum .preload-subscribe{background:url(/sunguru/theme/image.php/archaius/mod_forum/1531975376/t/subscribed) no-repeat -9999px -9999px}.path-mod-forum .preload-unsubscribe{background:url(/sunguru/theme/image.php/archaius/mod_forum/1531975376/t/unsubscribed) no-repeat -9999px -9999px}.path-mod-forum
.discussionsubscription{margin-top:-10px;text-align:right;margin-bottom:10px}.path-mod-forum .discussionsubscription>a>img{width:12px;padding:0
4px}.dir-rtl .path-mod-forum
.discussionsubscription{text-align:left}#page-mod-forum-view
img.timedpost{margin-right:5px}.dir-rtl#page-mod-forum-view
img.timedpost{margin:3px
0 0 5px;float:right}.path-mod-glossary
.glossarypost{width:95%;border-collapse:separate;margin:0px
auto;text-align:left}.path-mod-glossary
.glossarypost.entrylist{border-width:0px}.path-mod-glossary .glossarypost.continuous
.concept{display:inline}.path-mod-glossary .glossarypost
.commands{width:200px;white-space:nowrap}.path-mod-glossary .glossarypost
td.picture{width:35px}.path-mod-glossary .glossarypost .entrylowersection
.aliases{text-align:center}.path-mod-glossary .glossarypost .entrylowersection
.icons{text-align:right;padding-right:5px}.path-mod-glossary .glossarypost .entrylowersection
.ratings{text-align:right;padding-right:5px;padding-bottom:2px}.path-mod-glossary .glossarypost .glossary-hidden-note{margin:0
.45em}.path-mod-glossary
.glossarydisplay{margin-left:auto;margin-right:auto}.path-mod-glossary .glossarydisplay
.tabs{width:100%;margin-bottom:0px}.path-mod-glossary .glossarydisplay .tabs
.side{border-style:none;border-width:0px;width:auto}.path-mod-glossary .glossarydisplay
.separator{width:4px}.path-mod-glossary
table.glossarypopup{width:95%}.path-mod-glossary .entrybox, .path-mod-glossary table.glossaryapproval,
.path-mod-glossary .glossarypost .entrylowersection
table{width:100%;margin-bottom:0em}.glossary-activity-picture{float:left}.glossary-activity-content{margin-left:40px}#page-mod-glossary-view
.glossarycontrol{float:right;text-align:right;white-space:nowrap;margin:5px
0}#page-mod-glossary-view table.glossarycategoryheader,
#page-mod-glossary-import
table.glossaryimportexport{margin-left:auto;margin-right:auto}#page-mod-glossary-view
table.glossarycategoryheader{margin-bottom:0em}#page-mod-glossary-view table.glossarycategoryheader
th{padding:0px}#page-mod-glossary-view td.glossarysearchbox
label{display:inline-block}#page-mod-glossary-showentry #page-content{min-width:600px}#page-mod-glossary-print .mod-glossary-entrylist .mod-glossary-entry{vertical-align:top}#page-mod-glossary-print .displayprinticon,
.path-mod-glossary.dir-rtl
.glossarypost{text-align:right}#page-mod-glossary-print
.displaydate{text-align:right;font-size:0.75em}#page-mod-glossary-print
.strong{font-weight:bold}.path-mod-glossary
.printicon{background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/print) no-repeat scroll 2px center transparent;padding-left:20px}.h5p-data-view
table{width:100%;border:1px
solid #e5e5e5;box-shadow:0 1px 1px rgba(0,0,0,.04);table-layout:fixed}.h5p-data-view td,
.h5p-data-view
th{padding:8px
10px;color:#555;vertical-align:top;font-size:13px;line-height:1.5em;word-wrap:break-word}.h5p-data-view
th{font-size:14px;font-weight:normal;line-height:1.4em;color:#32373c}.h5p-data-view thead
th{border-bottom:1px solid #e1e1e1}.h5p-data-view tfoot
td{border-top:1px solid #e1e1e1;font-size:14px}.h5p-data-view tr:nth-child(odd){background-color:#F9F9F9}.h5p-pagination{text-align:center;line-height:2em}.h5p-pagination>span,.h5p-pagination>input{margin:0
1em}.h5p-pagination
button{margin:0}.h5p-data-view input[type="text"]{margin-bottom:0.5em}.h5p-data-view input[type="text"]::-ms-clear{display:none}.h5p-data-view th[role="button"]{cursor:pointer}.h5p-data-view th[role="button"].h5p-sort:after,
.h5p-data-view th[role="button"]:hover:after,
.h5p-data-view th[role="button"].h5p-sort.h5p-reverse:hover:after{content:"\25BE";position:relative;left:0.5em;top:-1px}.h5p-data-view th[role="button"].h5p-sort.h5p-reverse:after,
.h5p-data-view th[role="button"].h5p-sort:hover:after{content:"\25B4";top:-2px}.h5p-data-view th[role="button"]:hover:after,
.h5p-data-view th[role="button"].h5p-sort.h5p-reverse:hover:after,
.h5p-data-view th[role="button"].h5p-sort:hover:after{color:#999}#page-mod-imscp-view
#imscp_nav{text-align:center;margin-bottom:5px;margin-top:10px}#page-mod-imscp-view #imscp_toc .ygtv-highlight1{font-weight:bold}#page-mod-imscp-view .yui-layout-hd{background-image:none;background-color:#DDD}#page-mod-imscp-view .yui-layout-hd
h2{color:black}.path-mod-imscp
#imscp_child_list{margin-left:1em;width:auto;height:auto}#page-mod-journal-view
.feedbackbox{width:75%;border-collapse:separate}#page-mod-journal-view
.entrycontent{padding:3px}#page-mod-journal-view
.picture{width:35px}#page-mod-journal-view
.info{margin-bottom:5px;text-align:right}#page-mod-journal-view .journalstart,
#page-mod-journal-report
.feedbacksave{text-align:center}#page-mod-journal-view .lastedit,
#page-mod-journal-view
.editend{font-size:0.7em;margin:5px;text-align:center}#page-mod-journal-view
.author{font-size:1em;font-weight:bold}#page-mod-journal-view
.time{font-size:0.7em;font-style:italic}#page-mod-journal-view
.grade{font-weight:bold;font-style:italic;text-align:right}#page-mod-journal-index
.cell{font-size:0.8em}#page-mod-journal-view .feedbackbox .left,
#page-mod-journal-view .feedbackbox
.entryheader{background-color:#ddd}#page-mod-journal-view
.feedbackbox{-moz-border-radius-bottomleft:15px;-moz-border-radius-bottomright:15px;border-spacing:0;margin:0
auto}#page-mod-journal-view .feedbackbox
.side{-moz-border-radius-bottomleft:15px}#page-mod-journal-view .feedbackbox
.entrycontent{-moz-border-radius-bottomright:15px}#page-mod-journal-report
.journaluserentry{border:1px
solid #000;border-collapse:collapse;border-spacing:0}#page-mod-journal-report .journaluserentry
td{padding:10px;vertical-align:top;width:100%}#page-mod-journal-report .journaluserentry
td.userpix{width:35px}#page-mod-journal-report .journaluserentry
td.userfullname{white-space:nowrap}#page-mod-journal-report .journaluserentry td
.lastedit{font-size:0.76em;margin-left:10px}.path-mod-lesson .contents,
.path-mod-lesson .standardtable,
.path-mod-lesson .mform .box.contents,
.path-mod-lesson .invisiblefieldset.fieldsetfix
tr{text-align:left}.path-mod-lesson #layout-table{width:100%}.path-mod-lesson .edit_buttons form,
.path-mod-lesson .edit_buttons
input{display:inline}.path-mod-lesson .userinfotable .cell,
.path-mod-lesson .userinfotable
.userpicture{vertical-align:middle}.path-mod-lesson
.invisiblefieldset.fieldsetfix{display:block}.path-mod-lesson
.slideshow{overflow:auto;padding:15px}.path-mod-lesson .menu
.menuwrapper{max-height:400px;overflow:auto;vertical-align:top;margin-bottom:10px}.path-mod-lesson .menu
ul{list-style:none;padding:5px
0px 0px 5px;margin:0px}.path-mod-lesson .menu ul
li{padding-bottom:5px}.path-mod-lesson
.skip{position:absolute;top:-1000em;width:20em}.path-mod-lesson .branchbuttoncontainer.horizontal div,
.path-mod-lesson .branchbuttoncontainer.horizontal
form{display:inline}.path-mod-lesson
.firstpageoptions{width:30%;margin-left:35%;margin-top:1em}.path-mod-lesson .progress_bar_table,
.path-mod-lesson .progress_bar_completed,
.path-mod-lesson
.progress_bar_todo{padding:0;margin:0}.path-mod-lesson
.progress_bar_token{height:20px;width:5px;padding:0;margin:0}.path-mod-lesson .edit_pages_box
.addlinks{margin:0;margin-bottom:1em}.path-mod-lesson
.progress_bar_completed{background-color:green;text-align:right;vertical-align:middle;color:#FFF}.path-mod-lesson
.resourcecontent{text-align:center}.path-mod-lesson .answeroption .fcheckbox>span{position:relative;float:left}.path-mod-lesson .answeroptiongroup .fgroup>span{position:relative;width:100%}.path-mod-lesson .answeroption .fcheckbox input,
.path-mod-lesson .answeroptiongroup
input{position:absolute;top:2px;margin-top:0px;left:0}.path-mod-lesson .answeroption .fcheckbox label,
.path-mod-lesson .mform .fitem.answeroptiongroup fieldset.fgroup
label{padding-left:20px;float:left}.path-mod-lesson .answeroption .felement label p:last-child,
.path-mod-lesson .answeroptiongroup .felement label p:last-child{margin-bottom:0px}.path-mod-lesson.dir-rtl .answeroption .fcheckbox>span{float:right}.path-mod-lesson.dir-rtl .answeroption .fcheckbox input,
.path-mod-lesson.dir-rtl .answeroptiongroup .fgroup
input{left:inherit;right:0}.path-mod-lesson.dir-rtl .answeroption .fcheckbox label,
.path-mod-lesson.dir-rtl .mform .fitem.answeroptiongroup fieldset.fgroup
label{padding-left:0;padding-right:20px;float:right}#page-mod-lesson-view .password-form
.submitbutton{display:inline}.path-mod-lesson
.reviewessay{width:40%;border:1px
solid #DDD;background-color:#EEE}.path-mod-lesson.dir-rtl .contents,
.path-mod-lesson.dir-rtl .standardtable,
.path-mod-lesson.dir-rtl .mform .box.contents,
.path-mod-lesson.dir-rtl .invisiblefieldset.fieldsetfix
tr{text-align:right}#lesson-timer{text-align:center}.path-mod-lesson
.essayungraded{background-color:#efcfcf}.path-mod-lesson
.essaygraded{background-color:#efefcf}.path-mod-lesson
.essaysent{background-color:#cfefcf}.path-mod-lti
.ltiframe{position:relative;width:100%;height:100%}.path-mod-lti .userpicture,
.path-mod-lti .picture.user,
.path-mod-lti
.picture.teacher{width:35px;height:35px;vertical-align:top}.path-mod-lti .feedback .files,
.path-mod-lti .feedback .grade,
.path-mod-lti .feedback .outcome,
.path-mod-lti .feedback
.finalgrade{float:right}.path-mod-lti .feedback
.disabledfeedback{width:500px;height:250px}.path-mod-lti .feedback
.from{float:left}.path-mod-lti .files
img{margin-right:4px}.path-mod-lti .files
a{white-space:nowrap}.path-mod-lti
.late{color:red}.path-mod-lti
.message{text-align:center}.path-admin-mod-lti .mform .fitem
.fitemtitle{min-width:18em;padding-right:1em}.path-mod-lti .mform .fitem
.fitemtitle{min-width:14em;padding-right:1em}#page-mod-lti-instructor_edit_tool_type .mform .fitem
.fitemtitle{min-width:18em;padding-right:1em}#registration-choice-container .buffer-text{margin:20px}#choice-list{list-style:none;border-bottom:1px solid #e3e3e3;padding-bottom:1em;margin-left:0}#choice-list>li{display:inline-block}#external-registration-container
iframe{border:1px
solid #e5e5e5;border-radius:10px;width:100%;min-height:800px}.loading-screen{text-align:center;padding:3em}.loading-screen .loading-text{font-size:2em}.loading-screen
.loader{margin-left:auto;margin-right:auto;margin-bottom:1em;height:2em;width:2em;font-size:2em}#registration-submit{min-width:140px}#registration-form-container{min-height:260px}#registration-form-container
.well{margin-bottom:0}#registration-form-container .control-group:last-child{margin-bottom:0}#registration-choice-container
.well{text-align:center}#registration-choice-container .btn-toolbar{margin-bottom:0}#registration-choice-container p:last-child{margin-top:20px}#tool-type-capabilities-container .registration-loading-container{display:none}#tool-type-capabilities-container.loading .registration-loading-container{display:block}#tool-type-capabilities-container.loading #tool-type-capabilities-template-container{display:none}.centered-menu{max-width:70%;margin-left:auto;margin-right:auto}.btn-text{display:block}.btn-loader{display:none}.loading .btn-text{display:none}.loading .btn-loader{display:block}.btn
.loader{margin-left:auto;margin-right:auto}.btn .loader
img{height:1.5em}#tool-list-container
h3{display:inline-block}#tool-list-loader-container{display:inline-block}#tool-list-loader-container
.loader{display:none}#tool-list-loader-container .loader
img{height:2em}.loading #tool-list-loader-container
.loader{display:block}.loading #tool-notools-text{display:none}.tool-card{display:inline-block;width:250px;height:300px;border:1px
solid #e5e5e5;border-radius:10px;margin:5px;position:relative;box-sizing:border-box;vertical-align:top}.tool-card:hover,.tool-card:focus{border-color:#08c;box-shadow:0 1px 4px rgba(0, 105, 214, 0.25);-webkit-transition:border linear 0.2s, box-shadow linear 0.2s;-moz-transition:border linear 0.2s, box-shadow linear 0.2s;-o-transition:border linear 0.2s, box-shadow linear 0.2s;transition:border linear 0.2s, box-shadow linear 0.2s}.tool-card .overlay-container{background-color:rgba(255, 255, 255, 0.8);border-radius:10px;display:none;height:100%;left:0;position:absolute;text-align:center;top:0;width:100%;z-index:100;box-sizing:border-box;padding:10px}.tool-card .overlay-container .img-container{position:absolute;top:115px;left:90px;display:block;width:70px;height:70px}.tool-card .overlay-container .img-container
img{height:100%;width:100%}.tool-card.announcement>.overlay-container{display:block}.tool-card.announcement .overlay-container
.loader{display:none}.tool-card.announcement.loading .overlay-container
.loader{display:block;width:100%;height:100%}.tool-card.announcement .overlay-container .success-icon-container{display:none}.tool-card.announcement.success .overlay-container .success-icon-container{display:block}.tool-card.announcement .overlay-container .fail-icon-container{display:none}.tool-card.announcement.fail .overlay-container .fail-icon-container{display:block}.tool-card.announcement .overlay-container .capabilities-container{display:none}.tool-card.announcement.capabilities .overlay-container .capabilities-container{display:block}.tool-card.announcement.capabilities .overlay-container{background-color:rgb(255, 255, 255)}.tool-card.announcement.capabilities .overlay-container .img-container{display:none}.tool-card-content{z-index:1}.tool-card-header{text-align:center;background-color:#f5f5f5;padding:10px;border-top-left-radius:10px;border-top-right-radius:10px;box-sizing:border-box;height:125px}.tool-card-subheader{margin-bottom:10px;text-align:left}.dir-rtl .tool-card-subheader{text-align:right}.tool-card-header .tool-card-icon{width:35px;height:35px}.tool-card-header
.name{margin-bottom:0;white-space:nowrap}.tool-card-header .tool-card-actions{float:right}.dir-rtl .tool-card-header .tool-card-actions{float:left}.tool-card-header .tool-card-actions
img{width:15px;height:15px;margin-left:7px}.dir-rtl .tool-card-header .tool-card-actions
img{margin-left:0px;margin-right:7px}.tool-card-body{border-top:1px solid #e5e5e5;box-sizing:border-box;padding:5px;height:125px}.tool-card-body
.description{max-height:100px;word-wrap:break-word}.tool-card-footer{height:50px;text-align:center;padding-top:10px;box-sizing:border-box}.tool-card .contenteditable-container{position:relative}.tool-card [contenteditable=true]{border:1px
solid transparent;padding:0.25em;position:relative;z-index:1;overflow:auto}.tool-card [contenteditable=true]:hover{border-radius:4px;box-shadow:inset 0 1px 1px rgba(0, 0, 0, 0.075);background-color:#fff;border:1px
solid #e3e3e3;-webkit-transition:border linear 0.2s, box-shadow linear 0.2s;-moz-transition:border linear 0.2s, box-shadow linear 0.2s;-o-transition:border linear 0.2s, box-shadow linear 0.2s;transition:border linear 0.2s, box-shadow linear 0.2s;cursor:text}.tool-card [contenteditable=true]:focus{outline:0;border-radius:4px;box-shadow:inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(82, 168, 236, 0.6);background-color:#fff;border:1px
solid rgba(82, 168, 236, 0.8);-webkit-transition:border linear 0.2s, box-shadow linear 0.2s;-moz-transition:border linear 0.2s, box-shadow linear 0.2s;-o-transition:border linear 0.2s, box-shadow linear 0.2s;transition:border linear 0.2s, box-shadow linear 0.2s;cursor:text}.tool-card [contenteditable=true].loading+.overlay-container{border-radius:4px;display:block}.tool-card [contenteditable=true] + .overlay-container
.loader{display:inline-block;vertical-align:middle}#contentframe{border:1px
solid #ddd;border-radius:4px}#page-mod-offlinequiz-attempt #page .controls,
#page-mod-offlinequiz-summary #page .controls,
#page-mod-offlinequiz-review #page
.controls{text-align:center;margin:8px
auto}#page-mod-offlinequiz-attempt .submitbtns,
#page-mod-offlinequiz-review
.submitbtns{clear:left;text-align:left;padding-top:1.5em}#page-mod-offlinequiz-review
.noticebox{background-color:#FFA;border-color:#FB3232;border-width:3px;color:#000;margin-top:15px}body.jsenabled
.questionflagcheckbox{display:none}.generalbox#passwordbox{width:70%;margin-left:auto;margin-right:auto}#passwordform{margin:1em
0}#offlinequiznojswarning{color:red}#offlinequiznojswarning{font-size:0.7em;line-height:1.1}.jsenabled
#offlinequiznojswarning{display:none}.path-mod-offlinequiz #user-picture{margin:0.5em 0}.path-mod-offlinequiz #user-picture
img{width:auto;height:auto;float:left}.path-mod-offlinequiz
.qnbutton{display:block;position:relative;float:left;width:1.5em;height:1.5em;overflow:hidden;margin:0.3em 0.3em 0.3em 0;padding:0;border:1px
solid #bbb;background:#ddd;text-align:center;vertical-align:middle;line-height:1.5em !important;font-weight:bold;text-decoration:none}.path-mod-offlinequiz .qnbutton:hover{text-decoration:underline}.path-mod-offlinequiz .qnbutton
span{cursor:pointer;cursor:hand}.path-mod-offlinequiz .qnbutton .trafficlight,
.path-mod-offlinequiz .qnbutton
.thispageholder{display:block;position:absolute;top:0;bottom:0;left:0;right:0}.path-mod-offlinequiz
.qnbutton.thispage{border-color:#666}.path-mod-offlinequiz .qnbutton.thispage
.thispageholder{border:1px
solid #666}.path-mod-offlinequiz .qnbutton.flagged
.trafficlight{background:url(/sunguru/theme/image.php/archaius/offlinequiz/1531975376/navflagged) no-repeat top right}.path-mod-offlinequiz .qnbutton.notyetanswered,
.path-mod-offlinequiz .qnbutton.requiresgrading,
.path-mod-offlinequiz
.qnbutton.invalidanswer{background-color:white}.path-mod-offlinequiz
.qnbutton.correct{background-color:#cfc}.path-mod-offlinequiz .qnbutton.correct
.trafficlight{border-bottom:3px solid #080}.path-mod-offlinequiz
.qnbutton.partiallycorrect{background-color:#ffa}.path-mod-offlinequiz .qnbutton.notanswered,
.path-mod-offlinequiz
.qnbutton.incorrect{background-color:#fcc}.path-mod-offlinequiz .qnbutton.notanswered .trafficlight,
.path-mod-offlinequiz .qnbutton.incorrect
.trafficlight{border-top:3px solid #800}.path-mod-offlinequiz
.othernav{clear:both;margin:0.5em 0}.path-mod-offlinequiz .othernav a,
.path-mod-offlinequiz .othernav
input{display:block;margin:0.5em 0}#offlinequiz-timer{display:none;margin-top:1em}#offlinequiz-time-left{font-weight:bold}#offlinequiz-timer.timeleft15{background:#fff}#offlinequiz-timer.timeleft14{background:#fee}#offlinequiz-timer.timeleft13{background:#fdd}#offlinequiz-timer.timeleft12{background:#fcc}#offlinequiz-timer.timeleft11{background:#fbb}#offlinequiz-timer.timeleft10{background:#faa}#offlinequiz-timer.timeleft9{background:#f99}#offlinequiz-timer.timeleft8{background:#f88}#offlinequiz-timer.timeleft7{background:#f77}#offlinequiz-timer.timeleft6{background:#f66}#offlinequiz-timer.timeleft5{background:#f55}#offlinequiz-timer.timeleft4{background:#f44}#offlinequiz-timer.timeleft3{background:#f33}#offlinequiz-timer.timeleft2{background:#f22}#offlinequiz-timer.timeleft1{background:#f11}#offlinequiz-timer.timeleft0{background:#f00}#page-mod-offlinequiz-mod #reviewoptionshdr
.fitem{width:23%;margin-left:10px}#page-mod-offlinequiz-mod #reviewoptionshdr
fieldset.fgroup{width:100%;text-align:left;margin-left:0}#page-mod-offlinequiz-mod #reviewoptionshdr .fitem,
#adminofflinequizreviewoptions
.group{float:left;width:33%;clear:none}#page-mod-offlinequiz-mod #reviewoptionshdr .fitemtitle,
#adminofflinequizreviewoptions
.fitemtitle{width:100%;font-weight:bold;text-align:left;height:2.5em;margin-left:0}#page-mod-offlinequiz-mod #reviewoptionshdr fieldset.fgroup,#adminofflinequizreviewoptions{clear:left}#page-mod-offlinequiz-mod #reviewoptionshdr fieldset.fgroup span,
#adminofflinequizreviewoptions
span{float:left;clear:left;margin:0.1em 0}#page-mod-offlinequiz-mod #reviewoptionshdr fieldset.fgroup span label,
#adminofflinequizreviewoptions span
label{margin-left:0.4em}#page-mod-offlinequiz-mod.dir-rtl #reviewoptionshdr .fitem,
#adminofflinequizreviewoptions
.group{float:right;width:24%}#page-mod-offlinequiz-mod.dir-rtl #reviewoptionshdr fieldset.fgroup span,
#adminofflinequizreviewoptions
span{float:right;clear:right}#page-mod-offlinequiz-mod.dir-rtl #reviewoptionshdr .fitemtitle,
#adminofflinequizreviewoptions
.fitemtitle{text-align:right}#page-mod-offlinequiz-participants
a.editlistlink{margin-left:3px}#page-mod-offlinequiz-participants
a.deletelistlink{margin-left:3px}#page-mod-offlinequiz-view .offlinequizinfo,
#page-mod-offlinequiz-view h2.main,
#page-mod-offlinequiz-createquiz h2.main,
#page-mod-offlinequiz-report h2.main,
#page-mod-offlinequiz-participants h2.main,
#page-mod-offlinequiz-review h2.main,
#page-mod-offlinequiz-tutorial-index h2.main,
#page-mod-offlinequiz-view #page .offlinequizgradefeedback,
#page-mod-offlinequiz-view #page
.offlinequizattempt{text-align:center}#page-mod-offlinequiz-view #page .offlinequizattemptsummary td
p{margin-top:0}table.offlinequizattemptsummary .bestrow
td{background-color:#e8e8e8}table.offlinequizattemptsummary
.noreviewmessage{color:gray}#page-mod-offlinequiz-view
.generaltable.offlinequizattemptsummary{margin-left:auto;margin-right:auto}#page-mod-offlinequiz-view
.generalbox#feedback{width:70%;margin-left:auto;margin-right:auto;padding-bottom:15px}#page-mod-offlinequiz-view .generalbox#feedback
h2{margin:0}#page-mod-offlinequiz-view .generalbox#feedback
h3{text-align:left}#page-mod-offlinequiz-view .generalbox#feedback
.overriddennotice{text-align:center;font-size:0.7em}.offlinequizstartbuttondiv.offlinequizsecuremoderequired
input{display:none}.jsenabled .offlinequizstartbuttondiv.offlinequizsecuremoderequired
input{display:inline}.mod-offlinequiz .gradedattempt,
.mod-offlinequiz tr.gradedattempt
td{background-color:#e8e8e8}.offlinequizattemptcounts{clear:left;text-align:center}#page-mod-offlinequiz-summary
#content{text-align:center}#page-mod-offlinequiz-summary
.questionflag{width:16px;height:16px;vertical-align:middle}#page-mod-offlinequiz-summary #offlinequiz-timer{text-align:center;margin-top:1em}#page-mod-offlinequiz-summary
.submitbtns{margin-top:1.5em}@media
print{.offlinequiz-secure-window
*{display:none !important}}table.offlinequizreviewsummary{width:100%}table.offlinequizreviewsummary
th.cell{padding:1px
0.5em 1px 1em;font-weight:bold;text-align:right;width:10em;background:#f0f0f0}table.offlinequizreviewsummary
td.cell{padding:1px
1em 1px 0.5em;text-align:left;background:#fafafa}#page-mod-offlinequiz-comment
.mform{width:100%}#page-mod-offlinequiz-comment .mform
fieldset{margin:0}#page-mod-offlinequiz-comment
.que{margin:0}#page-mod-offlinequiz-report
h2.main{clear:both}#page-mod-offlinequiz-report .tabtree .tabrow1 li a,
#page-mod-offlinequiz-participants .tabtree .tabrow1 li a,
#page-mod-offlinequiz-createquiz .tabtree .tabrow1 li a,
#page-mod-offlinequiz-report .tabtree .tabrow1 li a.nolink,
#page-mod-offlinequiz-participants .tabtree .tabrow1 li a.nolink,
#page-mod-offlinequiz-createquiz .tabtree .tabrow1 li a.nolink,
#page-mod-offlinequiz-report div#commands,
#page-mod-offlinequiz-report
.controls{text-align:center}#page-mod-offlinequiz-report
.dubious{background-color:#fcc}#page-mod-offlinequiz-report
.highlight{border:medium solid yellow;background-color:lightYellow}#page-mod-offlinequiz-report
.negcovar{border:medium solid pink;width:70%;float:right}#page-mod-offlinequiz-report
.toggleincludeauto{text-align:center}#page-mod-offlinequiz-report
.gradetheselink{font-size:0.8em}#page-mod-offlinequiz-report .mform
fieldset{margin:0}#page-mod-offlinequiz-report
fieldset.felement.fgroup{margin:0}#page-mod-offlinequiz-report table.titlesleft
td.c0{font-weight:bold}#page-mod-offlinequiz-report table
.numcol{text-align:center;vertical-align:middle !important}#page-mod-offlinequiz-report
table#attempts{clear:both;width:80%;margin:0.2em auto}#page-mod-offlinequiz-report table#attempts .header,
#page-mod-offlinequiz-report table#attempts
.cell{padding:4px}#page-mod-offlinequiz-report table#attempts .header
.commands{display:inline}#page-mod-offlinequiz-report table#attempts
.picture{width:40px}#page-mod-offlinequiz-report table#attempts
td{border-left-width:1px;border-right-width:1px;border-left-style:solid;border-right-style:solid;vertical-align:middle;border-color:#DDD}#page-mod-offlinequiz-report table#attempts
th.userkey{text-align:center}#page-mod-offlinequiz-report table#attempts
td.userkey{text-align:center}#page-mod-offlinequiz-report table#attempts
th.timestart{text-align:center}#page-mod-offlinequiz-report table#attempts
td.timestart{text-align:center}#page-mod-offlinequiz-report table#attempts
th.offlinegroupid{text-align:center}#page-mod-offlinequiz-report table#attempts
td.offlinegroupid{text-align:center}#page-mod-offlinequiz-report table#attempts
th.sumgrades{text-align:right}#page-mod-offlinequiz-report table#attempts
td.sumgrades{text-align:right}#page-mod-offlinequiz-report table#attempts
.header{text-align:left}#page-mod-offlinequiz-report table#attempts
.picture{text-align:center !important}#page-mod-offlinequiz-report table#attempts.grades span.que,
#page-mod-offlinequiz-report table#attempts
span.avgcell{white-space:nowrap}#page-mod-offlinequiz-report table#attempts span.que
.requiresgrading{white-space:normal}#page-mod-offlinequiz-report table#attempts
.questionflag{width:16px;height:16px;vertical-align:middle}#page-mod-offlinequiz-report .graph.flexible-wrap{text-align:center;overflow:auto}#page-mod-offlinequiz-report
#cachingnotice{margin-bottom:1em;padding:0.2em}#page-mod-offlinequiz-report #cachingnotice
.singlebutton{margin:0.5em 0 0}#page-mod-offlinequiz-report .bold
.reviewlink{font-weight:normal}#page-mod-offlinequiz-report
div.notify{text-align:center}#page-mod-offlinequiz-report
div.notifynote{color:#04b}#page-mod-offlinequiz-report
div.backlinkbox{padding-top:10px}#page-mod-offlinequiz-report table.errorpages td.checkbox
input{margin-left:0px;float:none}#adminofflinequizreviewoptions{margin-bottom:0.5em}.linkbox{text-align:center}#page-mod-offlinequiz-createquiz
div.notify{text-align:center}#page-mod-offlinequiz-createquiz
div.preview{padding:10px
10px 10px 30px;text-align:left;width:96%}#page-mod-offlinequiz-createquiz div.preview div.question
span.number{font-weight:bold;text-align:left}#page-mod-offlinequiz-createquiz div.preview
div.question{float:left;padding:5px;text-align:left;width:80%}#page-mod-offlinequiz-createquiz div.preview
div.grade{float:right;padding:5px;text-align:right;width:10%}#page-mod-offlinequiz-createquiz div.preview
div.answer{clear:both;padding:5px
5px 5px 52px;text-align:left;text-indent:-22px;width:90%}#page-mod-offlinequiz-createquiz
div.docsbox{border-bottom:1px solid #e3e3e3;clear:both}#page-mod-offlinequiz-createquiz
div.downloadalllink{float:right}#page-mod-offlinequiz-report .errorpages .checkbox,
#page-mod-offlinequiz-report .errorpages .page,
#page-mod-offlinequiz-report .errorpages .error,
#page-mod-offlinequiz-report .errorpages .time,
#page-mod-offlinequiz-report .errorpages
.counter{text-align:center}#page-mod-offlinequiz-report .errorpages
.username{text-align:left}#page-mod-offlinequiz-mod.dir-rtl #reviewoptionshdr .fitem, .dir-rtl  #adminofflinequizreviewoptions
.group{width:23%;float:right}#page-mod-offlinequiz-mod.dir-rtl #reviewoptionshdr .fitemtitle, .dir-rtl  #adminofflinequizreviewoptions
.fitemtitle{text-align:right}#page-mod-offlinequiz-mod.dir-rtl #reviewoptionshdr fieldset.fgroup span, .dir-rtl  #adminofflinequizreviewoptions
span{clear:right;float:right}}#page-mod-offlinequiz-createquiz div.answer
img.texrender{vertical-align:middle}#page-mod-offlinequiz-report
div.notifynote{color:#069}#page-mod-offlinequiz-report
table#statsoverviewtable{border:1px
solid #DDD;width:50%}#page-mod-offlinequiz-report table#statsoverviewtable
.r1{background-color:#F2F2F2}#page-mod-offlinequiz-report
table#questionstatstable{border:1px
solid #DDD;width:30em}#page-mod-offlinequiz-report table#questionstatstable
.r1{background-color:#F2F2F2}#page-mod-offlinequiz-report table#questionstatstable tr
td.c0{width:50%}#page-mod-offlinequiz-report table#questionstatstable
.r1{background-color:#F2F2F2}#page-mod-offlinequiz-report
table#statisticsquestiontable{border:1px
solid #DDD;border-collapse:collapse;width:80%}#page-mod-offlinequiz-report table#statisticsquestiontable
.r1{background-color:#F2F2F2}#page-mod-offlinequiz-report
tr.redrow{color:red}#page-mod-offlinequiz-report
tr.greenrow{color:green}#page-mod-offlinequiz-report table#questionstatistics
th.header{border:1px
solid #DDD;border-collapse:collapse}#page-mod-offlinequiz-report div.no-overflow table#questionstatistics
td{border:1px
solid #DDD;border-collapse:collapse}#page-mod-offlinequiz-report table#questionstatistics
.r1{background-color:#F2F2F2}#page-mod-offlinequiz-report table#questionstatistics
.numcol{text-align:right}#page-mod-offlinequiz-report table#questionstatistics
.questiontext{color:#555}#page-mod-offlinequiz-report table#questionstatistics td.numcol
div.negcovar{position:relative;width:18em}#page-mod-offlinequiz-report table#questionstatistics
td.cell{border:1px
solid #DDD;border-collapse:collapse}#page-mod-offlinequiz-report div.no-overflow table#statisticsquestiontable
th.header{border:1px
solid #DDD;border-collapse:collapse}#page-mod-offlinequiz-report div.no-overflow table#statisticsquestiontable
td{border:1px
solid #DDD;border-collapse:collapse}#page-mod-offlinequiz-report table#questionstatistics
div.commands{float:right}#page-mod-offlinequiz-report table#questionstatistics
td.correct{display:none}#page-mod-offlinequiz-report table#questionstatistics
td.partially{display:none}#page-mod-offlinequiz-report table#questionstatistics
td.wrong{display:none}#page-mod-offlinequiz-report table#questionstatistics
th.correct{display:none}#page-mod-offlinequiz-report table#questionstatistics
th.partially{display:none}#page-mod-offlinequiz-report table#questionstatistics
th.wrong{display:none}.Popup{display:none;background:#fff;left:50%;margin-left:-250px;position:fixed;top:10px;width:600px;height:800px;z-index:3;box-shadow:0 0 10px #222;padding:10px}#overlay{display:none;background:-moz-radial-gradient(center, ellipse cover,  rgba(0,0,0,0.65) 0%, rgba(0,0,0,0.5) 100%);background:-webkit-gradient(radial, center center, 0px, center center, 100%, color-stop(0%,rgba(0,0,0,0.65)), color-stop(100%,rgba(0,0,0,0.5)));background:-webkit-radial-gradient(center, ellipse cover,  rgba(0,0,0,0.65) 0%,rgba(0,0,0,0.5) 100%);background:-o-radial-gradient(center, ellipse cover,  rgba(0,0,0,0.65) 0%,rgba(0,0,0,0.5) 100%);background:-ms-radial-gradient(center, ellipse cover,  rgba(0,0,0,0.65) 0%,rgba(0,0,0,0.5) 100%);: radial-gradient(ellipse at center,  rgba(0,0,0,0.65) 0%,rgba(0,0,0,0.5) 100%);filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#a6000000', endColorstr='#80000000',GradientType=1 );width:100%;height:100%;position:fixed;z-index:2;top:0px;left:0px}input#showviewbutton{display:none}.jsenabled
input#showviewbutton{float:right;display:block}#page-mod-offlinequiz-edit
h2.main{display:inline;padding-right:1em;clear:left}#page-mod-offlinequiz-edit.dir-rtl
h2.main{padding-left:1em;padding-right:0}#page-mod-offlinequiz-edit
.statusdisplay{background-color:#ffc;clear:both;margin:0.3em 1em 0.3em 0;padding:1px
}#page-mod-offlinequiz-edit
.emptystatusdisplay{clear:both;margin:0.3em 1em 0.3em 0}#page-mod-offlinequiz-edit.dir-rtl
.statusdisplay{margin:0.3em 0 0.3em 1em}#page-mod-offlinequiz-edit .statusdisplay
p{margin:0.4em}#page-mod-offlinequiz-edit li.activity > div,
#page-mod-offlinequiz-edit
li.pagenumber{position:relative}#page-mod-offlinequiz-edit .last-add-menu{position:relative;height:1.5em}#page-mod-offlinequiz-edit .add-menu-outer{position:absolute;top:0;right:0}#page-mod-offlinequiz-edit.dir-rtl .add-menu-outer{right:auto;left:0}#page-mod-offlinequiz-edit
.slotnumber{background-color:#D3D3D3;text-align:center;margin:0.1em 0.5em;min-width:2em;display:inline-block}#page-mod-offlinequiz-edit ul.slots
li.section{border:0}#page-mod-offlinequiz-edit ul.slots li.section
.content{background-color:#FAFAFA;padding:5px
10px}#page-mod-offlinequiz-edit ul.slots li.section .content
h3{margin:0;color:#777;font-weight:normal}#page-mod-offlinequiz-edit ul.slots li.section
.left{padding:4px
0}#page-mod-offlinequiz-edit ul.slots li.section
.right{padding:4px
0}#page-mod-offlinequiz-edit
ul.slots{margin:0;clear:both}#page-mod-offlinequiz-edit ul.slots
li.section{list-style:none;margin:0
0 5px 0;padding:0}#page-mod-offlinequiz-edit ul.slots li.section
.left{float:left}#page-mod-offlinequiz-edit ul.slots li.section
.right{float:right}#page-mod-offlinequiz-edit ul.slots li.section .left,
#page-mod-offlinequiz-edit ul.slots li.section
.right{width:40px;text-align:center;padding:6px
0}#page-mod-offlinequiz-edit ul.slots li.section .right
img.icon{padding:0
0 4px 0}#page-mod-offlinequiz-edit ul.slots li.section .left .section-handle
img.icon{padding:0;vertical-align:baseline}#page-mod-offlinequiz-edit ul.slots li.section
li.activity{background:#E6E6E6;margin:3px
0 3px 0;padding:0.2em}#page-mod-offlinequiz-edit ul.slots li.section
li.activity.page{background:transparent}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmarkcontainer{background:white;padding:0.2em;margin:0.4em}#page-mod-offlinequiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer
.editicon{width:13px}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmarkcontainer.infoitem{background:transparent}#page-mod-offlinequiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer
form{display:inline}#page-mod-offlinequiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer form
input{margin:0;padding:0.2em;height:1em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark{display:inline-block;text-align:right}#page-mod-offlinequiz-edit.dir-rtl ul.slots li.section li.activity
.instancemaxmark{text-align:left}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.page_split_join_wrapper{position:absolute}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.page_split_join{position:relative;left:-20px;top:-7px}#page-mod-offlinequiz-edit.dir-rtl ul.slots li.section li.activity
.page_split_join{left:auto;right:-20px}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_0{min-width:1.3em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_1{min-width:2em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_2{min-width:2.6em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_3{min-width:3.2em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_4{min-width:3.7em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_5{min-width:4.3em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_6{min-width:4.8em}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_7{min-width:5.45em}#page-mod-offlinequiz-edit ul.slots li.section li.activity .edit_icon,
#page-mod-offlinequiz-edit ul.slots li.section li.activity a.preview,
#page-mod-offlinequiz-edit ul.slots li.section li.activity .editing_delete,
#page-mod-offlinequiz-edit ul.slots li.section li.activity
.editing_maxmark{margin:0
2px}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.question_checkbox{position:absolute;left:0px}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.editing_move{left:15px}#page-mod-offlinequiz-edit ul.slots li.section li.activity
.activityinstance{display:block;min-height:1.7em;position:absolute;top:0;left:6em;width:85%}#page-mod-offlinequiz-edit ul.slots li.section li.activity.forgrading
.activityinstance{left:3em}#page-mod-offlinequiz-edit.dir-rtl ul.slots li.section li.activity
.activityinstance{left:auto;right:5em}#page-mod-offlinequiz-edit ul.slots li.section li.activity .mod-indent-outer{padding-left:35px}#page-mod-offlinequiz-edit ul.slots li.section li.activity.forgrading .mod-indent-outer{padding-left:4px}#page-mod-offlinequiz-edit.dir-rtl ul.slots li.section li.activity .mod-indent-outer{padding-left:0;padding-right:22px}#page-mod-offlinequiz-edit ul.slots .activityinstance
form{display:inline}#page-mod-offlinequiz-edit
span.editinstructions{right:0}#page-mod-offlinequiz-edit.dir-rtl
span.editinstructions{left:0;right:auto}#page-mod-offlinequiz-edit div.rpcontainerclass
input{margin-left:0em;margin-top:0.2em}#page-mod-offlinequiz-edit
div.groupchoice{float:left;margin:0.5em 1.5em 0.7em 0em}#page-mod-offlinequiz-edit
.clear{clear:both}#page-mod-offlinequiz-edit
.statusbar{float:left;margin:0.6em 0em 0.6em 0em}#page-mod-offlinequiz-edit
.maxgrade{display:block;float:right;margin:-2.5em 1em 0em 1em;padding: .2em}#page-mod-offlinequiz-edit
.maxgrade{position:relative;top:2.2em}#page-mod-offlinequiz-edit .maxgrade
label{display:inline}#page-mod-offlinequiz-edit .edit_grades
.maxgrade{margin:-5em 1em 0em 1em;top:0em}#page-mod-offlinequiz-edit
.totalpoints{display:block;float:right;margin:-3.5em 1em 0em 1em;padding: .2em}#page-mod-offlinequiz-edit .edit_grades
.totalpoints{display:block;float:right;margin:-2em 1em 0em 1em;padding: .2em}#page-mod-offlinequiz-edit.dir-rtl .maxgrade,
#page-mod-offlinequiz-edit.dir-rtl
.totalpoints{float:left}#page-mod-offlinequiz-edit
div.selectall{display:inline-block;margin-right:2em;clear:both}#page-mod-offlinequiz-edit
div.copyselected{display:inline-block}#page-mod-offlinequiz-edit
div.removeselected{display:inline-block;float:right}#page-mod-offlinequiz-edit div.removeselected
input{margin-left:0px}#page-mod-offlinequiz-edit div.randomquestionformforpopup input[type="checkbox"]{vertical-align:text-bottom}#page-mod-offlinequiz-edit ul.slots .activityinstance
span.instancename{overflow-x:hidden;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;word-break:break-word;width:90%;display:inline-block;height:20px}#page-mod-offlinequiz-edit ul.slots .activityinstance span.instancename
img{margin:0
0.2em}#page-mod-offlinequiz-edit #categoryquestions .questionname,
#page-mod-offlinequiz-edit ul.slots li.activity div.activityinstance
.questionname{font-weight:bold;color:#555;margin-right:0.5em;vertical-align:middle}#page-mod-offlinequiz-edit ul.slots li.activity div.activityinstance
.questiontext{color:#555;vertical-align:middle}#page-mod-offlinequiz-edit ul.slots li.activity div.activityinstance
.mod_offlinequiz_random_qbank_link{font-size:0.8em}#page-mod-offlinequiz-edit ul.slots .activityinstance
img.activityicon{float:left;margin: .2em 0 0;padding:0}#page-mod-offlinequiz-edit.dir-rtl ul.slots .activityinstance
img.activityicon{float:right}#page-mod-offlinequiz-edit .section .activity
.actions{white-space:nowrap;background:#e6e6e6;padding:0.1em 0;margin-left:0.2em}#page-mod-offlinequiz-edit .section .activity.forgrading .actions
input.gradeinput{margin:0px;padding:0px
2px 0px 0px;text-align:right;vertical-align:top}#page-mod-offlinequiz-edit
.mod_offlinequiz_edit_forms{display:none}#categoryquestions>tbody>tr:nth-of-type(even){background:#e4e4e4}#categoryquestions>tbody>tr:nth-of-type(even).highlight{background-color:#AFA}#categoryquestions
.header{text-align:center;padding:0
2px;border:0
none}#categoryquestions th.modifiername .sorters,
#categoryquestions th.creatorname
.sorters{font-weight:normal;font-size:0.8em}table#categoryquestions{width:100%;overflow:hidden;table-layout:fixed}#categoryquestions
.iconcol{width:15px;text-align:center;padding:0}#categoryquestions
.checkbox{width:19px;text-align:center;padding:0}#categoryquestions
.qtype{text-align:center}#categoryquestions
.qtype{width:28px;padding:0}#categoryquestions
.questiontext{position:relative;zoom:1;padding-left:0.3em;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}#page-mod-offlinequiz-edit #categoryquestions .questionnametext .greyed,
#page-mod-offlinequiz-edit #categoryquestions .addtoofflinequizaction .greyed,
#page-mod-offlinequiz-edit #categoryquestions .qtype
.greyed{opacity:0.4}.dir-rtl #categoryquestions
.questiontext{padding-left:0;padding-right:0.3em}#categoryquestions
.questionname{white-space:nowrap;overflow:hidden;zoom:1;position:relative}#categoryquestions .questiontext
p{margin:0}#page-mod-offlinequiz-edit table#categoryquestions td,
#page-mod-offlinequiz-edit table#categoryquestions
th{overflow:hidden;white-space:nowrap}.mod_offlinequiz_qbank_dialogue{width:80%;min-height:200px}.mod_offlinequiz_qbank_dialogue.moodle-dialogue-fullscreen{width:100%}.mod_offlinequiz_qbank_dialogue
.questionbankloading{position:absolute;top:30px;bottom:0;left:0;right:0;background:#fff;text-align:center;opacity:0.5;padding-top:50px}.modulespecificbuttonscontainer{padding-left:0.3em;padding-right:0.3em}.offlinequizquestionlistcontrols{text-align:center}.categoryinfo{padding:0.3em}.path-mod-offlinequiz
.gradingdetails{font-size:small}#page-mod-offlinequiz-edit div#repaginatedialog
.mform{margin-left:auto;margin-right:auto}#page-mod-offlinequiz-edit div.container
div.generalbox{position:relative;display:block;border:0
none;margin:0;padding:0}#page-mod-offlinequiz-edit
.paging{margin-top:0;margin-bottom:0;padding:0.1em 0.3em;display:block;background-color:#ddd}#page-mod-offlinequiz-edit #page-footer{clear:both;padding-top:1em}#page-mod-offlinequiz-edit
.categoryinfofield{font-style:italic}#page-mod-offlinequiz-edit
.categorynamefield{font-weight:bold}#page-mod-offlinequiz-edit
.questionsortoptions{background-color:#ddd}#page-mod-offlinequiz-edit div.questionbank
.categorysortopotionscontainer{padding-top:0.5em;margin-top:0.3em}#page-mod-offlinequiz-edit div.questionbank .categoryquestionscontainer,
.questionbank .categorysortopotionscontainer,
.questionbank .categorypagingbarcontainer,
.questionbank
.categoryselectallcontainer{background-color:#FFF}#page-mod-offlinequiz-edit ul.slots li.section
ul.section{list-style:none}@media only screen and (max-width: 62em){#page-mod-offlinequiz-edit
.totalpoints{margin:-2em 1em 0em 1em}#page-mod-offlinequiz-edit
.maxgrade{margin-bottom:1.5em}}@media only screen and (min-width: 50em) and (max-width: 60em){#page-mod-offlinequiz-edit
div.removeselected{margin-top:-0.5em}}#page-mod-questionnaire-questions .qcontainer .fitemtitle,
#page-mod-questionnaire-questions #id_questionhdr
.fitemtitle{display:none!important}#page-mod-questionnaire-questions .qcontainer
.qnums{font-weight:bold;float:left;color:gray}#page-mod-questionnaire-questions .qcontainer
.fstatic{width:97%;margin-right:1em;margin-left:5px;margin-bottom:-10px}#page-mod-questionnaire-questions .mform .fitem
fieldset.felement{margin-left:0%;padding-left:1%;margin-bottom:0px!important}#page-mod-questionnaire-preview fieldset,
#page-mod-questionnaire-complete
fieldset{margin-bottom:0px!important}#page-mod-questionnaire-questions .mform .fitem
.fitemtitle{text-align:left;margin-left:10px;margin-bottom:0px!important}#page-mod-questionnaire-questions
.moving{border:medium dotted maroon}div.qoptcontainer
div.ftextarea{clear:all;float:none;width:600px;margin:0pt auto 10px}div.qoptcontainer div.ftextarea
textarea.qopts{width:600px;height:10em;margin-left:1px}.response span.selected,
.generalboxcontent
span.selected{font-weight:bold}td.selected{background-color:#e4f1fa;border:1px
solid gray}#page-mod-questionnaire-myreport
div.respdate{font-size:0.8em;font-weight:bold;margin-bottom:6px;padding-top:6px;border-bottom:1px dashed gray}#page-mod-questionnaire-complete .message,
#page-mod-questionnaire-complete .notifyproblem,
#page-mod-questionnaire-preview .message,
#page-mod-questionnaire-preview .notifyproblem,
#page-mod-questionnaire-complete .thankbody,
#page-mod-questionnaire-complete
.thankhead{background-color:#FFF;border-style:solid;border-width:2px;margin-bottom:10px;padding:5px}#page-mod-questionnaire-complete .notifyproblem,
#page-mod-questionnaire-preview
.notifyproblem{border-color:red}#page-mod-questionnaire-fbsections
.notifyproblem{text-align:left;padding:0px}#page-mod-questionnaire-complete .message,
#page-mod-questionnaire-preview .message,
#page-mod-questionnaire-complete .thankbody,
#page-mod-questionnaire-complete
.thankhead{border-color:blue}#page-mod-questionnaire-complete .surveyTitle,
#page-mod-questionnaire-complete .surveySubtitle,
#page-mod-questionnaire-complete
.addInfo{clear:both;margin:0px;margin-bottom:4px;padding:10px}.surveyPage{background-color:#eee;border-bottom-color:#000;border-bottom-style:solid;border-bottom-width:1px;clear:right;padding:3px;margin-bottom:5px;margin-top:0px}#page-mod-questionnaire-complete .c0,
#page-mod-questionnaire-preview .c0,
#page-mod-questionnaire-print .c0,
#page-mod-questionnaire-report .individual .c0,
#page-mod-questionnaire-myreport .individual
.c0{background-color:#fafafa;border:1px
solid silver;padding-left:5px;padding-right:5px}#page-mod-questionnaire-complete .raterow:hover,
#page-mod-questionnaire-preview .raterow:hover{background-color:#e4f1fa}#page-mod-questionnaire-complete td.raterow:hover,
#page-mod-questionnaire-preview td.raterow:hover{border:1px
solid navy}#page-mod-questionnaire-complete td.notanswered,
#page-mod-questionnaire-preview
td.notanswered{background-color:#fafafa;}#page-mod-questionnaire-complete td.notcompleted,
#page-mod-questionnaire-preview
td.notcompleted{border:2px
solid red;background-color:#fafafa}#page-mod-questionnaire-complete .c1,
#page-mod-questionnaire-preview .c1,
#page-mod-questionnaire-print .c1,
#page-mod-questionnaire-report .individual .c1,
#page-mod-questionnaire-myreport .individual
.c1{background-color:#eee;border:1px
solid silver;padding-left:5px;padding-right:5px}#page-mod-questionnaire-myreport .individualresp,
#page-mod-questionnaire-preview .individualresp,
#page-mod-questionnaire-print
.individualresp{border:#c0c0c0 1px solid;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:0px;margin-bottom:10px;margin-top:10px}#page-mod-questionnaire-complete .notice .buttons div,
#page-mod-questionnaire-complete .notice .buttons
form{display:inline}.floatprinticon{margin-top:-30px;float:right}.qn-legend{float:left;font-size:inherit;width:auto}.qn-question
p{margin-bottom:0.6em;margin-top:0.5em}.qn-question{padding-left:5px;padding-right:5px;padding-bottom:0.1em;padding-top:0.1em;background-color:#e4f1fa}#page-mod-questionnaire-questions .qn-question{margin-left:40px}.unselected{color:gray}#respondentscolumn{float:left;margin-left:20px}.respondentsnavbar{text-align:center;padding-bottom:5px;padding-top:5px;margin-bottom:5px;background-color:#F2F2F2}#page-mod-questionnaire-questions .qn-container{border:1px
dotted gray;margin-bottom:1em}.dir-rtl .qn-container{text-align:right}.qn-info{float:left;width:auto;padding:7px;background:#eee;font-weight:bold}.qn-info h2.qn-number{margin:0px;font-size:1.5em;line-height:1.2em}.qn-question,.qn-answer{margin:0
0 0.5em;overflow:auto}#notice .qn-question{margin:0}.req{font-size:x-small}.qdepend{color:red;padding-left:5px;margin-bottom:5px}.qn-content{margin-bottom:10px;margin-left:55px}.qn-answer input[type="radio"],
.qn-answer input[type="checkbox"]{margin-right:3px}#page-mod-questionnaire-show_nonrespondents input[type="radio"]{margin-right:1px}.qn-answer label,
#page-mod-questionnaire-show_nonrespondents
label{margin-right:0.6em}.hidedependquestion{color:red;display:none}.qn-container{color:black;display:inherit;margin-left:10px}#page-mod-questionnaire-fbsections .c0,
#page-mod-questionnaire-fbsections
.c1{border:1px
solid silver;padding-left:4px;padding-right:4px}#page-mod-questionnaire-fbsections
.c0{background-color:#fafafa}#page-mod-questionnaire-fbsections
.c1{background-color:#eee}#page-mod-questionnaire-fbsections input[type="radio"]{margin-right:0px}#page-mod-questionnaire-fbsections .qn-legend{padding-left:8px}#page-mod-questionnaire-fbsections
.qcontainer.qcontent{margin-bottom:-5em}#page-mod-questionnaire-report
div.chart{overflow:auto;margin-left:-40px}#page-mod-questionnaire-report .generaltable.questionnairereport
td{border:1px
solid silver}.qn-container
.smalltext{font-size:0.75em}#page-mod-questionnaire-questions #region-main .mform .fitem
.felement{margin-bottom:0px}.path-mod-quiz
.statedetails{display:block;font-size:0.7em}#page-mod-quiz-attempt #page .controls,
#page-mod-quiz-summary #page .controls,
#page-mod-quiz-review #page
.controls{text-align:center;margin:8px
auto}#page-mod-quiz-attempt .submitbtns,
#page-mod-quiz-review
.submitbtns{clear:left;text-align:left;padding-top:1.5em}#page-mod-quiz-attempt.dir-rtl .submitbtns,
#page-mod-quiz-review.dir-rtl
.submitbtns{text-align:right}#page-mod-quiz-attempt .submitbtns .mod_quiz-next-nav,
#page-mod-quiz-review .submitbtns .mod_quiz-next-nav{float:right}#page-mod-quiz-attempt.dir-rtl .submitbtns .mod_quiz-next-nav,
#page-mod-quiz-review.dir-rtl .submitbtns .mod_quiz-next-nav{float:left}.path-mod-quiz .mod_quiz-redo_question_button{margin:0}.path-mod-quiz input[type="submit"].mod_quiz-redo_question_button{padding:2px
0.8em;font-size:1em}#page-mod-quiz-attempt .mod_quiz-blocked_question_warning .que .formulation,
#page-mod-quiz-review .mod_quiz-blocked_question_warning .que
.formulation{background:#eee;border:1px
solid #dcdcdc}body.jsenabled
.questionflagcheckbox{display:none}#page-mod-quiz-attempt #connection-ok,
#page-mod-quiz-attempt #connection-error{position:fixed;top:0;width:80%;left:10%;color:#555;border-radius:0 0 10px 10px;box-shadow:5px 5px 20px 0 #666;padding:1em
1em 0;z-index:10000}#page-mod-quiz-attempt #connection-error{background-color:#fcc}#page-mod-quiz-attempt #connection-ok{background-color:#cfb;width:60%;left:20%}.generalbox#passwordbox{width:70%;margin-left:auto;margin-right:auto}#passwordform{margin:1em
0}#quiznojswarning{color:red}#quiznojswarning{font-size:0.7em;line-height:1.1}.jsenabled
#quiznojswarning{display:none}.path-mod-quiz #user-picture{margin:0.5em 0}.path-mod-quiz #user-picture
img{width:auto;height:auto;vertical-align:bottom}.path-mod-quiz #mod_quiz_navblock h3.mod_quiz-section-heading{padding:0.7em 0 0;margin:0;clear:both}.path-mod-quiz #mod_quiz_navblock h3.mod_quiz-section-heading:first-child{padding-top:0}.path-mod-quiz
.qnbutton{display:block;position:relative;float:left;width:1.5em;height:1.5em;overflow:hidden;margin:0.3em 0.3em 0.3em 0;padding:0;border:1px
solid #bbb;background:#ddd;text-align:center;vertical-align:middle;line-height:1.5em;font-weight:bold;text-decoration:none}.path-mod-quiz.dir-rtl
.qnbutton{float:right}.path-mod-quiz .qnbutton:visited:hover,
.path-mod-quiz .qnbutton:link:hover{text-decoration:underline}.path-mod-quiz .qnbutton .trafficlight,
.path-mod-quiz .qnbutton
.thispageholder{display:block;position:absolute;top:0;bottom:0;left:0;right:0}.path-mod-quiz
.qnbutton.thispage{border-color:#666}.path-mod-quiz .qnbutton.thispage
.thispageholder{border:1px
solid #666}.path-mod-quiz .qnbutton.flagged
.trafficlight{background:url(/sunguru/theme/image.php/archaius/quiz/1531975376/navflagged) no-repeat top right}.path-mod-quiz .qnbutton.blocked,
.path-mod-quiz .qnbutton.notyetanswered,
.path-mod-quiz .qnbutton.requiresgrading,
.path-mod-quiz
.qnbutton.invalidanswer{background-color:white}.path-mod-quiz
.qnbutton.correct{background-color:#cfc}.path-mod-quiz .qnbutton.correct
.trafficlight{border-bottom:3px solid #080}.path-mod-quiz
.qnbutton.partiallycorrect{background-color:#ffa}.path-mod-quiz .qnbutton.notanswered,
.path-mod-quiz
.qnbutton.incorrect{background-color:#fcc}.path-mod-quiz
.qnbutton.blocked{color:#999}.path-mod-quiz .qnbutton.notanswered .trafficlight,
.path-mod-quiz .qnbutton.incorrect
.trafficlight{border-top:3px solid #800}.path-mod-quiz
.othernav{clear:both;margin:0.5em 0}.path-mod-quiz .othernav a,
.path-mod-quiz .othernav
input{display:block;margin:0.5em 0}#quiz-timer{display:none;margin-top:1em}#quiz-time-left{font-weight:bold}#quiz-timer.timeleft15{background:#fff}#quiz-timer.timeleft14{background:#fee}#quiz-timer.timeleft13{background:#fdd}#quiz-timer.timeleft12{background:#fcc}#quiz-timer.timeleft11{background:#fbb}#quiz-timer.timeleft10{background:#faa}#quiz-timer.timeleft9{background:#f99}#quiz-timer.timeleft8{background:#f88}#quiz-timer.timeleft7{background:#f77}#quiz-timer.timeleft6{background:#f66}#quiz-timer.timeleft5{background:#f55}#quiz-timer.timeleft4{background:#f44}#quiz-timer.timeleft3{background:#f33}#quiz-timer.timeleft2{background:#f22}#quiz-timer.timeleft1{background:#f11}#quiz-timer.timeleft0{background:#f00}#page-mod-quiz-mod #id_reviewoptionshdr
.fitem{width:23%;margin-left:10px}#page-mod-quiz-mod #id_reviewoptionshdr
fieldset.fgroup{width:100%;text-align:left;margin-left:0}#page-mod-quiz-mod #id_reviewoptionshdr
.fitem{float:left;width:23%;clear:none}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitem{float:right}#page-mod-quiz-mod #id_reviewoptionshdr
.fitemtitle{width:100%;font-weight:bold;text-align:left;height:2.5em;margin-left:0}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitemtitle{text-align:right}#page-mod-quiz-mod #id_reviewoptionshdr
fieldset.fgroup{clear:left;margin:0
0 1em}#page-mod-quiz-mod #id_reviewoptionshdr fieldset.fgroup>span{float:left;clear:left;line-height:1.7}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr fieldset.fgroup>span{float:right;clear:right}#page-mod-quiz-mod #id_reviewoptionshdr fieldset.fgroup span
label{margin-left:0.4em}#page-mod-quiz-view .quizinfo,
#page-mod-quiz-view #page .quizgradefeedback,
#page-mod-quiz-view #page
.quizattempt{text-align:center}#page-mod-quiz-view #page .quizattemptsummary td
p{margin-top:0}#page-mod-quiz-view table.quizattemptsummary tr.bestrow
td{border-color:#bce8f1;background-color:#d9edf7}table.quizattemptsummary
.noreviewmessage{color:gray}#page-mod-quiz-view
.generaltable.quizattemptsummary{margin-left:auto;margin-right:auto}#page-mod-quiz-view
.generalbox#feedback{width:70%;margin-left:auto;margin-right:auto;padding-bottom:15px}#page-mod-quiz-view .generalbox#feedback
h2{margin:0}#page-mod-quiz-view .generalbox#feedback
h3{text-align:left}#page-mod-quiz-view.dir-rtl .generalbox#feedback
h3{text-align:center}#page-mod-quiz-view .generalbox#feedback
.overriddennotice{text-align:center;font-size:0.7em}.quizstartbuttondiv.quizsecuremoderequired
input{display:none}.jsenabled .quizstartbuttondiv.quizsecuremoderequired
input{display:inline}.quizattempt
#mod_quiz_preflight_form{display:none}#mod_quiz_preflight_form .femptylabel
.fitemtitle{display:none}#mod_quiz_preflight_form .femptylabel
.felement{margin:0;padding:0}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup{width:600px}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-wrap{overflow:hidden}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd{padding:0}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd #mod_quiz_preflight_form
legend{padding:0
10px;margin:0;border:0
none}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd #mod_quiz_preflight_form
.fitem{margin-left:10px}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd #mod_quiz_preflight_form
#fgroup_id_buttonar{padding:10px
0 0;margin:0}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-content .moodle-dialogue-ft{margin:0}.moodle-dialogue-bd #mod_quiz_preflight_form
fieldset.hidden{display:inherit;visibility:inherit}body.path-mod-quiz .gradedattempt,
body.path-mod-quiz table tbody tr.gradedattempt>td{border-color:#bce8f1;background-color:#d9edf7}.quizattemptcounts{clear:left;text-align:center;display:inline;margin-left:20%}.dir-rtl
.quizattemptcounts{margin-left:0;margin-right:20%}#page-mod-quiz-view .quizattemptcounts,
.dir-rtl #page-mod-quiz-view
.quizattemptcounts{display:block;margin-left:0;margin-right:0}#page-mod-quiz-summary
#content{text-align:center}#page-mod-quiz-summary
.questionflag{vertical-align:text-bottom}#page-mod-quiz-summary #quiz-timer{text-align:center;margin-top:1em}#page-mod-quiz-summary
.submitbtns{margin-top:1.5em}@media
print{.quiz-secure-window
*{display:none !important}}table.quizreviewsummary{width:100%}table.quizreviewsummary
th.cell{padding:1px
0.5em 1px 1em;font-weight:bold;text-align:right;width:10em;background:#f0f0f0}table.quizreviewsummary
td.cell{padding:1px
1em 1px 0.5em;text-align:left;background:#fafafa}.dir-rtl table.quizreviewsummary
td.cell{text-align:right}#page-mod-quiz-comment
.mform{width:100%}#page-mod-quiz-comment .mform
fieldset{margin:0}#page-mod-quiz-comment
.que{margin:0}#page-mod-quiz-report
h2.main{clear:both}#page-mod-quiz-report div#commands,
#page-mod-quiz-report
.controls{text-align:center}#page-mod-quiz-report
.dubious{background-color:#fcc}#page-mod-quiz-report
.highlight{border:1px
solid #bce8f1;background-color:#d9edf7}#page-mod-quiz-report
.negcovar{border:medium solid pink}#page-mod-quiz-report
.toggleincludeauto{text-align:center}#page-mod-quiz-report
.gradetheselink{font-size:0.8em}#page-mod-quiz-report .mform fieldset.fgroup span
label{margin-right:14px}#page-mod-quiz-report table
th{white-space:normal}#page-mod-quiz-report table#attempts td,
#page-mod-quiz-report table.quizresponseanalysis
td{word-wrap:break-word;max-width:20em}#page-mod-quiz-report table.titlesleft
td.c0{font-weight:bold}#page-mod-quiz-report table
.numcol{text-align:center;vertical-align:middle !important}#page-mod-quiz-report
table#attempts{clear:both;width:80%;margin:0.2em auto}#page-mod-quiz-report table#attempts .header,
#page-mod-quiz-report table#attempts
.cell{padding:4px}#page-mod-quiz-report table#attempts .header
.commands{display:inline}#page-mod-quiz-report table#attempts
.picture{width:40px}#page-mod-quiz-report table#attempts
td{border-left-width:1px;border-right-width:1px;border-left-style:solid;border-right-style:solid;vertical-align:middle}#page-mod-quiz-report table#attempts
.header{text-align:left}#page-mod-quiz-report table#attempts
.picture{text-align:center !important}#page-mod-quiz-report table#attempts.grades span.que,
#page-mod-quiz-report table#attempts
span.avgcell{white-space:nowrap}#page-mod-quiz-report table#attempts span.que
.requiresgrading{white-space:normal}#page-mod-quiz-report table#attempts
.questionflag{vertical-align:text-bottom;padding-left:6px}.dir-rtl#page-mod-quiz-report table#attempts
.questionflag{padding-right:6px;padding-left:0}#page-mod-quiz-report .graph.flexible-wrap{text-align:center;overflow:auto}#page-mod-quiz-report
#cachingnotice{margin-bottom:1em;padding:0.2em}#page-mod-quiz-report #cachingnotice
.singlebutton{margin:0.5em 0 0}#page-mod-quiz-report .bold
.reviewlink{font-weight:normal}#page-mod-quiz-report
tr.lastrowforattempt{border-bottom:lightgrey solid 0.2em}#page-mod-quiz-edit
.statusbar{margin:0.6em 0.4em}#page-mod-quiz-edit
.statusdisplay{background-color:#ffc;clear:both;margin:0.3em 0;padding:1px
10px}#page-mod-quiz-edit .statusdisplay
p{margin:4px
0}#page-mod-quiz-edit .maxgrade,
#page-mod-quiz-edit
.totalpoints{display:block;float:right;margin:-2.85em 0 0;padding: .2em}#page-mod-quiz-edit.dir-rtl .maxgrade,
#page-mod-quiz-edit.dir-rtl
.totalpoints{float:left}#page-mod-quiz-edit .maxgrade
label{display:inline}#page-mod-quiz-edit li.activity > div,
#page-mod-quiz-edit
li.pagenumber{position:relative}#page-mod-quiz-edit ul.section li.pagenumber:first-child .add-menu-outer ul.menu li:first-child,
#page-mod-quiz-edit .last-add-menu .add-menu-outer ul.menu li:first-child{display:none}#page-mod-quiz-edit .last-add-menu{position:relative;height:1.5em;margin:0
20px}#page-mod-quiz-edit .add-menu-outer{position:absolute;right:0}#page-mod-quiz-edit.dir-rtl .add-menu-outer{right:auto;left:0}#page-mod-quiz-edit
.slotnumber{background-color:#D3D3D3;text-align:center;margin:0.1em 0.5em;min-width:2em;display:inline-block}#page-mod-quiz-edit .section-heading{font-size:24px;margin-left:20px;margin-bottom:0;height:40px}#page-mod-quiz-edit .section-heading
.instancesectioncontainer{display:inline}#page-mod-quiz-edit .section-heading .instancesectioncontainer
h3{display:inline;color:#999}#page-mod-quiz-edit .section-heading .editing_section,
#page-mod-quiz-edit .section-heading
.editing_delete{margin-left:10px}#page-mod-quiz-edit .section-heading
.sectioninstance{position:relative}#page-mod-quiz-edit .section-heading
.instancesection{white-space:nowrap;max-width:72%;display:inline-block;text-overflow:ellipsis;overflow:hidden;vertical-align:bottom}#page-mod-quiz-edit .section-heading
form{display:inline;position:relative;top:3px;left:-7px}#page-mod-quiz-edit .section-heading form
input{font-size:24px;font-weight:bold;width:50%}#page-mod-quiz-edit .section-heading
.instanceshufflequestions{float:right;margin:0.3em 20px 0 0}#page-mod-quiz-edit
ul.section{margin:0;padding:0
20px}#page-mod-quiz-edit
ul.slots{margin:0}#page-mod-quiz-edit ul.slots
li.section{border:0}#page-mod-quiz-edit ul.slots li.section
.content{background-color:#FAFAFA;padding:1px
0}#page-mod-quiz-edit ul.slots
li.section{list-style:none;margin:0;padding:0}#page-mod-quiz-edit ul.slots li.section
li.activity{background:#E6E6E6;margin:3px
0;padding:0.2em}#page-mod-quiz-edit ul.slots li.section
li.activity.page{background:transparent}#page-mod-quiz-edit ul.slots li.section li.activity.page
h4{display:inline;font-weight:normal;font-size:1em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmarkcontainer{background:white;padding:0.2em;margin:0.4em}#page-mod-quiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer
.editicon{width:13px}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmarkcontainer.infoitem{background:transparent}#page-mod-quiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer
form{display:inline}#page-mod-quiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer form
input{margin:0;padding:0.2em;height:1em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark{display:inline-block;text-align:right}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.instancemaxmark{text-align:left}#page-mod-quiz-edit ul.slots li.section li.activity
.page_split_join_wrapper{position:absolute}#page-mod-quiz-edit ul.slots li.section li.activity
.page_split_join{position:relative;left:-20px;top:-7px}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.page_split_join{left:auto;right:-20px}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_0{min-width:1.3em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_1{min-width:2em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_2{min-width:2.6em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_3{min-width:3.2em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_4{min-width:3.7em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_5{min-width:4.3em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_6{min-width:4.8em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_7{min-width:5.45em}#page-mod-quiz-edit ul.slots li.section li.activity .edit_icon,
#page-mod-quiz-edit ul.slots li.section li.activity a.preview,
#page-mod-quiz-edit ul.slots li.section li.activity .editing_delete,
#page-mod-quiz-edit ul.slots li.section li.activity
.editing_maxmark{margin:0
2px}#page-mod-quiz-edit ul.slots li.section.only-has-one-slot li.activity .editing_move,
#page-mod-quiz-edit ul.slots li.section.only-has-one-slot li.activity
.editing_delete{visibility:hidden}#page-mod-quiz-edit ul.slots.only-one-section li.section.only-has-one-slot li.activity
.editing_delete{visibility:visible}#page-mod-quiz-edit ul.slots li.section li.activity
.question_dependency_wrapper{position:absolute;top:0;right:0}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.question_dependency_wrapper{left:0;right:auto}#page-mod-quiz-edit ul.slots li.section li.activity
.question_dependency_wrapper.question_dependency_cannot_depend{display:none}#page-mod-quiz-edit ul.slots li.section li.activity .question_dependency_wrapper .currentlink,
#page-mod-quiz-edit ul.slots li.section li.activity .question_dependency_wrapper .cm-edit-action{position:relative;left:20px;top:-1em}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity .question_dependency_wrapper .currentlink,
#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity .question_dependency_wrapper .cm-edit-action{right:20px;left:auto}#page-mod-quiz-edit ul.slots li.section li.activity
.activityinstance{display:block;min-height:1.7em;position:absolute;top:0;left:5em;width:100%}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.activityinstance{left:auto;right:5em}#page-mod-quiz-edit ul.slots li.section li.activity .mod-indent-outer{padding-left:22px}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity .mod-indent-outer{padding-left:0;padding-right:22px}#page-mod-quiz-edit ul.slots .activityinstance
form{display:inline}#page-mod-quiz-edit
span.editinstructions{right:0}#page-mod-quiz-edit.dir-rtl
span.editinstructions{left:0;right:auto}#page-mod-quiz-edit ul.slots .activityinstance
span.instancename{overflow-x:hidden;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;word-break:break-word;width:70%;display:inline-block;height:20px}#page-mod-quiz-edit ul.slots .activityinstance span.instancename
img{margin:0
0.2em}#page-mod-quiz-edit #categoryquestions .questionname,
#page-mod-quiz-edit ul.slots li.activity div.activityinstance
.questionname{font-weight:bold;color:#555}#page-mod-quiz-edit ul.slots li.activity div.activityinstance
.questiontext{color:#555}#page-mod-quiz-edit ul.slots li.activity div.activityinstance
.mod_quiz_random_qbank_link{font-size:0.8em}#page-mod-quiz-edit ul.slots .activityinstance
img.activityicon{float:left;margin: .2em 0 0;padding:0}#page-mod-quiz-edit.dir-rtl ul.slots .activityinstance
img.activityicon{float:right}#page-mod-quiz-edit .section .activity
.actions{white-space:nowrap;background:#e6e6e6;padding:0.1em 0}#page-mod-quiz-edit
.mod_quiz_edit_forms{display:none}#categoryquestions>tbody>tr:nth-of-type(even){background:#e4e4e4}#categoryquestions>tbody>tr:nth-of-type(even).highlight{background-color:#AFA}#categoryquestions
.header{text-align:center;padding:0
2px;border:0
none}#categoryquestions th.modifiername .sorters,
#categoryquestions th.creatorname
.sorters{font-weight:normal;font-size:0.8em}#categoryquestions td.modifiername,
#categoryquestions
td.creatorname{line-height:1em}#categoryquestions td.modifiername span.date,
#categoryquestions td.creatorname
span.date{font-weight:normal;font-size:0.8em}table#categoryquestions{width:100%;overflow:hidden;table-layout:fixed}#categoryquestions
.iconcol{width:15px;text-align:center;padding:0}#categoryquestions
.checkbox{width:19px;text-align:center;padding:0}#categoryquestions
.qtype{text-align:center}#categoryquestions
.qtype{width:28px;padding:0}#categoryquestions
.questiontext{position:relative;zoom:1;padding-left:0.3em;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.dir-rtl #categoryquestions
.questiontext{padding-left:0;padding-right:0.3em}#categoryquestions
.questionname{white-space:nowrap;overflow:hidden;zoom:1;position:relative}#categoryquestions .questiontext
p{margin:0}#page-mod-quiz-edit table#categoryquestions td,
#page-mod-quiz-edit table#categoryquestions
th{overflow:hidden;white-space:nowrap}.mod_quiz_qbank_dialogue{width:80%;min-height:200px}.mod_quiz_qbank_dialogue.moodle-dialogue-fullscreen{width:100%}.mod_quiz_qbank_dialogue
.questionbankloading{position:absolute;top:30px;bottom:0;left:0;right:0;background:#fff;text-align:center;opacity:0.5;padding-top:50px}.mod_quiz_qbank_dialogue #advancedsearch
label{font-size:100%}.modulespecificbuttonscontainer{padding-left:0.3em;padding-right:0.3em}.quizquestionlistcontrols{text-align:center}.categoryinfo{padding:0.3em}.path-mod-quiz
.gradingdetails{font-size:small}#page-mod-quiz-edit div#repaginatedialog
.mform{margin-left:auto;margin-right:auto}#page-mod-quiz-edit div.container
div.generalbox{position:relative;display:block;border:0
none;margin:0;padding:0}#page-mod-quiz-edit
.paging{margin-top:0;margin-bottom:0;padding:0.1em 0.3em;display:block;background-color:#ddd}#page-mod-quiz-edit #page-footer{clear:both;padding-top:1em}#page-mod-quiz-edit
.categoryinfofield{font-style:italic}#page-mod-quiz-edit
.categorynamefield{font-weight:bold}#page-mod-quiz-edit
.questionsortoptions{background-color:#ddd}#page-mod-quiz-edit div.questionbank
.categorysortopotionscontainer{padding-top:0.5em;margin-top:0.3em}#page-mod-quiz-edit div.questionbank .categoryquestionscontainer,
.questionbank .categorysortopotionscontainer,
.questionbank .categorypagingbarcontainer,
.questionbank
.categoryselectallcontainer{background-color:#FFF}#page-mod-quiz-edit ul.slots li.section
ul.section{list-style:none}@media
print{#page-mod-quiz-attempt header.navbar,
#page-mod-quiz-review
header.navbar{display:none}#page-mod-quiz-attempt #dock,
#page-mod-quiz-review
#dock{display:none}#page-mod-quiz-attempt #page #page-header h1,
#page-mod-quiz-review #page #page-header
h1{display:none}#page-mod-quiz-attempt #region-main,
#page-mod-quiz-review #region-main{width:100%}#page-mod-quiz-attempt #block-region-side-pre,
#page-mod-quiz-attempt #block-region-side-post,
#page-mod-quiz-review #block-region-side-pre,
#page-mod-quiz-review #block-region-side-post{display:none}#page-mod-quiz-attempt #page-footer,
#page-mod-quiz-review #page-footer{display:none}#page-mod-quiz-attempt .editquestion,
#page-mod-quiz-review .editquestion,
#page-mod-quiz-attempt .questionflag,
#page-mod-quiz-review
.questionflag{display:none}#page-mod-quiz-attempt .submitbtns,
#page-mod-quiz-review
.submitbtns{display:none}#page-mod-quiz-review .que
.commentlink{display:none}#page-mod-quiz-attempt .que,
#page-mod-quiz-review
.que{page-break-inside:avoid}}@media only screen and (max-width:565px){#page-mod-quiz-edit
.rpcontainerclass{margin-top:3em}#page-mod-quiz-edit
.maxgrade{margin-top:0.1em}#page-mod-quiz-edit
.statusbar{padding:0}}.path-mod-resource
.resourcecontent{text-align:center}.path-mod-resource
.resourcedetails{font-size:0.8em;color:#555}.resourcelinkdetails{font-size:0.8em;color:#555}.path-mod-scorm
.top{vertical-align:top}.path-mod-scorm .scorm-left{text-align:left}.path-mod-scorm .scorm-center{text-align:center}.path-mod-scorm .scorm-right{text-align:right}.path-mod-scorm
.scoframe{position:relative;width:100%;height:100%}.ios #scormpage
#scorm_content{-webkit-overflow-scrolling:touch;overflow:scroll}#page-mod-scorm-player
#scormtop{position:relative;width:100%;height:30px}#page-mod-scorm-player
#scormbrowse{position:absolute;left:5px;top:0px}#page-mod-scorm-player
#scormnav{position:absolute;right:5px;text-align:center;top:3px;width:100%}#page-mod-scorm-player
#scormbox{width:74%;height:100%;position:absolute;right:0px;top:0px}#page-mod-scorm-player
#scormpage{position:relative;width:100%;height:100%}#page-mod-scorm-player #scormpage
#toctree{position:relative;width:100%}#page-mod-scorm-player
#tocbox{position:relative;left:0px;width:100%;height:100%;font-size:0.8em}#page-mod-scorm-player
#toctree{overflow:visible}#page-mod-scorm-player
#tochead{position:relative;text-align:center;top:3px;height:30px}#page-mod-scorm-player #scormpage
.scoframe{frameborder:0}#page-mod-scorm-player #scormpage
#scorm_object{border:none;width:98%;height:98%}#page-mod-scorm-player #scormpage
#scorm_object.scorm_nav_under_content{height:95%}#page-mod-scorm-player #scormpage
#scorm_content{height:100%}#page-mod-scorm-player #scormpage
#scorm_toc{position:relative}#page-mod-scorm-player #scormpage
#scorm_toc_title{font-size:1.2em;font-weight:bold}#page-mod-scorm-player #scormpage
#scorm_tree{border-right:5px solid rgb(239, 245, 255)}#page-mod-scorm-player #scormpage
#scorm_navpanel{text-align:center}#page-mod-scorm-player .toc,
#page-mod-scorm-player .no-toc{width:100%}#page-mod-scorm-player
.structlist{list-style-type:none;white-space:nowrap}#page-mod-scorm-player
.structurelist{position:relative;list-style-type:none;width:96%;margin:0;padding:0}#page-mod-scorm-player .structurelist
ul{padding-left:0.5em;margin-left:0.5em}#page-mod-scorm-player #scormpage #scorm_toc.disabled,
#page-mod-scorm-player #scormpage
#scorm_toc_toggle.disabled{display:none}#page-mod-scorm-view
.structurelist{list-style-type:none;white-space:nowrap}#page-mod-scorm-view
.structurelist{list-style-type:none;white-space:nowrap}#page-mod-scorm-view
.exceededmaxattempts{color:#c00}#page-mod-scorm-player
#altfinishlink{font-size:140%;border:0px;padding:0px}#page-mod-scorm-player
#scormmode{float:left;border:0px}#page-mod-scorm-player.pagelayout-popup #page-content .region-content{padding:0px}#page-mod-scorm-player.pagelayout-popup #page-wrapper{width:100%}#page-mod-scorm-player .yui-layout-scroll div.yui-layout-bd{overflow:visible}#page-mod-scorm-player .yui-layout-unit-left div.yui-layout-bd{overflow:auto}.path-mod-scorm.forcejavascript .scorm-center{display:none}.path-mod-scorm.forcejavascript
.toc{display:none}.path-mod-scorm.forcejavascript #scormpage
#tocbox{display:none}.path-mod-scorm.jsenabled
.forcejavascriptmessage{display:none}.path-mod-scorm.jsenabled .scorm-center{display:block}.path-mod-scorm.jsenabled
.toc{display:block}.path-mod-scorm.jsenabled #scormpage
#tocbox{display:block}#page-mod-scorm-report-userreporttracks table
.c1{word-wrap:break-word;word-break:break-all}#page-mod-scorm-report
.scormattemptcounts{clear:left;text-align:center;display:inline;margin-left:20%}#page-mod-scorm-player #scormpage span.yui3-treeview-icon{display:none}#page-mod-scorm-player #scormpage li.yui3-treeview-has-children>div.yui3-treeview-row>span.yui3-treeview-icon{display:block}#page-mod-scorm-player #scormpage div.yui3-u-1,
#page-mod-scorm-player #scormpage div.yui3-u-3-4,
#page-mod-scorm-player #scormpage div.yui3-u-1-5,
#page-mod-scorm-player #scormpage div.yui3-u-1-24{display:inline-block;*display:inline;zoom:1;letter-spacing:normal;word-spacing:normal;vertical-align:top;text-rendering:auto}#page-mod-scorm-player #scormpage div.yui3-u-1{display:block}#page-mod-scorm-player #scormpage div.yui3-u-3-4{width:75%}#page-mod-scorm-player #scormpage div.yui3-u-1-5{width:20%}#page-mod-scorm-player #scormpage div.yui3-u-1-24{width:4.1666%}#page-mod-scorm-player #scormpage div.yui3-g-r{*letter-spacing:normal;*word-spacing:-0.43em}#page-mod-scorm-player .opera-only :-o-prefocus,
#page-mod-scorm-player #scormpage div.yui3-g-r
img{max-width:100%}.dir-rtl#page-mod-scorm-player #scormpage span.yui3-treeview-icon{float:right}@charset "utf-8";#ecform_container{width:95%;text-align:center}#ecform_title{text-align:center;font-size:1.7em;font-weight:bold}#ecform_content{clear:both;border-top:thin #dcdcdc solid;border-bottom:thin #dcdcdc solid;border-left:thin #dcdcdc solid;border-right:thin #dcdcdc solid;padding-left:1em;padding-right:1em;padding-bottom:1em;overflow-x:hidden;-moz-border-radius-topleft:6px;-moz-border-radius-topright:6px;-moz-border-radius-bottomleft:6px;-moz-border-radius-bottomright:6px}#ecform_content
.titcontent{margin-top:1em}#ecform_container
.on{display:block}#ecform_container
.off{display:none}#ecform_container
.tabon{display:inline}#ecform_container
.taboff{display:inline;opacity:0.5}#ecform_onglet ul
li{margin:5px
4px 0px 4px;background-repeat:no-repeat;background-position:top right}#ecform_onglet ul#menu li
a{width:116px;line-height:13px;height:22px}.ecformtab{width:80%;margin-right:auto;margin-left:auto;margin-bottom:5px}.son{display:block}.soff{display:none}#monForm{width:91%}#monForm
p{margin:2px
0;margin-bottom:10px}#monForm
fieldset{margin-bottom:10px;border:#CCC 1px solid;padding:7px
7px 7px 7px}#monForm fieldset:hover{background-color:#FFF}#monForm fieldset
legend{padding:0
10px;font-size:1.3em;color:#999}#monForm
label{display:block;width:35%;float:left;padding-right:1%;text-align:right;letter-spacing:1px;background:#dcdcdc;font-size:1.1em}#monForm label:hover{font-weight:bold}#monForm label
.error{background:#F00}#monForm
.form_label_nostyle{background:none}#monForm input, #monForm
select{margin-left:1%;width:62%;border:#CCC 1px solid}#monForm input:hover, #monForm select:hover, #monForm input:focus, #monForm select:focus{border:#CCC 1px solid}#monForm
.form_input_day{width:20%;text-align:center}#monForm
.form_input_month{width:20%;text-align:center}#monForm
.form_input_year{width:20%;text-align:center}#monForm
.form_input_duration{width:6%}#monForm
.addbutton{width:40%;text-align:center;margin-bottom:10px}#monForm input[type="submit"]{border:#DEF 1px solid;width:27%}#monForm input[type="submit"]:hover{background-color:#6C3;cursor:pointer}#monForm input[type="reset"]{border:#DEF 1px solid;width:27%}#monForm input[type="reset"]:hover{background-color:#E6484D;cursor:pointer}.ds_box{background-color:#FFF;border:1px
solid #000;position:absolute;z-index:32767}.ds_tbl{background-color:#FFF}.ds_head{background-color:#585858;color:#FFF;font-family:Arial,Helvetica,sans-serif;font-size:13px;font-weight:bold;text-align:center;letter-spacing:2px}.ds_subhead{background-color:#CCC;color:#000;font-size:12px;font-weight:bold;text-align:center;font-family:Arial,Helvetica,sans-serif;width:32px}.ds_cell{background-color:#EEE;color:#000;font-size:13px;text-align:center;font-family:Arial,Helvetica,sans-serif;padding:5px;cursor:pointer}.ds_cell:hover{background-color:#F3F3F3}#libsearch
INPUT{font-size:0.9em}#libsearch
SELECT{font-size:0.9em}.widget{}.widget-label{}.widget-input{}td.mtdfield{width:25%;min-height:24px;text-align:right;color:white;background-color:#565B9E;border:2px
solid white;font-weight:bolder;padding:4px;padding-right:10px}td.mtdnum{width:5%;min-height:24px;text-align:right;color:#B9B9D9;background-color:#565B9E;border:2px
solid white;padding:4px}td.mtdvalue{width:70%;text-align:left;padding:2px;background-color:#F0F0F7;padding-left:10px}fieldset.subbranch{margin-left:5px}fieldset>legend{padding:5px;font-weight:bolder;color:#54549E}.sharedresource-listsection{font-weight:bold;text-align:center}#notice-menu
LI{background-color:#A7A3BA;font-weight:bolder;padding:4px;color:#f0f0f0}#notice-menu
.active{background-color:#4D4860;color:#f0f0f0}#page-mod-sharedresource-metadatanotice
#ecform_content{padding:0px}#page-mod-sharedresource-metadatanotice #ecform_content .mtd-description-panel{text-align:left;padding:20px}#sharedresource-search{float:left;width:200px}.widget
.header{background-color:#6B6486;color:#f0f0f0;padding:2px;font-weight:bold}.mtd-tab-visible{float:left;display:inline}.mtd-tab-hidden{float:left;display:none}.path-mod-survey
.smalltext{font-size:0.75em}.path-mod-survey .surveytable .rblock
label{display:block}.path-mod-survey .surveytable .foundthat,
.path-mod-survey .surveytable
.preferthat{white-space:nowrap}.path-mod-survey .surveytable
.buttoncell{width:5%}.path-mod-survey .surveytable .optioncell,
.path-mod-survey .surveytable
.questioncell{width:50%;vertical-align:top}.path-mod-survey .surveytable
.whitecell{background-color:white}.path-mod-survey #surveyform
th{font-weight:normal;text-align:left}.path-mod-survey #surveyform
th.hresponse{text-align:center;width:9%}#page-mod-survey-report
.fullnamecell{width:10%;vertical-align:top;white-space:nowrap}div.centeredboxtable{margin-left:auto;margin-right:auto;width:600px;text-align:center}body.path-course-view div.taskchainrecentactivity
p{margin:0px}body.path-course-view div.taskchainrecentactivity
ul{font-size:0.8em;margin:0em
0em 0em 1em;padding:0em
0em 0em 1em}#page-mod-taskchain-view .region-content{text-align:center}#page-mod-taskchain-view .region-content ul.taskchainwarnings,
#page-mod-taskchain-view .region-content table.taskchainentryoptions,
#page-mod-taskchain-view .region-content table.taskchainattempts,
#page-mod-taskchain-view .region-content table.taskchainattemptssummary,
#page-mod-taskchain-view .region-content
table.taskchaindeleteattempts{margin-left:auto;margin-right:auto}#page-mod-taskchain-view .region-content table.taskchainentryoptions
td.c0{font-weight:bold;text-align:right}#page-mod-taskchain-view .region-content table.taskchainentryoptions
td.c1{font-weight:normal;text-align:left}#page-mod-taskchain-attempt .region-content
table.taskchaintaskssummary{margin-left:auto;margin-right:auto}#page-mod-taskchain-attempt
div.taskchainstopbutton{position:absolute;right:0px;top:0.8em}#page-mod-taskchain-attempt div.taskchainstopbutton .FuncButton,
#page-mod-taskchain-attempt div.taskchainstopbutton .FuncButtonUp,
#page-mod-taskchain-attempt div.taskchainstopbutton
.FuncButtonDown{margin-right:18px}#page-mod-taskchain-attempt input,
#page-mod-taskchain-attempt
textarea{width:auto}#page-mod-taskchain-submit .region-content{text-align:center}#page-mod-taskchain-submit .region-content ul.taskchainexitfeedback,
#page-mod-taskchain-submit .region-content p.taskchainwhatnext,
#page-mod-taskchain-submit .region-content ul.taskchainexitfeedback
li{list-style-type:none}#page-mod-taskchain-submit .region-content
li.taskchainexitencouragement{font-size:1.2em;margin-top:6px;margin-bottom:6px}#page-mod-taskchain-submit .region-content
table.taskchainexitlinks{margin-left:auto;margin-right:auto}#page-mod-taskchain-submit .region-content table.taskchainexitlinks
td.c0{font-weight:bold;text-align:right}#page-mod-taskchain-submit .region-content table.taskchainexitlinks
td.c1{font-weight:normal;text-align:left}#page-mod-taskchain-index .region-content{text-align:center}#page-mod-taskchain-index .region-content
table{margin-left:auto;margin-right:auto}#page-mod-taskchain-report table.flexible
tr.emptyrow{display:none}#page-mod-taskchain-report table.reportheader th:after{content:":"}#page-mod-taskchain-report table.reportheader
th{text-align:right;padding-right:4px}#page-mod-taskchain-report table.reportheader
td{text-align:left;padding-left:4px}#page-mod-taskchain-report
table#attempts{clear:both}#page-mod-taskchain-report table#attempts.analysis
td.c0{font-weight:bold}#page-mod-taskchain-report table#attempts.analysis td.c0:after{content:":"}#page-mod-taskchain-report div#page,
#page-mod-taskchain-report div#page div#page-content,
#page-mod-taskchain-report div#page div#page-content div#region-main-box,
#page-mod-taskchain-report div#page div#page-content div#region-main-box div#region-post-box,
#page-mod-taskchain-report div#page div#page-content div#region-main-box div#region-post-box div#region-main-wrap,
#page-mod-taskchain-report div#page div#page-content div#region-main-box div#region-post-box div#region-main-wrap div#region-main,
#page-mod-taskchain-report div#page div#page-content div#region-main-box div#region-post-box div#region-main-wrap div#region-main div.region-content,
#page-mod-taskchain-report div#page div#page-content div#region-main-box div#region-post-box div#region-main-wrap div#region-main div.region-content #attemptsform div.no-overflow{overflow:visible}#page-mod-taskchain-report table#attempts
th{white-space:normal}#page-mod-taskchain-report table#attempts
td{width:60px;text-align:center}#page-mod-taskchain-report table#attempts td.fullname,
#page-mod-taskchain-report table#attempts
td.taskname{width:120px;text-align:left}#page-mod-taskchain-report table#attempts
td.timemodified{width:80px}#page-mod-taskchain-report table#attempts
td.responsefield{text-align:right}#page-mod-taskchain-report table#attempts th span.grademethod,
#page-mod-taskchain-report table#attempts th
span.scoremethod{font-size:0.8em;font-weight:normal}#page-mod-taskchain-report
ul.response{text-align:left;padding:0px;margin-top:0px;text-indent:-6px}#page-mod-taskchain-report ul.response
li{list-style:none;text-align:left}#page-mod-taskchain-report ul.response
li.correct{color:green;list-style-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/tick_green_small)}#page-mod-taskchain-report ul.response
li.ignored{color:grey;list-style-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/show)}#page-mod-taskchain-report ul.response
li.wrong{color:red;list-style-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/cross_red_small)}#page-mod-taskchain-report ul.response
li.score{color:inherit;list-style-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/item)}#page-mod-taskchain-report ul.response
li.hintsclueschecks{color:#666;list-style-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/item)}#page-mod-taskchain-review
table#responses{clear:both;margin-left:auto;margin-right:auto}#page-mod-taskchain-review table#responses td.c0,
#page-mod-taskchain-review table#responses td.c2,
#page-mod-taskchain-review table#responses td.c4,
#page-mod-taskchain-review table#responses
td.c6{font-weight:bold;text-align:right}#page-mod-taskchain-review table#responses td.c1,
#page-mod-taskchain-review table#responses td.c3,
#page-mod-taskchain-review table#responses td.c5,
#page-mod-taskchain-review table#responses
td.lastcol{font-weight:normal;text-align:left}#page-mod-taskchain-review table#responses td.c0:after,
#page-mod-taskchain-review table#responses td.c2:after,
#page-mod-taskchain-review table#responses td.c4:after,
#page-mod-taskchain-review table#responses td.c6:after{content:":"}#page-mod-taskchain-review table#responses td.lastcol:after{content:""}#page-mod-taskchain-edit-task #reviewoptionshdr
.fitem{clear:none;float:left;margin-left:48px;width:20%}#page-mod-taskchain-edit-task #reviewoptionshdr
.fitemtitle{font-weight:bold;margin-left:0;text-align:left;width:100%}#page-mod-taskchain-edit-task #reviewoptionshdr
fieldset.fgroup{margin-left:0;text-align:left;width:100%}#page-mod-taskchain-edit-task #reviewoptionshdr
fieldset.fgroup{clear:left;margin:0
0 1em}#page-mod-taskchain-edit-task #reviewoptionshdr fieldset.fgroup>span{clear:left;float:left;line-height:1.7}#page-mod-taskchain-edit-task #reviewoptionshdr fieldset.fgroup span
label{margin-left:0.4em}#page-mod-taskchain-edit-task.dir-rtl #reviewoptionshdr
.fitem{float:right}#page-mod-taskchain-edit-task.dir-rtl #reviewoptionshdr
.fitemtitle{text-align:right}#page-mod-taskchain-edit-task.dir-rtl #reviewoptionshdr fieldset.fgroup
span{float:right;clear:right}#page-mod-taskchain-edit-tasks div#page,
#page-mod-taskchain-edit-tasks div#page-wrapper,
#page-mod-taskchain-edit-tasks div#page-content,
#page-mod-taskchain-edit-tasks div#region-pre-box,
#page-mod-taskchain-edit-tasks div#region-main-box,
#page-mod-taskchain-edit-tasks div#region-post-box,
#page-mod-taskchain-edit-tasks div#region-main-wrap,
#page-mod-taskchain-edit-tasks div#region-main-pad,
#page-mod-taskchain-edit-tasks div#region-main,
#page-mod-taskchain-edit-tasks div.region-content{overflow:visible !important}#page-mod-taskchain-edit-tasks form.mform,
#page-mod-taskchain-edit-tasks fieldset,
#page-mod-taskchain-edit-tasks fieldset div,
#page-mod-taskchain-edit-tasks fieldset.clearfix,
#page-mod-taskchain-edit-tasks div.fcontainer,
#page-mod-taskchain-edit-tasks div.fitem,
#page-mod-taskchain-edit-tasks div.fitemtitle,
#page-mod-taskchain-edit-tasks div.felement,
#page-mod-taskchain-edit-tasks div.felement.fgroup,
#page-mod-taskchain-edit-tasks fieldset.felement,
#page-mod-taskchain-edit-tasks
fieldset.felement.fgroup{clear:none;overflow:visible;margin:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;margin-top:0px;padding:0px;padding-bottom:0px;padding-left:0px;padding-right:0px;padding-top:0px;text-align:center;vertical-align:top;width:auto}#page-mod-taskchain-edit-tasks fieldset.clearfix
div.fitem{padding-top:6px}#page-mod-taskchain-edit-tasks fieldset#labels div.fitem,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem
div.felement{vertical-align:bottom}#page-mod-taskchain-edit-tasks fieldset.clearfix,
#page-mod-taskchain-edit-tasks fieldset.clearfix
div.fcontainer{text-align:left;white-space:nowrap}#page-mod-taskchain-edit-tasks
fieldset.clearfix{min-width:600px;_width:expression(
this.currentStyle.getAttribute('minWidth') ? this.currentStyle.getAttribute('minWidth') :
this.currentStyle.getAttribute('min-width') ? this.currentStyle.getAttribute('min-width') : null
)}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem div.fitemtitle,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem div.felement,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem div.felement.fgroup,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem
fieldset.felement{white-space:normal}#page-mod-taskchain-edit-tasks
fieldset#labels{background:#eee;background:linear-gradient(top,  #ffffff,  #dddddd);background:-o-linear-gradient(top,  #ffffff,  #dddddd);background:-moz-linear-gradient(top,  #ffffff,  #dddddd);background:-webkit-gradient(linear, left top, left bottom, from(#ffffff), to(#dddddd));filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#dddddd');-ms-filter:"progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#dddddd')";border-top-left-radius:12px;border-top-right-radius:12px;-o-border-top-left-radius:12px;-o-border-top-right-radius:12px;-moz-border-top-left-radius:12px;-moz-border-top-right-radius:12px;-webkit-border-top-left-radius:12px;-webkit-border-top-right-radius:12px}#page-mod-taskchain-edit-tasks fieldset#defaults,
#page-mod-taskchain-edit-tasks
fieldset#selects{background:#fff}#page-mod-taskchain-edit-tasks div.clearfix:after,
#page-mod-taskchain-edit-tasks fieldset.clearfix:after{clear:none;content:"";display:none}#page-mod-taskchain-edit-tasks
div.advancedbutton{display:none}#page-mod-taskchain-edit-tasks
div.fitem{border-right:1px solid #999;min-height:24px;padding-left:3px;padding-right:3px;width:120px;display:-moz-inline-box;display:-moz-inline-stack;display:inline-block;zoom:1;*display:inline}#page-mod-taskchain-edit-tasks fieldset.clearfix:nth-child(2n+6){background-color:#eea}#page-mod-taskchain-edit-tasks fieldset.clearfix:nth-child(2n+7){background-color:#ffe}#page-mod-taskchain-edit-tasks
span.headerfield{font-size:1.1em;font-weight:bold}#page-mod-taskchain-edit-tasks
span.defaultfield{font-style:italic}#page-mod-taskchain-edit-tasks div.fitem:last-child{border-right:none}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.sortorder,
#page-mod-taskchain-edit-tasks fieldset.clearfix
div.fitem.edit{width:60px}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.defaultrecord,
#page-mod-taskchain-edit-tasks fieldset.clearfix
div.fitem.selectrecord{width:50px}#page-mod-taskchain-edit-tasks fieldset.clearfix
div.fitem.name{width:180px}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.name,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.sourcefile,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.sourcetype,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.sourcelocation,
#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.configfile,
#page-mod-taskchain-edit-tasks fieldset.clearfix
div.fitem.configlocation{word-wrap:break-word}#page-mod-taskchain-edit-tasks
legend.ftoggler{display:none}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.preconditions,
#page-mod-taskchain-edit-tasks fieldset.clearfix
div.fitem.postconditions{width:180px}#page-mod-taskchain-edit-tasks fieldset#selects div.fitem.selectrecord
fieldset.fgroup{text-align:right}#page-mod-taskchain-edit-tasks fieldset#selects div.fitem.selectrecord fieldset.fgroup
input{margin-left:3px;margin-right:2px}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.sortorder
div.felement{text-align:center}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.sortorder div.felement
input{text-align:center;width:2.0em}#page-mod-taskchain-edit-tasks fieldset.clearfix div.fitem.name
div.felement{text-align:left}#page-mod-taskchain-edit-tasks fieldset#labels   div.fitem.name div.felement,
#page-mod-taskchain-edit-tasks fieldset#defaults div.fitem.name div.felement,
#page-mod-taskchain-edit-tasks fieldset#selects  div.fitem.name
div.felement{text-align:center}#page-mod-taskchain-edit-tasks
span.reviewoptionsitems{white-space:nowrap}#page-mod-taskchain-edit-tasks fieldset#filtershdr,
#page-mod-taskchain-edit-tasks
fieldset#actionshdr{background:transparent;border:none;margin-top:12px;margin-bottom:12px;text-align:left;padding-left:2.0em}#page-mod-taskchain-edit-tasks fieldset#filtershdr
legend{display:none}#page-mod-taskchain-edit-tasks fieldset#actionshdr
legend{margin-bottom:12px}#page-mod-taskchain-edit-tasks fieldset#filtershdr div.fitem,
#page-mod-taskchain-edit-tasks fieldset#actionshdr
div.fitem{border-right:none;clear:both;display:block;width:auto}#page-mod-taskchain-edit-tasks fieldset#filtershdr div.fitem div.fitemtitle,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem
div.fitemtitle{float:left}#page-mod-taskchain-edit-tasks fieldset#filtershdr div.felement,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.felement,
#page-mod-taskchain-edit-tasks fieldset#filtershdr div.felement.fgroup,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.felement.fgroup,
#page-mod-taskchain-edit-tasks fieldset#filtershdr fieldset.felement,
#page-mod-taskchain-edit-tasks fieldset#actionshdr fieldset.felement,
#page-mod-taskchain-edit-tasks fieldset#filtershdr fieldset.felement.fgroup,
#page-mod-taskchain-edit-tasks fieldset#actionshdr
fieldset.felement.fgroup{float:left;text-align:left}#page-mod-taskchain-edit-tasks
input{margin-right:8px}#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.reordertasks_sortfield,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.reordertasks_sortdirection,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.reordertasks_sortincrement,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.addtasks,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.addtasksafter,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.movetasks,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.movetasksafter,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.movetaskschain,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtercoursename,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filteractivityname,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtertaskname,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtertaskposition,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtersourcefile,
#page-mod-taskchain-edit-tasks fieldset#actionshdr
div.fitem.applydefaults_filtersourcetype{background-color:#eeb;border-left:1px solid #333;border-right:1px solid #333;margin-left:2.0em}#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.reordertasks_sortfield,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.reordertasks_sortdirection,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.reordertasks_sortincrement,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.addtasks,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.addtasksafter,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.movetasks,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.movetasksafter,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.movetaskschain,
#page-mod-taskchain-edit-tasks fieldset#actionshdr
div.fitem.applydefaults{padding-left:2.0em;width:42.0em}#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtercoursename,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filteractivityname,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtertaskname,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtertaskposition,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div.fitem.applydefaults_filtersourcefile,
#page-mod-taskchain-edit-tasks fieldset#actionshdr
div.fitem.applydefaults_filtersourcetype{padding-left:4.0em;width:40.0em}#page-mod-taskchain-edit-tasks fieldset#actionshdr div#fitem_id_reordertasks_sortfield,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div#fitem_id_addtasks_start,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div#fitem_id_movetasks_start,
#page-mod-taskchain-edit-tasks fieldset#actionshdr
div#fitem_id_applydefaults_selectedtasks{border-top:1px solid #333;padding-top:6px}#page-mod-taskchain-edit-tasks fieldset#actionshdr div#fitem_id_reordertasks_sortincrement,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div#fgroup_id_addtasksafter_elements,
#page-mod-taskchain-edit-tasks fieldset#actionshdr div#fgroup_id_movetaskschain_elements,
#page-mod-taskchain-edit-tasks fieldset#actionshdr
div#fgroup_id_applydefaults_filtersourcetype_elements{border-bottom:1px solid #333;padding-bottom:6px}#page-mod-taskchain-edit-tasks div.fitem#fitem_id_applydefaults_filtercoursename div.fitemtitle,
#page-mod-taskchain-edit-tasks div.fitem#fgroup_id_applydefaults_filteractivityname_elements div.fitemtitle,
#page-mod-taskchain-edit-tasks div.fitem#fgroup_id_applydefaults_filtertaskname_elements div.fitemtitle,
#page-mod-taskchain-edit-tasks div.fitem#fitem_id_applydefaults_filtertaskposition div.fitemtitle,
#page-mod-taskchain-edit-tasks div.fitem#fgroup_id_applydefaults_filtersourcefile_elements div.fitemtitle,
#page-mod-taskchain-edit-tasks div.fitem#fgroup_id_applydefaults_filtersourcetype_elements
div.fitemtitle{min-width:8.0em;text-align:left;_width:expression(
this.currentStyle.getAttribute('minWidth') ? this.currentStyle.getAttribute('minWidth') :
this.currentStyle.getAttribute('min-width') ? this.currentStyle.getAttribute('min-width') : null
)}#page-mod-taskchain-edit-tasks fieldset.hidden,
#page-mod-taskchain-edit-tasks fieldset.hidden div,
#page-mod-taskchain-edit-tasks fieldset.hidden div div.fitem,
#page-mod-taskchain-edit-tasks fieldset.hidden div div.fitem
div.felement{text-align:left;width:auto}#page-mod-taskchain-edit-tasks fieldset#actionshdr
div.fitem.actionjs{display:none}#page-mod-taskchain-edit-tasks
div.conditions{text-align:left;padding:0px}#page-mod-taskchain-edit-tasks div.conditions
ul{margin:0px;padding:0px;white-space:nowrap}#page-mod-taskchain-edit-tasks div.conditions ul
li{margin:0px;padding:0px;list-style:disc inside}#page-mod-taskchain-edit-tasks
span.commands{font-size:0.8em}#page-mod-taskchain-edit-tasks
p.taskchainconditionsintro{margin:0px
0px 12px 0px}#page-mod-taskchain-edit-tasks
p.taskchainconditionsor{margin:0px}#page-mod-taskchain-edit-tasks p.taskchainconditionsor:after{content:" ---"}#page-mod-taskchain-edit-tasks p.taskchainconditionsor:before{content:"--- "}#page-mod-taskchain-edit-chains div#page,
#page-mod-taskchain-edit-chains div#page div#page-content,
#page-mod-taskchain-edit-chains div#page div#page-content div#region-main-box,
#page-mod-taskchain-edit-chains div#page div#page-content div#region-main-box div#region-pre-box,
#page-mod-taskchain-edit-chains div#page div#page-content div#region-main-box div#region-pre-box div#region-main,
#page-mod-taskchain-edit-chains div#page div#page-content div#region-main-box div#region-post-box,
#page-mod-taskchain-edit-chains div#page div#page-content div#region-main-box div#region-post-box div#region-main-wrap,
#page-mod-taskchain-edit-chains div#page div#page-content div#region-main-box div#region-post-box div#region-main-wrap div#region-main,
#page-mod-taskchain-edit-chains div#page div#page-content div#region-main-box div#region-post-box div#region-main-wrap div#region-main div.region-content{overflow:visible}#page-mod-taskchain-edit-chains form.mform,
#page-mod-taskchain-edit-chains fieldset,
#page-mod-taskchain-edit-chains fieldset div,
#page-mod-taskchain-edit-chains fieldset.clearfix,
#page-mod-taskchain-edit-chains div.fcontainer,
#page-mod-taskchain-edit-chains div.fitem,
#page-mod-taskchain-edit-chains div.fitemtitle,
#page-mod-taskchain-edit-chains div.felement,
#page-mod-taskchain-edit-chains div.felement.fgroup,
#page-mod-taskchain-edit-chains fieldset.felement,
#page-mod-taskchain-edit-chains
fieldset.felement.fgroup{clear:none;overflow:visible;margin:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;margin-top:0px;padding:0px;padding-bottom:0px;padding-left:0px;padding-right:0px;padding-top:0px;text-align:center;vertical-align:top;width:auto}#page-mod-taskchain-edit-chains fieldset.clearfix
div.fitem{padding-top:6px}#page-mod-taskchain-edit-chains fieldset#labels div.fitem,
#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem
div.felement{vertical-align:bottom}#page-mod-taskchain-edit-chains fieldset.clearfix,
#page-mod-taskchain-edit-chains fieldset.clearfix
div.fcontainer{white-space:nowrap;text-align:left}#page-mod-taskchain-edit-chains
fieldset.clearfix{min-width:600px;_width:expression(
this.currentStyle.getAttribute('minWidth') ? this.currentStyle.getAttribute('minWidth') :
this.currentStyle.getAttribute('min-width') ? this.currentStyle.getAttribute('min-width') : null
)}#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem,
#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem div.fitemtitle,
#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem div.felement,
#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem div.felement.fgroup,
#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem
fieldset.felement{white-space:normal}#page-mod-taskchain-edit-chains
fieldset#labels{background:#eee;background:linear-gradient(top,  #ffffff,  #dddddd);background:-o-linear-gradient(top,  #ffffff,  #dddddd);background:-moz-linear-gradient(top,  #ffffff,  #dddddd);background:-webkit-gradient(linear, left top, left bottom, from(#ffffff), to(#dddddd));filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#dddddd');-ms-filter:"progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#dddddd')";border-top-left-radius:12px;border-top-right-radius:12px;-o-border-top-left-radius:12px;-o-border-top-right-radius:12px;-moz-border-top-left-radius:12px;-moz-border-top-right-radius:12px;-webkit-border-top-left-radius:12px;-webkit-border-top-right-radius:12px}#page-mod-taskchain-edit-chains fieldset#defaults,
#page-mod-taskchain-edit-chains
fieldset#selects{background:#fff}#page-mod-taskchain-edit-chains div.clearfix:after,
#page-mod-taskchain-edit-chains fieldset.clearfix:after{clear:none;content:"";display:none}#page-mod-taskchain-edit-chains
div.advancedbutton{display:none}#page-mod-taskchain-edit-chains
div.fitem{border-right:1px solid #999;min-height:24px;padding-left:3px;padding-right:3px;width:120px;display:-moz-inline-box;display:-moz-inline-stack;display:inline-block;zoom:1;*display:inline}#page-mod-taskchain-edit-chains fieldset.clearfix:nth-child(2n+6){background-color:#eea}#page-mod-taskchain-edit-chains fieldset.clearfix:nth-child(2n+7){background-color:#ffe}#page-mod-taskchain-edit-chains
span.headerfield{font-size:1.1em;font-weight:bold}#page-mod-taskchain-edit-chains
span.defaultfield{font-style:italic}#page-mod-taskchain-edit-chains div.fitem:last-child{border-right:none}#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem.sortorder,
#page-mod-taskchain-edit-chains fieldset.clearfix
div.fitem.edit{width:60px}#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem.defaultrecord,
#page-mod-taskchain-edit-chains fieldset.clearfix
div.fitem.selectrecord{width:50px}#page-mod-taskchain-edit-chains fieldset.clearfix
div.fitem.name{width:180px}#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem.preconditions,
#page-mod-taskchain-edit-chains fieldset.clearfix
div.fitem.postconditions{width:180px}#page-mod-taskchain-edit-chains fieldset#selects div.fitem.selectrecord
fieldset.fgroup{text-align:right}#page-mod-taskchain-edit-chains fieldset#selects div.fitem.selectrecord fieldset.fgroup
input{margin-left:3px;margin-right:2px}#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem.sortorder
div.felement{text-align:center}#page-mod-taskchain-edit-chains fieldset.clearfix div.fitem.sortorder div.felement
input{text-align:center;width:2.0em}#page-mod-taskchain-edit-chains fieldset.clearfix          div.fitem.name
div.felement{text-align:left}#page-mod-taskchain-edit-chains fieldset#labels   div.fitem.name div.felement,
#page-mod-taskchain-edit-chains fieldset#defaults div.fitem.name div.felement,
#page-mod-taskchain-edit-chains fieldset#selects  div.fitem.name
div.felement{text-align:center}#page-mod-taskchain-edit-chains fieldset#filtershdr,
#page-mod-taskchain-edit-chains
fieldset#actionshdr{background:transparent;border:none;margin-top:12px;margin-bottom:12px;text-align:left;padding-left:24px}#page-mod-taskchain-edit-chains fieldset#filtershdr
legend{display:none}#page-mod-taskchain-edit-chains fieldset#actionshdr
legend{margin-bottom:12px}#page-mod-taskchain-edit-chains fieldset#filtershdr div.fitem,
#page-mod-taskchain-edit-chains fieldset#actionshdr
div.fitem{border-right:none;clear:both;display:block;width:auto}#page-mod-taskchain-edit-chains fieldset#filtershdr div.fitem div.fitemtitle,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem
div.fitemtitle{float:left}#page-mod-taskchain-edit-chains fieldset#filtershdr div.felement,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.felement,
#page-mod-taskchain-edit-chains fieldset#filtershdr div.felement.fgroup,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.felement.fgroup,
#page-mod-taskchain-edit-chains fieldset#filtershdr fieldset.felement,
#page-mod-taskchain-edit-chains fieldset#actionshdr fieldset.felement,
#page-mod-taskchain-edit-chains fieldset#filtershdr fieldset.felement.fgroup,
#page-mod-taskchain-edit-chains fieldset#actionshdr
fieldset.felement.fgroup{float:left;text-align:left}#page-mod-taskchain-edit-chains
input{margin-right:8px}#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.reorderchains_sortfield,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.reorderchains_sortdirection,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.reorderchains_sortincrement,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.addchains,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.addchainsafter,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.movechains,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.movechainsafter,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.applydefaults,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.applydefaults_filtercoursename,
#page-mod-taskchain-edit-chains fieldset#actionshdr
div.fitem.applydefaults_filteractivityname{background-color:#eeb;border-left:1px solid #333;border-right:1px solid #333;margin-left:24px;width:480px}#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.reorderchains_sortfield,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.reorderchains_sortdirection,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.reorderchains_sortincrement,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.addchains,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.addchainsafter,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.movechains,
#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.movechainsafter,
#page-mod-taskchain-edit-chains fieldset#actionshdr
div.fitem.applydefaults{padding-left:24px;width:456px}#page-mod-taskchain-edit-chains fieldset#actionshdr div.fitem.applydefaults_filtercoursename,
#page-mod-taskchain-edit-chains fieldset#actionshdr
div.fitem.applydefaults_filteractivityname{padding-left:48px;width:432px}#page-mod-taskchain-edit-chains fieldset#actionshdr div#fitem_id_reorderchains_sortfield,
#page-mod-taskchain-edit-chains fieldset#actionshdr div#fitem_id_addchains_start,
#page-mod-taskchain-edit-chains fieldset#actionshdr div#fitem_id_movechains_start,
#page-mod-taskchain-edit-chains fieldset#actionshdr
div#fitem_id_applydefaults_selectedchains{border-top:1px solid #333;padding-top:6px}#page-mod-taskchain-edit-chains fieldset#actionshdr div#fitem_id_reorderchains_sortincrement,
#page-mod-taskchain-edit-chains fieldset#actionshdr div#fgroup_id_addchainsafter_elements,
#page-mod-taskchain-edit-chains fieldset#actionshdr div#fgroup_id_movechainsafter_elements,
#page-mod-taskchain-edit-chains fieldset#actionshdr
div#fgroup_id_applydefaults_filteractivityname_elements{border-bottom:1px solid #333;padding-bottom:6px}#page-mod-taskchain-edit-chains div.fitem#fitem_id_applydefaults_filtercoursename div.fitemtitle,
#page-mod-taskchain-edit-chains div.fitem#fgroup_id_applydefaults_filteractivityname_elements
div.fitemtitle{min-width:8.0em;text-align:left;_width:expression(
this.currentStyle.getAttribute('minWidth') ? this.currentStyle.getAttribute('minWidth') :
this.currentStyle.getAttribute('min-width') ? this.currentStyle.getAttribute('min-width') : null
)}#page-mod-taskchain-edit-chains fieldset.hidden,
#page-mod-taskchain-edit-chains fieldset.hidden div,
#page-mod-taskchain-edit-chains fieldset.hidden div div.fitem,
#page-mod-taskchain-edit-chains fieldset.hidden div div.fitem
div.felement{text-align:left;width:auto}#page-mod-taskchain-edit-chains fieldset#actionshdr
div.fitem.actionjs{display:none}#page-mod-taskchain-edit-condition fieldset.hidden,
#page-mod-taskchain-edit-columnlists
fieldset.hidden{margin:0px;padding:0px;text-align:center}#page-mod-taskchain-edit-condition fieldset.hidden div.fitem h1,
#page-mod-taskchain-edit-condition fieldset.hidden div.fitem h2,
#page-mod-taskchain-edit-condition fieldset.hidden div.fitem h3,
#page-mod-taskchain-edit-condition fieldset.hidden div.fitem h4,
#page-mod-taskchain-edit-condition fieldset.hidden div.fitem h5,
#page-mod-taskchain-edit-condition fieldset.hidden div.fitem h6,
#page-mod-taskchain-edit-columnlists fieldset.hidden div.fitem h1,
#page-mod-taskchain-edit-columnlists fieldset.hidden div.fitem h2,
#page-mod-taskchain-edit-columnlists fieldset.hidden div.fitem h3,
#page-mod-taskchain-edit-columnlists fieldset.hidden div.fitem h4,
#page-mod-taskchain-edit-columnlists fieldset.hidden div.fitem h5,
#page-mod-taskchain-edit-columnlists fieldset.hidden div.fitem
h6{margin:0px}#page-mod-taskchain-edit-condition div.fitem
div.fitemtitle{width:160px}#page-mod-taskchain-edit-condition div.fitem div.felement,
#page-mod-taskchain-edit-condition div.fitem
fieldset.felement{width:auto}#page-mod-taskchain-edit-columnlists
div.advancedbutton{display:none}#page-mod-taskchain-edit-columnlists
fieldset.clearfix{width:240px;margin-left:auto;margin-right:auto}#page-mod-taskchain-edit-columnlists fieldset.clearfix
legend{position:relative}#page-mod-taskchain-edit-columnlists fieldset.clearfix legend
input{position:absolute;left:176px}#page-mod-taskchain-edit-columnlists div.fitem
div.fitemtitle{width:160px;margin-right:12px}#page-mod-taskchain-edit-columnlists fieldset.clearfix:not(#filtershdr) div.fitem div.fitemtitle:after{content:":"}#page-mod-taskchain-edit-columnlists fieldset#actionshdr div,
#page-mod-taskchain-edit-columnlists fieldset#actionshdr div.fitem#fgroup_id_action_buttons_elements,
#page-mod-taskchain-edit-columnlists fieldset#actionshdr div.fitem#fgroup_id_action_buttons_elements
div.felement.fgroup{margin-bottom:0px;margin-left:0px;margin-right:0px;margin-top:0px;padding-bottom:0px;padding-left:0px;padding-right:0px;padding-top:0px;text-align:center;width:auto}#page-mod-taskchain-edit-columnlists #fgroup_id_action_buttons_elements
input{width:90px;margin:6px}.path-course-view .activity
a.taskchaingrade{border-bottom:2px #666 dotted;width:100%}.path-course-view .activity div.taskchainhighgrade,
.path-course-view .activity div.taskchainmediumgrade,
.path-course-view .activity div.taskchainlowgrade,
.path-course-view .activity
div.taskchainnograde{float:right;display:inline;min-width:2.6em;text-align:right;margin:6px
auto auto 6px;padding:1px
6px 1px 4px;-webkit-border-radius-topleft:4px;-webkit-border-radius-topright:4px;-moz-border-radius-topleft:4px;-moz-border-radius-topright:4px;-o-border-radius-topleft:4px;-o-border-radius-topright:4px;border-radius-topleft:4px;border-radius-topright:4px}.path-course-view .activity
.taskchainhighgrade{background-color:#cf9;color:#000}.path-course-view .activity .taskchainhighgrade:hover{background-color:#96ff2D;color:#222}.path-course-view .activity
.taskchainmediumgrade{background-color:#fc6;color:#000}.path-course-view .activity .taskchainmediumgrade:hover{background-color:#ffad02;color:#222}.path-course-view .activity
.taskchainlowgrade{background-color:#ff7373;color:#000}.path-course-view .activity .taskchainlowgrade:hover{background-color:#ff4040;color:#222}.path-course-view .activity
.taskchainnograde{background-color:#ddd;color:#000}.path-course-view .activity .taskchainnograde:hover{background-color:#ccc;color:#000}.path-mod-url
.resourcecontent{text-align:center}.wiki_contentbox{width:80%;margin:auto;min-width:200px;min-height:100px}.wiki_editor{width:50%;margin:auto;margin-top:10px;margin-bottom:10px}.wiki_previewbox{width:50%;margin:auto;border:thin solid blue}.wiki_button{margin:5px}.wiki_warning{color:red}.emptycomments{color:red;display:inline}.wiki-toc{border:1px
solid #BBB;background:#EEE;margin:16px;padding:8px}.wiki-toc-title{color:#666;font-size:1.1em;font-variant:small-caps;text-align:center}.wiki-toc-section{padding:0;margin:2px
8px}.wiki-toc-section-2{padding-left:12px}.wiki-toc-section-3{padding-left:24px}.wiki_form-button{margin-left:0%}.wiki-form-center{text-align:center;margin:auto;width:320px}.wiki-upload-table{margin:8px
auto;clear:both}.wiki-upload-table
table{margin:auto}.wiki-upload-table
h3{margin:4px
0px;text-align:center}.wiki-upload-section{border:1px
solid #EEE;width:400px;margin:8px
auto}.wiki-upload-section
legend{font-weight:bold;font-size:0.9em;margin-left:16px}.wiki-tags{text-align:right}.wiki_modifieduser
p{line-height:35px}.wiki_modifieduser
img{border:thin solid black}.wiki_restore_yes, .wiki_deletecomment_yes,
.dir-rtl .wiki_restore_no, .dir-rtl
.wiki_deletecomment_no{float:left}.wiki_restore_no, .wiki_deletecomment_no,
.dir-rtl .wiki_restore_yes, .dir-rtl
.wiki_deletecomment_yes{float:right}.wiki_restoreform,.wiki_deletecommentform{width:10%;margin:auto}.wiki_versionuser{float:left}.wiki_diffuserleft,.wiki_diffuserright{font-weight:normal;padding-top:1%}.wiki_diffuserleft{float:right}.dir-rtl
.wiki_diffuserleft{float:left}.wiki_diffuserright{float:left}.wiki_compareheading{font-weight:normal}.wiki_restore,.wiki_diffview,.wiki_difftime,.wiki_headingtime{font-size:0.8em;font-weight:normal}.wiki_difftime,.wiki_headingtime{font-style:oblique;text-align:center}.wiki_diff_oldpaging{float:left;width:40%;min-width:200px;margin-left:5%}.wiki_diff_newpaging{float:right;width:40%;min-width:200px;margin-right:5%}.wiki_diff_old,.wiki_diff_new{float:left;min-width:200px;width:40%}.wiki_difftable
td{width:50%;float:left}.wiki_histdate{text-align:left}.wiki_histnewdate{border-top:1px dotted gray}.ouw_deleted{background:#FFA;color:red;text-decoration:line-through}.ouw_added{background:#CFC;color:red}a.wiki_newentry:link,a.wiki_newentry:visited{color:red;font-style:italic}.wiki_newentry
a{color:red;font-style:italic}#intro.generalbox{margin-top:10px;padding:5px}.wiki_navigation_container{margin:0
auto}.wiki_navigation_from{float:left;width:40%;min-width:200px;margin-left:5%}.wiki_navigation_to{float:left;width:40%;min-width:200px;margin-right:5%}.wiki_headingtitle{text-align:center}.wiki_clear{clear:both}.wiki_right{text-align:right}.wiki_index{text-align:right}.notunderlined{text-decoration:none}a.wiki_edit_section{font-size:0.6em;vertical-align:top;position:relative;float:right}.midpad{text-align:center;margin-top:0.4em;margin-bottom:0.4em}.block_wiki_search
ul{margin-top:0.5em;margin-bottom:3px}.wiki-attachment:before{content:url("/mod/wiki/pix/attachment.png");padding-right:2px}#wiki_printable_content{text-align:left}.dir-rtl
#wiki_printable_content{text-align:right}#wiki_printable_content
a{color:black}#wiki_printable_title{font-size:2.2em;text-decoration:underline}.wiki_diff_boxes{width:100%;clear:both}.wiki_diff_paging{width:100%;clear:both}.wiki_grayline{color:gray}.wikisearchresults{padding-left:50px;padding-top:20px}.wiki-diff-container{width:95%;margin:10px
auto}.wiki-diff-container .wiki-diff-leftside,
.wiki-diff-container .wiki-diff-rightside{width:49.5%;margin:0;padding:0;float:left}.wiki-diff-container .wiki-diff-rightside{margin-left:1%}.wiki-diff-container .wiki-diff-heading,
.wiki-diff-container .no-overflow{padding:10px;border:1px
solid #DDD}.wiki-diff-container .wiki-diff-rightside
.wiki_diffversion{text-align:right}.wikieditor-toolbar
img{width:22px;height:22px;vertical-align:middle}.path-mod-wiki
.printicon{background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/print) no-repeat scroll 2px center transparent;padding-left:20px}#page-mod-wiki-prettyview
.displayprinticon{text-align:right}.path-mod-workshop
.collapsibleregion{margin-bottom:0.75em}.path-mod-workshop
.collapsibleregioncaption{font-weight:bold;font-size:120%}.path-mod-workshop
div.singlebutton{text-align:center;margin:0.75em auto}.path-mod-workshop #workshop-viewlet-assignedassessments div.singlebutton,
.path-mod-workshop #workshop-viewlet-allexamples div.singlebutton,
.path-mod-workshop #workshop-viewlet-examples
div.singlebutton{text-align:left}.path-mod-workshop
.groupwidget{text-align:center;margin:0.75em auto}.path-mod-workshop
.perpagewidget{text-align:center;margin:0.75em auto}.path-mod-workshop .submission-summary{position:relative;margin-bottom:10px}.path-mod-workshop .submission-summary .title,
.path-mod-workshop .submission-summary .author,
.path-mod-workshop .submission-summary .author .fullname,
.path-mod-workshop .submission-summary .author
.picture{display:inline}.path-mod-workshop .submission-summary .title,
.path-mod-workshop .submission-summary .userdate,
.path-mod-workshop .submission-summary .grade-status{margin:0px
0px 0px 40px}.path-mod-workshop .submission-summary
.author{margin-left:1ex}.path-mod-workshop .submission-summary.anonymous .title,
.path-mod-workshop .submission-summary.anonymous .author,
.path-mod-workshop .submission-summary.anonymous .userdate,
.path-mod-workshop .submission-summary.anonymous .grade-status{margin:0px
0px 0px 5px}.path-mod-workshop .submission-summary
.userdate{font-size:x-small;color:#333}.path-mod-workshop .submission-summary .userdate
span{font-style:italic}.path-mod-workshop .submission-summary .author
.picture{position:absolute;top:0px;left:0px}.path-mod-workshop .submission-full{border:1px
solid #ddd;margin:0px
0px 1em 0px}.path-mod-workshop .submission-full
.header{position:relative;background-color:#ddd;padding:3px;min-height:67px}.path-mod-workshop .submission-full .header .title,
.path-mod-workshop .submission-full .header .author,
.path-mod-workshop .submission-full .header
.userdate{margin:0px
0px 0px 80px}.dir-rtl.path-mod-workshop .submission-full .header .title,
.dir-rtl.path-mod-workshop .submission-full .header .author,
.dir-rtl.path-mod-workshop .submission-full .header
.userdate{margin:0px
80px 0px 0px}.path-mod-workshop .submission-full.anonymous .header .title,
.path-mod-workshop .submission-full.anonymous .header .author,
.path-mod-workshop .submission-full.anonymous .header
.userdate{margin:0px
0px 0px 5px}.path-mod-workshop .submission-full .header
.userdate.created{padding-right:10px}.path-mod-workshop .submission-full .header
.userdate.modified{padding-left:10px;margin-left:0px;border-left:1px solid #000}.path-mod-workshop .submission-full .header
.userdate{font-size:x-small;color:#333;display:inline}.path-mod-workshop .submission-full .header .userdate
span{font-style:italic}.path-mod-workshop .submission-full .header .author
.picture{position:absolute;top:3px;left:3px}.dir-rtl.path-mod-workshop .submission-full .header .author
.picture{right:3px;left:auto}.path-mod-workshop .submission-full .content,
.path-mod-workshop .submission-full
.attachments{padding:5px
10px}.path-mod-workshop .submission-full .attachments .files
img.icon{margin-right:5px}.path-mod-workshop .submission-full .attachments .images
div{display:inline-block;margin:5px;padding:5px;border:1px
solid #ddd}.path-mod-workshop .submission-summary.example .title,
.path-mod-workshop .submission-summary.example
.userdate{margin:0px
0px 0px 0px}.path-mod-workshop .submission-full.example
.header{min-height:0px}.path-mod-workshop .submission-full.example .header
.title{margin:0px
0px 0px 0px}.path-mod-workshop
.message{padding:5px
5em 5px 15px;margin:0px
auto 20px auto;width:100%;font-size:80%;position:relative}.path-mod-workshop .message
.singlebutton{text-align:left;margin:0px}.path-mod-workshop
.message.ok{color:#547c22;background-color:#e7f1c3}.path-mod-workshop
.message.error{color:#dd0221;background-color:#ffd3d9}.path-mod-workshop
.message.info{color:#1666a9;background-color:#d2ebff}.path-mod-workshop .allocation-init-results{margin:10px
auto;width:100%;font-size:80%}.path-mod-workshop .allocation-init-results
.indent{margin-left:20px}.path-mod-workshop .allocation-init-results
.ok{color:#547c22;background-color:#e7f1c3}.path-mod-workshop .allocation-init-results
.error{color:#dd0221;background-color:#ffd3d9}.path-mod-workshop .allocation-init-results
.info{color:#1666a9;background-color:#d2ebff}.path-mod-workshop .allocation-init-results
.debug{color:black;background-color:#ddd}.path-mod-workshop
.userplan{width:100%;margin:1em
auto 1em auto;font-size:80%;border:1px
solid #ddd}.path-mod-workshop .userplan
th{vertical-align:bottom;white-space:normal;color:#999;border-top:1px solid #ddd;border-bottom:1px solid #ddd;padding:3px}.path-mod-workshop .userplan
th.active{vertical-align:top;color:black;font-size:140%;border:1px
solid #ddd;border-bottom:0;background:#e7f1c3}.path-mod-workshop .userplan
td{width:20%;vertical-align:top;border-right:1px solid #ddd;background-color:#f5f5f5}.path-mod-workshop .userplan td,
.path-mod-workshop .userplan td a,
.path-mod-workshop .userplan td a:link,
.path-mod-workshop .userplan td a:hover,
.path-mod-workshop .userplan td a:visited,
.path-mod-workshop .userplan td a:active{color:#999}.path-mod-workshop .userplan td.active,
.path-mod-workshop .userplan td.active a,
.path-mod-workshop .userplan td.active a:link,
.path-mod-workshop .userplan td.active a:hover,
.path-mod-workshop .userplan td.active a:visited,
.path-mod-workshop .userplan td.active a:active{color:black}.path-mod-workshop .userplan
td.lastcol{border-right:0}.path-mod-workshop .userplan
td.active{border-left:1px solid #ddd;border-right:1px solid #ddd;background-color:#e7f1c3}.path-mod-workshop .userplan th
.actions{display:inline}.path-mod-workshop .userplan tr.phasetasks
li{background-image:url(/sunguru/theme/image.php/archaius/mod_workshop/1531975376/userplan/task-todo);background-position:top left;background-repeat:no-repeat;list-style-type:none;min-height:16px;margin: .3em 0}.dir-rtl.path-mod-workshop .userplan tr.phasetasks
li{background-position:top right}.path-mod-workshop .userplan tr.phasetasks
li.completed{background-image:url(/sunguru/theme/image.php/archaius/mod_workshop/1531975376/userplan/task-done)}.path-mod-workshop .userplan tr.phasetasks
li.fail{background-image:url(/sunguru/theme/image.php/archaius/mod_workshop/1531975376/userplan/task-fail)}.path-mod-workshop .userplan tr.phasetasks
li.info{background-image:url(/sunguru/theme/image.php/archaius/mod_workshop/1531975376/userplan/task-info)}.path-mod-workshop .userplan tr.phasetasks
.tasks{list-style:none;margin:3px;padding:0px}.path-mod-workshop .userplan tr.phasetasks
.title{padding:0px
10px 0px 20px}.dir-rtl.path-mod-workshop .userplan tr.phasetasks
.title{padding:0px
20px 0px 10px}.path-mod-workshop .userplan tr.phasetasks
.details{padding:0px
10px 0px 25px;font-size:80%}.dir-rtl.path-mod-workshop .userplan tr.phasetasks
.details{padding:0px
25px 0px 10px}.path-mod-workshop .assessment-full{border:1px
solid #ddd;margin:0px
auto 1em auto}.path-mod-workshop .assessment-full
.header{position:relative;background-color:#ddd;padding:3px;min-height:35px}.path-mod-workshop .assessment-full .header
.title{font-weight:bold}.path-mod-workshop .assessment-full .header .title,
.path-mod-workshop .assessment-full .header .reviewer,
.path-mod-workshop .assessment-full .header .grade,
.path-mod-workshop .assessment-full .header
.weight{margin:0px
0px 0px 40px}.dir-rtl.path-mod-workshop .assessment-full .header .title,
.dir-rtl.path-mod-workshop .assessment-full .header .reviewer,
.dir-rtl.path-mod-workshop .assessment-full .header .grade,
.dir-rtl.path-mod-workshop .assessment-full .header
.weight{margin:0px
40px 0px 0px}.path-mod-workshop .assessment-full.anonymous .header .title,
.path-mod-workshop .assessment-full.anonymous .header .reviewer,
.path-mod-workshop .assessment-full.anonymous .header .grade,
.path-mod-workshop .assessment-full.anonymous .header
.weight{margin:0px
0px 0px 5px}.path-mod-workshop .assessment-full .header .reviewer
.picture{position:absolute;top:3px;left:3px}.dir-rtl.path-mod-workshop .assessment-full .header .reviewer
.picture{right:3px;left:auto}.path-mod-workshop .assessment-full .header
.actions{position:absolute;top:5px;right:5px;text-align:right}.path-mod-workshop .assessment-full .header .actions .singlebutton,
.path-mod-workshop .assessment-full .header .actions .singlebutton form,
.path-mod-workshop .assessment-full .header .actions .singlebutton form
div{display:inline}.path-mod-workshop .assessment-full .assessment-form-wrapper,
.path-mod-workshop .assessment-full .overall-feedback-wrapper{margin-top:0.5em;padding:0px
1em}.path-mod-workshop .assessment-summary.graded .singlebutton input[type="submit"],
.path-mod-workshop .example-summary.graded .singlebutton input[type="submit"]{background-color:#e7f1c3}.path-mod-workshop .assessment-summary.notgraded .singlebutton input[type="submit"],
.path-mod-workshop .example-summary.notgraded .singlebutton input[type="submit"]{background-color:#ffd3d9}.path-mod-workshop .assessment-full .overallfeedback .content,
.path-mod-workshop .assessment-full .overallfeedback
.attachments{padding:5px
10px}.path-mod-workshop .assessment-full .overallfeedback .attachments .files
img.icon{margin-right:5px}.path-mod-workshop .assessment-full .overallfeedback .attachments .images
div{display:inline-block;margin:5px;padding:5px;border:1px
solid #ddd}.path-mod-workshop .assessmentform
.description{margin:0px
1em}.path-mod-workshop .grading-report{width:100%;margin:1em
auto 1em auto;font-size:80%;border:1px
solid #ddd}.path-mod-workshop .grading-report
.userpicture{margin:0px
3px;vertical-align:middle}.path-mod-workshop .grading-report
del{color:red;font-size:90%;text-decoration:line-through}.path-mod-workshop .grading-report
ins{color:green;font-weight:bold;text-decoration:underline}.path-mod-workshop .grading-report
th{white-space:normal}.path-mod-workshop .grading-report
td{vertical-align:top;border:1px
solid #ddd}.path-mod-workshop .grading-report tr.published
td.submission{background-color:#d2ebff}.path-mod-workshop .grading-report tr.published td.submission
a{font-weight:bold}.path-mod-workshop .grading-report
.assessmentdetails{white-space:nowrap}.path-mod-workshop .grading-report .receivedgrade span.grade,
.path-mod-workshop .grading-report .givengrade
span.gradinggrade{font-weight:bold}.path-mod-workshop .grading-report .submissiongrade.cell,
.path-mod-workshop .grading-report
.gradinggrade.cell{text-align:center;font-size:200%;white-space:nowrap}.path-mod-workshop .grading-report .givengrade.null .user,
.path-mod-workshop .grading-report .receivedgrade.null
.user{color:#e00}.path-mod-workshop #workshop-viewlet-yourgrades
.finalgrades{text-align:center}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade{border:1px
solid #ddd;margin:1em;padding:2em;display:inline-block;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade.submissiongrade{background-color:#d2ebff}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade.assessmentgrade{background-color:#eee}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades .grade
.gradevalue{font-weight:bold;font-size:x-large;margin:10px}#mod-workshop-editform fieldset.fgroup
*{vertical-align:top}.path-mod-workshop
.feedback{border:1px
solid #ddd;margin:0px
auto 1em auto;width:100%}.path-mod-workshop .feedback
.header{position:relative;background-color:#ddd;padding:3px;min-height:35px}.path-mod-workshop .feedback .header
.title{margin:0px
0px 0px 40px}.path-mod-workshop .feedback .header
.picture{position:absolute;top:3px;left:3px}.path-mod-workshop .feedback
.content{padding:5px
10px}.path-mod-workshop
div.buttonsbar{text-align:center}.path-mod-workshop div.buttonsbar
.singlebutton{display:inline}.path-mod-workshop
.toolboxaction{margin-right:1em}.path-mod-workshop .toolboxaction,
.path-mod-workshop .toolboxaction .singlebutton,
.path-mod-workshop .toolboxaction .singlebutton form,
.path-mod-workshop .toolboxaction .singlebutton form
div{display:inline}.path-mod-workshop div.buttonwithhelp
div{display:inline}.path-mod-workshop
#evaluationmethodchooser{margin:2em
auto;text-align:center}.path-mod-workshop
.lastmodified{line-height:1.0em}.path-mod-workshop
.nothingfound{font-size:150%;color:#FF4500}.path-mod-workshop .workshop-risk-dataloss{vertical-align:text-bottom}.block_activity_results{text-align:center}.block_activity_results
h1{margin:4px;font-size:1.1em}.block_activity_results
table.grades{text-align:left;width:100%}.block_activity_results table.grades
.number{text-align:left;width:10%}.block_activity_results table.grades
.name{text-align:left;width:77%}.block_activity_results table.grades
.grade{text-align:right}.block_activity_results table.grades
caption{font-weight:bold;font-size:18px}.dir-rtl .block_activity_results
table.grades{text-align:right}.dir-rtl .block_activity_results table.grades
.number{text-align:right}.dir-rtl .block_activity_results table.grades
.name{text-align:right}#page-blocks-community-communitycourse
.hubscreenshot{float:left}#page-blocks-community-communitycourse
.hubtitlelink{color:#999}#page-blocks-community-communitycourse
.hubsmalllogo{padding-left:3px;padding-right:7px;float:left}#page-blocks-community-communitycourse
.hubtext{display:block;width:68%;padding-left:165px}#page-blocks-community-communitycourse
.hubimgandtext{display:table}#page-blocks-community-communitycourse
.hubimage{float:left;display:block;width:100px}#page-blocks-community-communitycourse
.hubdescriptiontext{}#page-blocks-community-communitycourse
.hubstats{padding-top:10px}#page-blocks-community-communitycourse .hubstats
.iconhelp{float:left;padding-right:3px}#page-blocks-community-communitycourse
.hubadditionaldesc{color:#666;font-size:90%;display:block}#page-blocks-community-communitycourse
.hubscreenshot{margin-right:10px}#page-blocks-community-communitycourse
.hubnottrusted{}#page-blocks-community-communitycourse
.hubtrusted{display:inline}#page-blocks-community-communitycourse
.hubnottrusted{}#page-blocks-community-communitycourse
.trustedtr{background-color:#ffe1c3}#page-blocks-community-communitycourse
.prioritisetr{background-color:#ffd4ff}#page-blocks-community-communitycourse
.blockdescription{font-size:80%;color:#555}#page-blocks-community-communitycourse
.trusted{font-size:90%;color:#063;font-weight:normal;font-style:italic}#page-blocks-community-communitycourse
.additionaldesc{font-size:80%;color:#8B8989}#page-blocks-community-communitycourse .comment-link{font-size:80%;color:#555}#page-blocks-community-communitycourse
.coursescreenshot{text-align:center;cursor:pointer}#page-blocks-community-communitycourse
.hubcourseinfo{margin-left:15px}#page-blocks-community-communitycourse
.coursesitelink{}#page-blocks-community-communitycourse
.pagingbar{text-align:center}#page-blocks-community-communitycourse
.coursecomment{float:right}#page-blocks-community-communitycourse
.courseoperations{margin-top:9px;text-align:center}#page-blocks-community-communitycourse .hubcoursedownload:hover{background-color:#CDC9C9}#page-blocks-community-communitycourse
.courselinks{float:right;width:180px}#page-blocks-community-communitycourse
.ratingaggregate{float:left;padding-right:4px}#page-blocks-community-communitycourse
.hubcourserating{padding-top:3px;font-size:80%;color:#555}#page-blocks-community-communitycourse
.coursedescription{width:70%;float:left}#page-blocks-community-communitycourse
.fullhubcourse{margin-bottom:20px}#page-blocks-community-communitycourse
.hubcoursetitlepanel{margin-bottom:6px}#page-blocks-community-communitycourse
.hubcourseresult{background:none repeat scroll 0 0 #FFF;clear:both;margin:30px
auto 0;z-index:90;width:95%;padding:10px
10px 10px 10px;border-style:solid;border-width:1px}#page-blocks-community-communitycourse
.hubcoursetitle{-webkit-box-shadow:rgba(0, 0, 0, 0.546875) 0px 0px 4px;-moz-box-shadow:rgba(0, 0, 0, 0.546875) 0px 0px 4px;background:#8B8989;left:-15px;position:relative;z-index:0;border:0px;margin:0px;outline:0px;padding:0px;vertical-align:baseline;color:#fff;padding-top:6px;padding-bottom:6px;text-shadow:1px 1px 2px rgba(0,0,0,0.2);text-align:left;font-style:italic;font-weight:normal;line-height:1.2em;font-size:140%;width:102%;text-indent:15px}#page-blocks-community-communitycourse
.hubcoursedownload{display:inline-block;padding:5px
8px 6px;color:black;text-decoration:none;-moz-border-radius:6px;-webkit-border-radius:6px;-moz-box-shadow:0 1px 3px rgba(0,0,0,0.6);-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.6);border-bottom:1px solid rgba(0,0,0,0.25);position:relative;cursor:pointer;background-color:#EEE9E9;margin-left:6px;font-size:95%;margin-bottom:9px}#page-blocks-community-communitycourse .comment-list
li{background-color:#FFFAFA !important;-moz-border-radius:6px;-webkit-border-radius:6px;padding-right:4px;padding-bottom:2px}#page-blocks-community-communitycourse
.ratingcount{color:#8B8989;font-size:80%;vertical-align:top}#page-blocks-community-communitycourse
.norating{font-weight:bold;color:#8B8989;font-size:80%}#page-blocks-community-communitycourse .star-rating{list-style:none;margin:4px
0 4px;padding:0px;width:100px;height:20px;position:relative;background:url(/sunguru/theme/image.php/archaius/core/1531975376/i/star-rating) top left repeat-x;float:left}#page-blocks-community-communitycourse .star-rating
li{padding:0px;margin:0px;height:20px;width:20px;float:left}#page-blocks-community-communitycourse .star-rating li.current-rating{background:url(/sunguru/theme/image.php/archaius/core/1531975376/i/star-rating) left bottom;position:absolute;height:20px;display:block;text-indent:-9000px;z-index:1}#page-blocks-community-communitycourse
.nocomments{font-weight:bold;color:#8B8989;font-size:80%}#page-blocks-community-communitycourse
.hubcommentator{float:left;font-weight:bold}#page-blocks-community-communitycourse
.hubcommentdate{font-weight:bold}#page-blocks-community-communitycourse
.hubcommenttext{margin-bottom:10px}#page-blocks-community-communitycourse
.hubnoscriptcoursecomments{margin-left:5px}#page-blocks-community-communitycourse .yui3-overlay-loading{top:-1000em;left:-1000em;position:absolute;z-index:1000}#page-blocks-community-communitycourse
.hubcoursecomments{display:inline-block;padding:3px
3px 3px 3px;color:white;text-decoration:none;-moz-border-radius:6px;-webkit-border-radius:6px;position:relative;cursor:pointer;background-color:#8B8989;margin-left:0px;font-size:80%;margin-top:15px}#page-blocks-community-communitycourse
.hubrateandcomment{font-size:80%}#page-blocks-community-communitycourse
.hubcourseoutcomes{}#page-blocks-community-communitycourse
.nextlink{text-align:center;margin-top:6px}#page-blocks-community-communitycourse
.textinfo{text-align:center}#ss-mask{z-index:10;position:fixed;top:0;left:0;bottom:0;right:0;opacity:0.35;filter:alpha(opacity=35);background:#000}.hiddenoverlay{display:none;text-align:center}.imagearrow{font-size:120%;display:inline;cursor:pointer}.imagetitle{display:inline;cursor:pointer}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue{-moz-border-radius:12px 12px 12px 12px;-moz-box-shadow:0 1px 3px rgba(0, 0, 0, 0.6);-webkit-border-radius:12px 12px 12px 12px;-webkit-box-shadow:0 1px 3px rgba(0, 0, 0, 0.6);border-width:0 0 0 0}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-wrap{-moz-border-radius:12px 12px 0px 0px;-webkit-border-radius:12px 12px 0px 0px;background-color:#FFF;border:1px
solid #555}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-hd{-moz-border-radius:12px 12px 0 0;-webkit-border-radius:12px 12px 0 0;background-color:#F6F6F6;border:1px
solid #CCC;overflow:auto;padding:7px
6px}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-bd{padding:0px;margin-bottom:-5px}#page-blocks-community-communitycourse .moodle-dialogue-base
.closebutton{margin-top:4px;margin-right:4px}.block_completion_progress
.content{text-align:left}.block_completion_progress
.barContainer{overflow:hidden;position:relative;padding:0}.block_completion_progress .left-arrow-svg,
.block_completion_progress .right-arrow-svg{position:absolute;top:calc(50% - 15px);display:none}.block_completion_progress .triangle-polygon{fill:rgba(0, 0, 0, 0.3);stroke:white;stroke-width:3px}.block_completion_progress .nowRow,
.block_completion_progress
.barRow{padding:0;width:100%;margin:0;height:25px;display:table}.block_completion_progress .nowRow
.blankDiv{display:table-cell;height:25px}.block_completion_progress
.progressBarCell{height:25px;margin:0
-1px 0 0;padding:0;text-align:center;vertical-align:middle;cursor:pointer;border-left:solid 1px #e3e3e3;border-top:solid 1px #e3e3e3;position:relative}#page-blocks-completion_progress-overview .block_completion_progress
.progressBarCell{position:inherit}.block_completion_progress .progressBarCell
.nowDiv{position:absolute;top:-25px;white-space:nowrap;width:100px}.block_completion_progress .progressBarCell
.firstNow{left:0;text-align:left}.dir-rtl .block_completion_progress .progressBarCell
.firstNow{right:0;text-align:right}.block_completion_progress .progressBarCell
.firstHalfNow{left:100%;text-align:left}.dir-rtl .block_completion_progress .progressBarCell
.firstHalfNow{right:100%;left:initial;text-align:right}.block_completion_progress .progressBarCell
.lastHalfNow{right:0;text-align:right}.dir-rtl .block_completion_progress .progressBarCell
.lastHalfNow{left:0;text-align:left;right:initial}.block_completion_progress .progressBarCell
.nowicon{width:auto}.block_completion_progress
.progressBarCell.firstProgressBarCell{border-radius:4px 0 0 4px;border-left:none;border-right:solid 1px #e3e3e3}.dir-rtl .block_completion_progress
.progressBarCell.firstProgressBarCell{border-radius:0px 4px 4px 0px;border-left:solid 1px #e3e3e3}.block_completion_progress
.progressBarCell.lastProgressBarCell{border-radius:0 4px 4px 0}.dir-rtl .block_completion_progress
.progressBarCell.lastProgressBarCell{border-radius:4px 0px 0px 4px;border-left:none;border-right:solid 1px #e3e3e3}.block_completion_progress .progressBarCell
img{height:auto;margin:1px
0 0 0;max-height:15px;max-width:15px;padding:0;vertical-align:middle;width:85%}.block_completion_progress .progressEventInfo,
.block_completion_progress
.progressPercentage{font-size:x-small;text-align:left;white-space:pre;overflow:hidden;padding:0;margin:5px}.block_completion_progress .progressEventInfo .iconInInfo,
#fitem_id_config_progressBarIcons
.iconOnConfig{height:1.2em}#page-blocks-completion_progress-overview
.overviewTable{margin:10px
0;width:100%;table-layout:fixed}.block_completion_progress .progressEventInfo
img{vertical-align:middle}.block_completion_progress
.moduleIcon{float:left;margin-right:5px;max-width:24px}.block_completion_progress
.progressBarHeader{font-size:90%;margin:0;padding:0}.block_completion_progress
h3{margin-bottom:0}.block_completion_progress
.expectedBy{margin:5px
auto}.progressWarningBox{border:2px
solid #F00;padding:10px;background-color:#F66;color:white;margin:10px
0;font-size:large;font-weight:bold}.progressConfigBox{border-bottom:1px dashed #ccc;padding:5px;margin:0
0 5px 0 !important}.progressConfigModuleTitle{font-weight:bold}.progressConfigModuleTitle
img{vertical-align:middle}.block_completion_progress
.overviewButton{margin:10px;text-align:center}#page-blocks-completion_progress-overview
.buttons{margin-top:20px;text-align:left}#page-blocks-completion_progress-overview .buttons
label{display:inline;margin:0
5px 0 10px}#page-blocks-completion_progress-overview
.progressoverviewmenus{text-align:left;margin-bottom:5px}#page-blocks-completion_progress-overview .progressoverviewmenus
.singleselect{text-align:left;margin-right:10px}#page-blocks-completion_progress-overview .progressoverviewmenus form,
#page-blocks-completion_progress-overview .progressoverviewmenus select,
#page-blocks-completion_progress-overview .progressoverviewmenus div,
#page-blocks-completion_progress-overview .paging,
#page-blocks-completion_progress-overview
#showall{display:inline}#page-blocks-completion_progress-overview
#showall{margin-left:10px}#page-blocks-completion_progress-overview .progressoverviewmenus
select{margin-left:2px}@import url("../blocks/configurable_reports/js/datatables/media/css/jquery.dataTables.css");@import url("../blocks/configurable_reports/js/codemirror/lib/codemirror.css");@import url("../blocks/configurable_reports/js/codemirror/addon/display/fullscreen.css");.dir-rtl
.CodeMirror{direction:ltr;text-align:left}#page-blocks-configurable_reports-editreport.dir-rtl textarea,
#page-blocks-configurable_reports-editreport.dir-rtl
.felement.fstatic{text-align:left;direction:ltr}#reportslist
th.header{padding:0
20px}#page-blocks-configurable_reports-managereport .generaltable
td.c5{direction:ltr}#page-admin-setting-blocksettingconfigurable_reports.dir-rtl .settingsform input[type=text],
#page-admin-setting-blocksettingconfigurable_reports.dir-rtl .settingsform input[type=password]{text-align:left;direction:ltr}#page-blocks-configurable_reports-viewreport
.generaltable{border:1px
solid gray;margin:0
auto}#page-blocks-configurable_reports-viewreport
#calcstable{width:80%}#page-blocks-configurable_reports-viewreport .generaltable
th.header{background-color:#f5f5dc;border-bottom-width:2px}#page-blocks-configurable_reports-viewreport #totalrecords,
#page-blocks-configurable_reports-viewreport
#lastexecutiontime{padding:10px;text-align:center}.addbutton{text-align:center}.linkbutton{-moz-box-shadow:inset 0px 1px 0px 0px #dcecfb;-webkit-box-shadow:inset 0px 1px 0px 0px #dcecfb;box-shadow:inset 0px 1px 0px 0px #dcecfb;background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #bddbfa), color-stop(1, #80b5ea) );background:-moz-linear-gradient( center top, #bddbfa 5%, #80b5ea 100% );filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#bddbfa', endColorstr='#80b5ea');background-color:#bddbfa;-webkit-border-top-left-radius:0px;-moz-border-radius-topleft:0px;border-top-left-radius:0px;-webkit-border-top-right-radius:0px;-moz-border-radius-topright:0px;border-top-right-radius:0px;-webkit-border-bottom-right-radius:0px;-moz-border-radius-bottomright:0px;border-bottom-right-radius:0px;-webkit-border-bottom-left-radius:0px;-moz-border-radius-bottomleft:0px;border-bottom-left-radius:0px;text-indent:0;border:1px
solid #84bbf3;display:inline-block;color:#fff;font-family:Arial;font-size:15px;font-weight:bold;font-style:normal;height:30px;line-height:30px;width:100px;text-decoration:none;text-align:center;text-shadow:1px 1px 0px #528ecc}.linkbutton:hover{background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #80b5ea), color-stop(1, #bddbfa) );background:-moz-linear-gradient( center top, #80b5ea 5%, #bddbfa 100% );filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#80b5ea',endColorstr='#bddbfa');background-color:#80b5ea}.linkbutton:active{position:relative;top:1px}.block_course_list
.footer{margin-top:5px}.block_course_list .content
li{margin-bottom: .3em}.block_course_overview
.coursechildren{font-weight:normal;font-style:italic}.block_course_overview
.categorypath{text-align:right}.dir-rtl .block_course_overview
.categorypath{text-align:left}.block_course_overview
.content{margin:0
20px}.block_course_overview .content
.notice{margin:5px
0}.block_course_overview
.coursebox{padding:15px;width:auto}.block_course_overview
.profilepicture{float:left}.dir-rtl.block_course_overview
.profilepicture{float:right}.block_course_overview
.welcome_area{width:100%;padding-bottom:5px}.block_course_overview
.welcome_message{float:left;padding:10px;vertical-align:middle;border-collapse:separate;clear:none}.dir-rtl .block_course_overview
.welcome_message{float:right}.block_course_overview .content
h2.title{float:left;margin:0
0 .5em 0;position:relative}.dir-rtl .block_course_overview .content
h2.title{float:right}.block_course_overview
.course_title{position:relative}.editing .block_course_overview .coursebox
.cursor{cursor:move;margin-bottom:2px}.editing .block_course_overview
.move{float:left;padding:2px
10px 0 0}.dir-rtl.editing .block_course_overview
.move{float:right;padding:2px
10px}.block_course_overview
.course_list{width:100%}.block_course_overview
div.flush{clear:both}.block_course_overview
.activity_info{clear:both}.dir-rtl .block_course_overview
.activity_info{margin-right:25px}.block_course_overview
.activity_overview{padding:2px}.block_course_overview .activity_overview
img.iconlarge{vertical-align:text-bottom;margin-right:6px}.dir-rtl .block_course_overview .activity_overview
img.iconlarge{margin-left:6px;margin-right:0}.block_course_overview
.singleselect{text-align:left;margin:0}.dir-rtl .block_course_overview
.singleselect{text-align:right}.block_course_overview .content .course_list
.movehere{margin-bottom:15px}.block_course_summary
.content{padding:10px}.block_course_summary
.editbutton{text-align:right}div.configure{float:right;width:100px}form.dashboard-filters{margin:1px;padding:2px
8px;border:solid 1px #9B5992}form.dashboard-filters
input{margin:1px;padding:1px}div.dashboard-query-box{margin:1px;border:solid 1px #9B5992;color:#8080A0;background-color:#E0E9F1}table.dashboard-table{border:1px
solid #7E7ACB;border-collapse:separate;padding:2px}table.dashboard-table
td{border:1px
solid white}.dashboard-table
.hkey{background-color:#9996D6;color:white;font-weight:bolder;font-size:1.1em;padding:1px
5px}.dashboard-horiz-serie{background-color:#C2C0E7;text-align:center;font-weight:bolder;border:2px
solid white;margin-top:2px}.dashboard-table
.vkey{padding:1px
5px}.dashboard-table
.vkey.c0{background-color:#48447D;color:white;font-weight:bolder;font-size:1.1em}.dashboard-table
.vkey.c1{background-color:#5B56A3;color:#F0F0F7;font-weight:bolder;font-size:1.1em}.dashboard-table
.vkey.c2{background-color:#746CB3;color:white;font-weight:bolder;font-size:1.1em}.dashboard-table
.vkey.c3{background-color:#948EC4;color:white;font-weight:bolder;font-size:1.1em}.dashboard-table
.vkey.c4{background-color:#9D98C9;color:white;font-weight:bolder;font-size:1.1em}.dashboard-table
.vkey.c5{background-color:#AFABD3;color:black;font-weight:bolder;font-size:1.1em}.dashboard-table
.vkey.c6{background-color:#BEBBDB;color:black;font-weight:bolder;font-size:1.1em}.dashboard-table
.data{border:1px
solid #A0A0A0;text-align:right}.dashboard-table
.empty{border:1px
solid #F0F0F0;background-color:#F8F8F8}div.dashboard-special{background-color:#EEFAA9;color:#5B5A44;font-size:0.8em}.dashboard-tree1
li{font-size:1.1em;line-height:1.3em}.dashboard-tree2
li{font-size:1.0em;line-height:1.2em}.dashboard-tree3
li{font-size:0.9em;line-height:1.1em}.dashboard-tree4
li{font-size:0.8em;line-height:1.0em}.dashboard-table
td.coltotal{text-align:right}.timeline-event-label{font-size:0.8em;margin-left:20px}.jqplot-table-legend-swatch{border-width:4px;margin:1px;width:9px;height:9px;border-style:solid}.jqplot-xaxis-tick{margin-top:10px}.jqplot-yaxis-label{left:-40px !important}.off{display:none !important}.on{display:block}.dashboard-sql-params{margin-top:2px;font-size:0.85em;display:inline}#dashboardsettings-menu
LI{line-height:1.7em}.block-dashboard-entrylist{padding:20px}.dashboard-panel{overflow:scroll;font-size:0.9em}.dashbobard-filter-query{padding:1px;border:1px
solid #808080;margin:2px;font-size:0.75em;font-family:monospace}.dashboard-query-box{padding:1px;border:1px
solid #808080;margin:2px;font-size:0.75em;font-family:monospace}table.dashboard-setup{width:100%}table.dashboard-setup
td{padding:10px}.dhtmlxcalendar_container{background-color:#fdfdfd;border:#fbfbfb solid 1px;border-radius:3px;box-shadow:10px 10px 5px #888;font-size:1.05em}.block_globalsearch
.searchform{text-align:center}.block_globalsearch
.footer{text-align:center}.links-bold{font-weight:bold}.links-italic{font-style:italic}.block_lp.block .content
h3{padding:0;text-transform:none}.block_lp .sub-content{padding:0
15px}.block_lp
ul{list-style:none;margin:0}.block_lp ul
.more{padding-top:10px}#mod-massaction-control-section-list-select{width:99%}#mod-massaction-control-section-list-moveto{margin-left:0.5em;max-width:95%}#mod-massaction-control-section-list-dupto{margin-left:0.5em;max-width:95%}#mod-massaction-control-deselectlist{float:right;position:relative}.block_massaction .massaction-action{margin-left:0.5em;position:relative}#mod-massaction-help-icon{padding:0.2em;text-align:center}#block_massaction_module_list
th{padding-bottom:0.1em}.block_messages
.content{text-align:left;padding-top:5px}.block_messages .content .list
li.listentry{clear:both}.block_messages .content .list li.listentry
.user{float:left;position:relative}.block_messages .content .list li.listentry
.message{float:right}.block_messages .content
.info{text-align:center}.block_messages .content
.footer{clear:both}.dir-rtl .block_messages .content .list li.listentry
.user{float:right}.dir-rtl .block_messages .content .list li.listentry
.message{float:left}.block_my_grades
h1{margin:4px;font-size:1.1em}.block_my_grades
table.grades{text-align:left;width:100%;cell-spacing:1}.block_my_grades
th{text-align:left}.block_my_grades table.grades .number,
.block_my_grades table.grades
.grade{text-align:right;width:10%}.block_my_grades table.grades
caption{margin:1em
0px 0px 0px;border-bottom-width:1px;border-bottom-style:solid;font-weight:bold}.block_myprofile
img.profilepicture{height:100px;width:100px}.block_myprofile
.myprofileitem.fullname{font-size:1.5em;font-weight:bold}.block_myprofile
.myprofileitem.edit{text-align:right}.block_navigation .block_tree .depth_1>.tree_item.branch{padding-left:0;background-image:none}.block_navigation .block_tree .depth_1>ul{margin:0}.block_navigation .block_tree
ul{margin-left:18px}.block_navigation .block_tree
p.hasicon{text-indent:-21px;padding-left:21px}.block_navigation .block_tree p.hasicon
img{width:16px;height:16px;margin-top:3px;margin-right:5px;vertical-align:top}.block_navigation .block_tree
p.hasicon.visibleifjs{display:block}.block_navigation .block_tree
.tree_item{cursor:pointer;padding-left:0;margin:3px
0px;background-position:0 50%;background-repeat:no-repeat}.block_navigation .block_tree
.tree_item.branch{padding-left:21px}.block_navigation .block_tree
.active_tree_node{font-weight:bold}.block_navigation .block_tree [aria-expanded="true"]{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/expanded')}.block_navigation .block_tree [aria-expanded="false"]{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed')}.block_navigation .block_tree [aria-expanded="true"].emptybranch{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_empty')}.block_navigation .block_tree [aria-expanded="false"].loading{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/i/loading_small')}.block_navigation .block_tree [aria-hidden="false"]{display:block}.block_navigation .block_tree  [aria-hidden="true"]{display:none}.ie6 .block_navigation .block_tree
.tree_item{width:100%}.dir-rtl .block_navigation .block_tree
p.hasicon{padding-left:0px;padding-right:21px}.dir-rtl .block_navigation .block_tree
.tree_item{background-position:100% 50%}.dir-rtl .block_navigation .block_tree
.tree_item.branch{padding-right:21px;padding-left:0}.dir-rtl .block_navigation .block_tree [aria-expanded="false"]{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_rtl')}.dir-rtl .block_navigation .block_tree [aria-expanded="true"].emptybranch{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_empty_rtl')}.dir-rtl .block_navigation .block_tree [aria-expanded="false"].loading{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/i/loading_small')}.dir-rtl .block_navigation .block_tree .tree_item
img{margin-right:0;margin-left:5px}.dir-rtl .block_navigation .block_tree
ul{margin:0
16px 0 0}.block_online_users .content .list
li.listentry{clear:both}.block_online_users .content .list li.listentry
.user{float:left;position:relative}.block_online_users .content .list li.listentry .user
.userpicture{vertical-align:text-bottom}.block_online_users .content .list li.listentry
.message{float:right;margin-top:3px}.block_online_users .content
.info{text-align:center}.dir-rtl .block_online_users .content .list li.listentry
.user{float:right}.dir-rtl .block_online_users .content .list li.listentry
.message{float:left}.block_private_files .content
table{table-layout:fixed;width:100%}.block_private_files .content
.footer{padding:10px
0 0;margin-top: .5em}body.jsenabled .block_quickfindlist
.submitbutton{display:none}.block_quickfindlist
.quickfindprogress{visibility:hidden}.block_quickfindlist
ul{margin:0}.block_quickfindlist
li{list-style-type:none;margin-left:0;padding-bottom:0.2em;margin-bottom:0.2em;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:#d3d3d3}.quickfindlistsearch{width:10em}.block_recent_activity .activitydate,
.block_recent_activity
.activityhead{text-align:center}.block_recent_activity .unlist
li{margin-bottom:1em}.block_recent_activity li .head
.date{float:right}.dir-rtl .block_recent_activity .content
h3{text-align:right}.block_rss_client .list li:first-child{border-top-width:0}.block_rss_client .list
li{border-top:1px solid;padding:5px}.block_search_forums
.searchform{text-align:center}.block_search_forums .searchform
img{vertical-align:middle}.block_search_forums .searchform
img.resize{width:1em;height:1.1em}.block_search_forums
.invisiblefieldset{display:block}.block_settings .block_tree
ul{margin-left:18px}.block_settings .block_tree
p.hasicon{text-indent:-21px;padding-left:21px}.block_settings .block_tree p.hasicon
img{width:16px;height:16px;margin-top:3px;margin-right:5px;vertical-align:top}.block_settings .block_tree
p.hasicon.visibleifjs{display:block}.block_settings .block_tree
.tree_item.branch{padding-left:21px}.block_settings .block_tree
.tree_item{cursor:pointer;margin:3px
0px;background-position:0 50%;background-repeat:no-repeat}.block_settings .block_tree
.active_tree_node{font-weight:bold}.block_settings .block_tree [aria-expanded="true"]{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/expanded')}.block_settings .block_tree [aria-expanded="false"]{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed')}.block_settings .block_tree [aria-expanded="true"].emptybranch{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_empty')}.block_settings .block_tree [aria-expanded="false"].loading{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/i/loading_small')}.block_settings .block_tree [aria-hidden="false"]{display:block}.block_settings .block_tree  [aria-hidden="true"]{display:none}.ie6 .block_settings .block_tree
.tree_item{width:100%}.dir-rtl .block_settings .block_tree
p.hasicon{padding-left:0px;padding-right:21px}.dir-rtl .block_settings .block_tree
.tree_item{background-position:100% 50%}.dir-rtl .block_settings .block_tree
.tree_item.branch{padding-right:21px;padding-left:0}.dir-rtl .block_settings .block_tree [aria-expanded="false"]{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_rtl')}.dir-rtl .block_settings .block_tree [aria-expanded="true"].emptybranch{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_empty_rtl')}.dir-rtl .block_settings .block_tree [aria-expanded="false"].loading{background-image:url('/sunguru/theme/image.php/archaius/core/1531975376/i/loading_small')}.dir-rtl .block_settings .block_tree .tree_item
img{margin-right:0;margin-left:5px}.dir-rtl .block_settings .block_tree
ul{margin:0
16px 0 0}.block_sharing_cart .sc-indent-0{margin-left:0em}.block_sharing_cart .sc-indent-1{margin-left:1em}.block_sharing_cart .sc-indent-2{margin-left:2em}.block_sharing_cart .sc-indent-3{margin-left:3em}.block_sharing_cart .sc-indent-4{margin-left:4em}.block_sharing_cart .sc-indent-5{margin-left:5em}.block_sharing_cart .sc-indent-6{margin-left:6em}.block_sharing_cart .sc-indent-7{margin-left:7em}.block_sharing_cart .sc-indent-8{margin-left:8em}.block_sharing_cart .sc-indent-9{margin-left:9em}.block_sharing_cart .sc-indent-10{margin-left:10em}.block_sharing_cart .sc-indent-11{margin-left:11em}.block_sharing_cart .sc-indent-12{margin-left:12em}.block_sharing_cart .sc-indent-13{margin-left:13em}.block_sharing_cart .sc-indent-14{margin-left:14em}.block_sharing_cart .sc-indent-15{margin-left:15em}.block_site_main_menu
li{clear:both}.block_site_main_menu.block.list_block .unlist>li>.column{width:100%;display:table}.block_site_main_menu li
.buttons{float:right;margin:0}.dir-rtl .block_site_main_menu li
.buttons{float:left}.block_site_main_menu li .buttons a
img{vertical-align:text-bottom}.block_site_main_menu
.footer{margin-top:1em}.block_site_main_menu .section_add_menus noscript
div{display:inline}.block_site_main_menu .mod-indent,
.block_site_main_menu .main-menu-content{display:table-cell}.block_social_activities
li{clear:both}.block_social_activities li
.column{width:100%}.block_social_activities li
.buttons{float:right;margin:0}.dir-rtl .block_social_activities li
.buttons{float:left}.block_social_activities li .buttons a
img{vertical-align:text-bottom}.path-admin-blocks-workflow
h2{margin-top:0px}.block_workflow
table.workflow{margin:0;width:100%}.block_workflow
ul.block_workflow_todolist{margin:0}.block_workflow .block_workflow_todolist
li{list-style-type:none;margin:0;padding:0
0 0 22px;background:url(/sunguru/theme/image.php/archaius/block_workflow/1531975376/todo) no-repeat left top}.block_workflow .block_workflow_todolist
li.completed{text-decoration:line-through;background-image:url(/sunguru/theme/image.php/archaius/block_workflow/1531975376/done)}.block-workflow-panel .loading-lightbox{position:absolute;width:100%;height:100%;top:0;left:0;background-color:#FFF;min-width:50px;min-height:150px;text-align:center;opacity:0.5}.block-workflow-panel .loading-lightbox.hidden{display:none}.block-workflow-panel .loading-lightbox .loading-icon{margin-top:120px}.block-workflow-panel .wfk-submit{text-align:right}.block-workflow-panel .wfk-submit
.submitbutton{margin-right:0}#block-workflow-overview
.active{background-color:#bfc}#block-workflow-overview
.completed{background-color:#ebb}#block-workflow-overview
.aborted{background-color:#b11}#block-workflow-overview
.historyinfo{font-size:0.8em}#block-workflow-overview .historyinfo
p{margin:0.4em 0}#block-workflow-overview
.completeinfo{display:block;font-size:0.8em;white-space:nowrap}#block-workflow-overview
.dateinfo{display:block;font-size:0.8em}body.ie7 .moodle-dialogue-base .moodle-dialogue-hd
.closebutton{float:none;position:absolute;right:5px}#page-admin-blocks-workflow-manage #manage
td.c2{font-size:0.8em}#glossaryfilteroverlayprogress{position:fixed;top:50%;width:100%;text-align:center}.jsenabled
#MathJax_ZoomFrame{position:absolute}.mediaplugin_html5audio,.mediaplugin_html5video,.mediaplugin_swf,.mediaplugin_flv,.mediaplugin_real,.mediaplugin_youtube,.mediaplugin_vimeo,.mediaplugin_wmp,.mediaplugin_qt{display:block;margin-top:5px;margin-bottom:5px;text-align:center}.mediaplugin.mediaplugin_mp3
object{display:inline;height:15px;width:180px;margin-left:0.5em}.mp3flowplayer_backgroundColor{color:#000}.editor_atto_content_wrap{background-color:white;color:#333}.editor_atto_content{padding:4px;resize:vertical;overflow:auto}.editor_atto_content_wrap,.editor_atto+textarea{width:100%;padding:0;border:1px
solid #BBB;border-top:none}.editor_atto+textarea{border-radius:0;resize:vertical;margin-top:-1px}div.editor_atto_toolbar{display:block;background:#F2F2F2;min-height:35px;border:1px
solid #BBB;width:100%;padding:0
0 9px 0}div.editor_atto_toolbar
button{padding:4px
9px;background:none;border:0;margin:0;border-radius:0;cursor:pointer;line-height:initial}div.editor_atto_toolbar button+button{border-left:1px solid #CCC}div.editor_atto_toolbar button[disabled]{opacity: .45;background:none;cursor:default}.editor_atto_toolbar button:hover{background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%);background-color:#ebebeb}.editor_atto_toolbar button:active, .editor_atto_toolbar
button.highlight{background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%);background-color:#dfdfdf}div.editor_atto_toolbar button::-moz-focus-inner{border:0;padding:0}div.editor_atto_toolbar button
img.icon{padding:0px;margin:2px
0;vertical-align:text-bottom;width:auto;height:auto}div.editor_atto_toolbar
div.atto_group{display:inline-block;border:1px
solid #CCC;border-bottom:1px solid #B3B3B3;border-radius:4px;margin:9px
0 0 9px;background:#FFF}.editor_atto_content
img{resize:both;overflow:auto}.atto_hasmenu{white-space:nowrap}.atto_menuentry
img{width:16px;height:16px}.atto_menuentry{clear:left}.atto_menuentry h1,
.atto_menuentry h2,
.atto_menuentry
p{margin:4px}.atto_form
label.sameline{display:inline-block;min-width:10em}.atto_form textarea.fullwidth,
.atto_form
input.fullwidth{width:100%}.atto_form{padding-left:30px;padding-right:30px}.atto_form
label{display:block;margin:0
0 5px 0}body.dir-rtl div.editor_atto_toolbar button+button{border-left:0;border-right:1px solid #CCC}body.dir-rtl div.editor_atto_toolbar
img.icon{padding:0}body.dir-rtl div.editor_atto_toolbar
div.atto_group{margin:9px
9px 0 0}.atto_control{position:absolute;right:-6px;bottom:-6px;display:none;cursor:pointer}.atto_control
img{background-color:white}div.editor_atto_content:focus .atto_control,
div.editor_atto_content:hover
.atto_control{display:block}.editor_atto_menu.yui3-menu-hidden{display:none}.editor_atto_content img:-moz-broken{-moz-force-broken-image-icon:1;min-width:24px;min-height:24px}.moodle-dialogue-base .editor_atto_menu .moodle-dialogue-content .moodle-dialogue-bd{padding:0;z-index:1000}.editor_atto_menu .dropdown-menu>li>a{padding:3px
14px}.editor_atto_menu .open ul.dropdown-menu{padding-top:5px;padding-bottom:5px}.editor_atto_wrap{position:relative}.dir-rtl .editor_atto_wrap
textarea{direction:ltr}.editor_atto_notification{position:absolute;bottom:-1.5em;height:1.5em;margin-top:1px;cursor:pointer}.editor_atto_notification .atto_info,
.editor_atto_notification
.atto_warning{display:inline-block;background-color:#F2F2F2;padding:0.5em;padding-left:1em;padding-right:1em;border-bottom-left-radius:1em;border-bottom-right-radius:1em}.editor_atto_notification
.atto_info{background-color:#F2F2F2}.editor_atto_notification
.atto_warning{background-color:#FFD700}.editor_atto_toolbar,.editor_atto_content_wrap,.editor_atto+textarea{box-sizing:border-box}.dir-rtl .editor_atto_notification .atto_info,
.dir-rtl .editor_atto_notification
.atto_warning{border-bottom-right-radius:1em;border-bottom-left-radius:1em}.dir-ltr
.editor_atto_notification{right:0}.dir-rtl
.editor_atto_notification{left:0}@media (max-width: 480px){.mceToolbar
td{float:left;display:inline-block}.moodleSkin .mceLayout .mceToolbar
.mceWrap{clear:left;width:100%;height:4px}.moodleSkin .mceLayout .mceToolbar
.mceNoWrap{clear:none;width:0px}.o2k7Skin tr.mceLast .mceToolbar tr td.mceWrap,
.o2k7Skin tr.mceFirst .mceToolbar tr
td.mceWrap{margin-left:-3px}.dir-rtl .o2k7Skin tr.mceLast .mceToolbar tr td.mceWrap,
.dir-rtl .o2k7Skin tr.mceFirst .mceToolbar tr
td.mceWrap{margin-left:0px}}.course-content
.grid_title{font-size:160%;font-weight:bold}.course-content ul.gtopics
h3.sectionname{background:transparent;border:0
none;border-bottom:dashed 1px #000;font-weight:normal;padding:0;padding-bottom:5px}.course-content ul.gtopics-0 #section-0{background:transparent;border:0
none}.course-content ul.gtopics-0 #section-0
.side{width:28px}body.jsenabled
li.grid_section.hide_section{display:none !important}div#gridmiddle-column>ul{list-style-type:none;overflow:visible}.course-content
ul.gtopics{margin:0}.course-content ul.gtopics
li.section{list-style:none;margin:5px
0 0 0;padding:0}.course-content ul.gtopics li.section
.content{margin:0
40px}.course-content ul.gtopics li.section
.side{text-align:center;width:40px}.course-content ul.gtopics li.section
.left{float:left;padding:0}.course-content ul.gtopics li.section
.right{float:right}#gridiconcontainer{height:auto;margin:0
auto;padding:0;text-align:center;width:100%}#gridiconcontainer
ul.gridicons{margin:0
auto;padding:0;width:100%}#gridiconcontainer ul.gridicons
li{display:inline-block;height:auto;padding:10px;text-align:left}.dir-rtl #gridiconcontainer ul.gridicons
li{text-align:right}#gridiconcontainer ul.gridicons.content_inside
li{position:relative}.course-content ul.gridicons
img.new_activity{position:absolute}.course-content
.gridicon_link{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-hand-o-up-f'), auto}.course-content ul.gridicons li
.icon_content{font-weight:bold;height:20px;margin:0;overflow:hidden;text-align:center;text-overflow:ellipsis;white-space:nowrap}.course-content ul.gridicons li
.icon_content.content_inside{background-color:white;color:black;height:40px;opacity:0.8;overflow-wrap:break-word;padding:10px
10px 30px;position:absolute;text-overflow:inherit;white-space:pre-wrap;word-wrap:break-word}.course-content ul.gridicons li
.icon_content.content_inside.middle{bottom:0;left:0;margin:auto;right:0;top:0}.course-content ul.gridicons li
.icon_content.content_inside.bottom{bottom:0;left:0;margin:auto;right:0}.course-content ul.gridicons li .gridicon_link
.tooltip{font-size:14px}.course-content ul.gridicons li .gridicon_link .tooltip-inner{background-color:#ffc540;color:#3b53ad}.course-content ul.gridicons li .gridicon_link .tooltip.top .tooltip-arrow{border-top-color:#ffc540}.course-content ul.gridicons li .gridicon_link .tooltip.bottom .tooltip-arrow{border-bottom-color:#ffc540}.course-content ul.gridicons li .gridicon_link .tooltip.left .tooltip-arrow{border-left-color:#ffc540}.course-content ul.gridicons li .gridicon_link .tooltip.right .tooltip-arrow{border-right-color:#ffc540}.course-content ul.gridicons li
.image_holder{border-style:solid;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;overflow:hidden;text-align:center;vertical-align:middle}.course-content ul.gridicons li
img{margin-top:0}.course-content ul.gridicons li
img.info{height:100%;width:100%}.course-content
li.grid_section{clear:both}div#gridshadebox_overlay{background:black;cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-times-circle-o-f'),auto;filter:alpha(opacity=70);height:500px;left:0;opacity:0.7;position:fixed;top:0;width:100%;z-index:1}#gridshadebox_content{background:#fff;border:solid 2px #a71e38;min-height:200px}body.jsenabled
#gridshadebox_content.hide_content{display:none}#gridshadebox_content.absolute{left:5%;position:absolute;width:90%;z-index:1}#gridshadebox_content.fit_to_window{bottom:10%;left:10%;position:fixed;right:10%;top:10%;z-index:1}#gridshadebox_content.fit_to_window
ul.gtopics{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;height:100%;margin:0;overflow:auto;padding:10px}#gridshadebox_content.fit_to_window ul.gtopics
h3.sectionname{margin-top:0}#gridshadebox_content
.activity{border-bottom:1px dashed #ccc;list-style:none;padding-bottom:4px;padding-top:2px}#gridshadebox_content ul
li.grid_section{list-style:none}#gridshadebox_content ul li ul li, #gridshadebox_content ul li ol
li{border-bottom:none;padding-bottom:4px;padding-top:2px}#gridshadebox_content ul li ul
li{list-style:disc outside none}#gridshadebox_content ul li ol
li{list-style:decimal outside none}#gridshadebox_close{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-hand-o-up-f'),auto;position:absolute;right:-10px;top:-10px;z-index:2}.gridshadebox_arrow{cursor:inherit;height:55px;opacity:0.35;position:absolute;top:75px;transition:opacity .25s ease-in-out;-moz-transition:opacity .25s ease-in-out;-webkit-transition:opacity .25s ease-in-out;width:55px}.gridshadebox_area:hover
.gridshadebox_arrow{opacity:0.9}.gridshadebox_area{height:100%;position:absolute;top:0;width:55px}.gridshadebox_left_area{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-hand-o-left-f'),auto;left:-55px}.gridshadebox_right_area{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-hand-o-right-f'), auto;right:-55px}@media (max-width: 1199px){.gridshadebox_arrow{height:40px;width:40px}.gridshadebox_area{width:40px}.gridshadebox_left_area{left:-40px}.gridshadebox_right_area{right:-40px}}@media (max-width: 767px){div#gridshadebox_overlay{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-times-circle-o-fsm'),auto}#gridshadebox_close{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-hand-o-up-fsm'),auto;height:28px;width:28px}.gridshadebox_arrow{height:30px;width:30px}.gridshadebox_area{width:30px}.gridshadebox_left_area{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-hand-o-left-fsm'),auto;left:-30px}.gridshadebox_right_area{cursor:url('/sunguru/theme/image.php/archaius/format_grid/1531975376/fa-hand-o-right-fsm'), auto;right:-30px}}@media (max-width: 480px){#gridshadebox_close{height:20px;right:-7px;top:-7px;width:20px}.gridshadebox_arrow{height:20px;width:20px}.gridshadebox_area{width:20px}.gridshadebox_left_area{left:-20px}.gridshadebox_right_area{right:-20px}}.gridshadebox_arrow.gridshadebox_mobile{height:18px;width:18px}.gridshadebox_arrow.gridshadebox_mobile.gridshadebox_area{width:18px}.gridshadebox_arrow.gridshadebox_mobile.gridshadebox_left_area{left:-18px}.gridshadebox_arrow.gridshadebox_mobile.gridshadebox_right_area{right:-18px}.gridshadebox_arrow.gridshadebox_mobile,.gridshadebox_arrow.gridshadebox_mobile:hover{opacity:1}#gridshadebox_close.gridshadebox_mobile{height:18px;right:-7px;top:-7px;width:18px}.gridshadebox_arrow.gridshadebox_tablet{height:31px;width:31px}.gridshadebox_arrow.gridshadebox_tablet.gridshadebox_area{width:31px}.gridshadebox_arrow.gridshadebox_tablet.gridshadebox_left_area{left:-31px}.gridshadebox_arrow.gridshadebox_tablet.gridshadebox_right_area{right:-31px}.gridshadebox_arrow.gridshadebox_tablet,.gridshadebox_arrow.gridshadebox_tablet:hover{opacity:1}#gridshadebox_content
ul.gtopics{margin:0
15px 10px}.course-content ul.gridicons li
.image_holder.inaccessible{background-color:#999;border-color:#aaa;-webkit-filter:grayscale(100%);-moz-filter:grayscale(100%);-ms-filter:grayscale(100%);-o-filter:grayscale(100%);filter:grayscale(100%);filter:gray;filter:alpha(opacity=70);opacity:0.7}.format-singleactivity .tree_item.orphaned
a{color:red}.course-content
ul.topics{margin:0}.course-content ul.topics
li.section{list-style:none;margin:0
0 5px 0;padding:0}.course-content ul.topics li.section
.content{margin:0
40px}.course-content ul.topics li.section .left,
.course-content ul.topics li.section
.right{width:40px;padding:0
6px}.course-content ul.topics li.section .right
img.icon{padding:0
0 4px 0}.course-content ul.topics li.section
.left{padding-top:22px;text-align:right}.jsenabled .course-content ul.topics li.section .left,
.jsenabled .course-content ul.topics li.section
.right{width:auto}.course-content ul.topics li.section .left .section-handle
img.icon{padding:0;vertical-align:baseline}.course-content ul.topics li.section .section_action_menu .textmenu,
.course-content ul.topics li.section .section_action_menu .menu-action-text{white-space:nowrap}.course-content
ul.weeks{margin:0}.course-content ul.weeks
li.section{list-style:none;margin:0
0 5px 0;padding:0}.course-content ul.weeks li.section
.content{margin:0
40px}.course-content ul.weeks li.section .left,
.course-content ul.weeks li.section
.right{width:40px;padding:0
6px}.course-content ul.weeks li.section .right
img.icon{padding:0
0 4px 0}.course-content ul.weeks li.section
.left{padding-top:22px;text-align:right}.jsenabled .course-content ul.weeks li.section .left,
.jsenabled .course-content ul.weeks li.section
.right{width:auto}.course-content ul.weeks li.section .left .section-handle
img.icon{padding:0;vertical-align:baseline}.course-content ul.weeks li.section .section_action_menu .textmenu,
.course-content ul.weeks li.section .section_action_menu .menu-action-text{white-space:nowrap}#benchmark
h3{border:1px
solid #ddd;width:450px;margin:20px
auto 30px auto;padding:10px
0;border-radius:4px;background:#f5f5f5;box-shadow:inset 1px 1px 3px 0px #fff, inset -1px -1px 1px 0px #cfcfcf}#benchmark h3
span{color:#0a0}#benchmark .continuebutton
a.btn{margin:0
10px 10px 10px}#benchmarkresult
td{vertical-align:middle}#benchmarkresult
td.success{background-color:#dff0d8}#benchmarkresult
td.warning{background-color:#fcf8e3}#benchmarkresult
td.danger{background-color:#f2dede}#benchmarkresult .cell.c1
small{color:#888}#benchmarkresult .cell.c0,
#benchmarkresult
.footer{font-weight:bold}#benchmarkresult .c0,
#benchmarkresult .c2,
#benchmarkresult .c3,
#benchmarkresult
.c4{text-align:center}#benchmarkresult .footer
td{background-color:#fff}#benchmarkresult .footer
.cell.c0{text-align:right}#benchmarkresult .footer
.cell.c1{text-align:center}@media (max-width: 500px){#benchmark
h3{font-size:20px;width:348px}}.dir-rtl.path-report-competency [data-region="competency-breakdown-report"] .row-fluid [class*="span"]{float:right}.dir-rtl.path-report-competency .pull-left{float:right}.dir-rtl.path-report-competency .pull-right{float:left}.dir-rtl.path-report-competency
dd{margin-right:10px}.dir-rtl.path-report-competency
ul.inline{margin-right:0}.dir-rtl.path-report-competency .table th,
.dir-rtl.path-report-competency .table
td{text-align:right}#page-report-completion-index table#completion-progress{margin-top:20px;margin-bottom:30px}#page-report-completion-index .export-actions{text-align:center;list-style:none}#page-report-completion-index.dir-rtl #completion-progress th
svg{direction:ltr}.report-eventlist-name{color:#888;font-size:0.75em}.report-eventlist-datatable-table>div>table{width:100%}#page-admin-report-eventlist-index
dt{float:left;text-align:right;width:20em}#page-admin-report-eventlist-index
dd{display:block;text-align:left;margin-left:21em}#page-admin-report-eventlist-index dd+dd{clear:left}@media (max-width : 767px){#page-admin-report-eventlist-index
dt{width:100%;text-align:left}#page-admin-report-eventlist-index
dd{margin-left:0}#page-admin-report-eventlist-index dd+dd{margin-left:0}}#page-admin-report-eventlist-index.dir-rtl
dt{float:right;text-align:left;width:20em}#page-admin-report-eventlist-index.dir-rtl
dd{display:block;text-align:right;margin-right:22em}#page-admin-report-eventlist-index.dir-rtl dd+dd{clear:right}@media (max-width : 767px){#page-admin-report-eventlist-index.dir-rtl
dt{width:100%;text-align:right}#page-admin-report-eventlist-index.dir-rtl
dd{margin-right:0em}#page-admin-report-eventlist-index.dir-rtl dd+dd{margin-right:0em}}#forumgraphsvg{background:#fff}#forumgraphsvg
circle{stroke:#fff;stroke-width:1.5px}#forumgraphsvg
.link{stroke:#999;stroke-opacity: .6}#forumgraphsvg
path.link{fill:none;stroke:#666;stroke-width:1.5px}#forumgraphsvg
text{fill:#000;font:12px sans-serif;pointer-events:none}#forumgraphoption{border:0px}div.forumgraphtooltip{position:absolute;text-align:center;width:120px;height:50px;padding:2px;font:12px sans-serif;background:lightsteelblue;border:0px;border-radius:8px;pointer-events:none}marker#end{fill:#999}ol#topposters{margin-top:0px;margin-bottom:5px}#page-report-log-index
.info{margin:10px}#page-report-log-index
.logselectform{margin:10px
auto}#page-report-log-user
.info{margin:10px;text-align:center}#page-report-log-user
.graph{text-align:center}#page-report-loglive-index
.info{margin:10px}table.flexible>tbody>tr:nth-child(n).newrow>td{background:#D4D4D4}.competencyreport
h3{font-size:18px;font-weight:400}.competencyreport .form-group{margin-bottom:10px}.competencyreport .mform
.fitem.fitem_fradiogroup{margin-bottom:0}body #region-main .competencyreport .mform:not(.unresponsive) .femptylabel
.felement.radio{padding-top:0;margin-top:0}.competencyreport .scaleitem>label{font-weight:bold}.competencyreport .mform .fitem .fgroup button:first-child{margin-left:0}.competencyreport .form-control:focus{border-color:#ccd0d7;box-shadow:none !important}.competencyreport
.x_panel{position:relative;width:100%;box-sizing:border-box;padding:5px
0;display:inline-block;opacity:1;transition:all 250ms ease-in-out}.competencyreport
.x_title{border-bottom:1px solid transparent;padding:2px
5px;transition:all 250ms ease-in-out}.competencyreport .panel-collapsed
.x_title{border-bottom-color:#cfd1d5}.competencyreport .x_title h4 a:hover{text-decoration:none}.competencyreport .x_title
.filter{width:40%;float:right}.competencyreport .x_title
h4{margin:5px
0 6px;display:inline-block;font-size:18px;line-height:1.2em;font-weight:400;transition:all 250ms ease-in-out 0s}.competencyreport .panel-collapsed .x_title
h4{max-width:calc(100% - 150px)}.competencyreport .x_title
span{color:#333}.competencyreport .x_title h4
small{font-size:14px}.competencyreport
.x_content{padding:0
5px 6px;position:relative;width:100%;box-sizing:border-box;float:left;clear:both}.competencyreport
.toggle{float:left;margin:0;padding-top:16px;width:70px}.competencyreport .toggle
a{padding:15px
15px 0;margin:0;cursor:pointer}.competencyreport .toggle a
i{font-size:26px}.competencyreport .nav.child_menu>li>a{color:rgba(255, 255, 255, 0.75);font-size:12px;padding:9px}.competencyreport a.collapse-link{display:inline-block;padding:5px;color:#999;font-size:14px;cursor:pointer;text-align:center;vertical-align:top;width:16px}.competencyreport a.collapse-link:hover{background:#f5f7fa}.competencyreport .clearfix::after,
.competencyreport form::after{clear:both;content:".";display:block;height:0;visibility:hidden}.competencyreport
ul.to_do{padding:0}.competencyreport ul.to_do
li{border-radius:3px;position:relative;padding:0;margin-bottom:2px;list-style:none}.competencyreport ul.to_do
p{margin:0}.competencyreport
#userInfoContainer{text-align:left}.competencyreport
.widget_profile_box{background:#1375c7;border-radius:4px;box-sizing:border-box;margin-top:14px;position:relative;width:100%;display:flex;flex-direction:row;flex-wrap:nowrap;justify-content:space-around;align-content:center;align-items:flex-start}.competencyreport .widget_profile_box
*{color:#fff}.competencyreport .widget_profile_box div,
.competencyreport .widget_profile_box
h3{display:inline-block;line-height:61px;height:61px;vertical-align:middle;white-space:nowrap}.competencyreport .widget_profile_box
h3{margin:0
0 0 5px}.competencyreport .widget_profile_box h3
img{display:inline-block;overflow:hidden;text-indent:-10000px;margin-bottom:2px;-webkit-filter:brightness(1.7);filter:url(/sunguru/theme/image.php/archaius/report_lpmonitoring/1531975376/white#white)}.competencyreport .widget_profile_box .plan-name{margin-right:5px;width:40%;overflow:hidden}.competencyreport .widget_profile_box #plan-user-info{font-size:14px;position:relative;top:-10px;flex:2 0 auto}.competencyreport .widget_profile_box #plan-user-info
#spinerprofile{display:none;left:16px;position:absolute;line-height:81px;z-index:1}.competencyreport .widget_profile_box #plan-user-info.loading
#spinerprofile{display:block}.competencyreport .widget_profile_box .img-wrapper{height:81px;width:81px}.competencyreport .widget_profile_box #plan-user-info.loading .img-wrapper:before{background:rgba(0, 0, 0, 0.8);border-radius:50%;content:"";display:block;height:81px;left:0;position:absolute;width:81px}.competencyreport .widget_profile_box #plan-user-info .img-wrapper .img-circle.profile_img{display:block;background:#fff;border:1px
solid rgba(32, 85, 130, 0.6);box-sizing:border-box;margin:0;padding:5px;width:81px;height:81px}.competencyreport .widget_profile_box
a.navigatetoplan{border-left:1px solid rgba(255, 255, 255, 0.15);box-sizing:border-box;font-size:10px;line-height:61px;position:relative;text-align:center;width:102px}.competencyreport .widget_profile_box
a.nexplan{padding-right:10px}.competencyreport .widget_profile_box a.nexplan
i{right:5px}.competencyreport .widget_profile_box
a.prevplan{padding-left:10px}.competencyreport .widget_profile_box a.prevplan
i{left:5px}.competencyreport .widget_profile_box a.navigatetoplan
img{border-radius:50%;height:25px;width:25px;display:block;margin:0
auto}.competencyreport .widget_profile_box a.navigatetoplan
i{line-height:0;position:absolute;top:50%}.competencyreport .widget_profile_box a.navigatetoplan .user-profile-small{display:inline-block;line-height:61px;vertical-align:middle;white-space:normal}.competencyreport .widget_profile_box a.navigatetoplan .user-profile-small
p{line-height:11px;margin:0;width:90px}@media (max-width: 998px){.competencyreport
.widget_profile_box{flex-flow:row wrap;height:auto;text-align:center;padding:0
40px}.competencyreport .widget_profile_box div,
.competencyreport .widget_profile_box
h3{display:block;height:auto;line-height:1.2em;margin:0
auto}.competencyreport .widget_profile_box
h3{width:100%;white-space:normal}.competencyreport .widget_profile_box .plan-name{width:100%;margin:10px
0}.competencyreport .widget_profile_box #plan-user-info{height:auto;width:100%}.competencyreport .widget_profile_box
a.navigatetoplan{position:absolute;width:40px;top:0;bottom:0;height:auto}.competencyreport .widget_profile_box
a.nexplan{right:0}.competencyreport .widget_profile_box
a.prevplan{left:0;border-left:none;border-right:1px solid rgba(255, 255, 255, 0.15)}.competencyreport .widget_profile_box a.navigatetoplan .user-profile-small{display:none}.competencyreport .widget_profile_box #plan-user-info{top:0;margin-bottom:10px}.competencyreport .widget_profile_box a.navigatetoplan i,
.competencyreport .widget_profile_box #plan-user-info
#spinerprofile{left:0;right:0}.competencyreport .widget_profile_box #plan-user-info.loading .img-wrapper::before{left:auto;margin:0
auto}}.competencyreport
.green{color:#4cae4c !important}.competencyreport
.blue{color:#3590db}.competencyreport
.fail{color:#ac2925 !important}.competencyreport
.breadcrumb{background:transparent;padding:0;margin:0}.competencyreport .truncate,.label.cr-scalename.truncate{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;max-width:100%;box-sizing:border-box}.competencyreport .x_panel table td
p{font-size:12px}.competencyreport
.preuve{font-weight:600;line-height:25px;font-size:22px}.competencyreport .modal-dialog td
span.label{font-size:12px}.competencyreport
.widget_stats{min-height:60px;padding:1px
5px}@media (min-width: 768px){.competencyreport .tile_count .tile_stats_count
.count{font-size:28px}}.competencyreport
.tile_count{display:-webkit-flex;display:flex;-webkit-flex-flow:row wrap;flex-flow:row wrap;margin-bottom:0;margin-top:4px}.competencyreport .tile_count
.tile_stats_count{padding:0
10px 0 20px;position:relative;-webkit-flex:1 1 auto;flex:1 1 auto}.competencyreport .tile_count .tile_stats_count
table{width:100%}.competencyreport .tile_count
#rating{-webkit-flex-grow:2;flex-grow:2}.competencyreport .tile_count
#finalrating{min-width:250px}@media (min-width: 992px){.competencyreport .tile_count
.tile_stats_count{margin-bottom:0;border-bottom:0;padding-bottom:2px}.competencyreport .tile_count .tile_stats_count:first-child{border-left:0}.competencyreport .tile_count .tile_stats_count
.count{font-size:28px}}.competencyreport .tile_count .tile_stats_count
.count{font-size:28px;line-height:47px;font-weight:600}@media (min-width: 992px) and (max-width: 1100px){.competencyreport .tile_count .tile_stats_count
.count{font-size:28px}}.competencyreport .tile_count .tile_stats_count
h5{font-size:14px;font-weight:bold;color:#555;padding-bottom:5px;border-bottom:1px solid #cfd1d5}@media (min-width: 768px){.competencyreport .tile_count .tile_stats_count
h5{font-size:15px}}.competencyreport
.btn{border-radius:3px;box-shadow:none;text-shadow:none}.competencyreport .btn-primary{background:#1375c7}.competencyreport .btn-primary:hover,
.competencyreport .btn-primary:focus,
.competencyreport .btn-primary:active,
.competencyreport .btn-primary.active,
.competencyreport .btn-primary.disabled,
.competencyreport .btn-primary[disabled]{background:#1453c7}.competencyreport .tile-stats{min-height:90px;position:relative;display:block;overflow:hidden;padding-bottom:5px}.competencyreport .tile-stats
.icon{width:20px;height:20px;position:absolute;right:53px;top:22px;z-index:1}.competencyreport .tile-stats .icon
i{margin:0;font-size:60px;line-height:0;vertical-align:bottom;padding:0}.competencyreport .tile-stats
.count{font-size:38px;font-weight:bold;line-height:1.65857}.competencyreport .tile-stats .count,
.competencyreport .tile-stats h4,
.competencyreport .tile-stats
p{position:relative;margin:0;margin-left:10px;z-index:0;padding:0}.competencyreport .tile-stats
h4{color:#bab8b8}.competencyreport .tile-stats
p{margin-top:5px;font-size:12px}.competencyreport .tile-stats>.dash-box-footer{position:relative;text-align:center;margin-top:5px;padding:3px
0;color:#fff;color:rgba(255, 255, 255, 0.8);display:block;z-index:10;background:rgba(0, 0, 0, 0.1);text-decoration:none}.competencyreport .tile-stats>.dash-box-footer:hover{color:#fff;background:rgba(0, 0, 0, 0.15)}.competencyreport .tile-stats>.dash-box-footer:hover{color:#fff;background:rgba(0, 0, 0, 0.15)}.competencyreport .navbar-right{margin-right:0}.competencyreport
.ln_solid{border-top:1px solid #e5e5e5;color:#fff;background-color:#fff;height:1px;margin:0
0 20px}.competencyreport
table.tile_info{padding:10px
15px}.competencyreport table.tile_info
td{text-align:left;padding:0;font-size:15px}.competencyreport table.tile_info tr:not(:first-child):hover{background:#f5f5f5}.competencyreport table.tile_info td:first-child{width:83%}.competencyreport table.tile_info td
p{margin:0;line-height:17px}.competencyreport table.tile_info td
i{margin:0
8px;font-size:17px;float:left;line-height:17px}.competencyreport table.tile_info td
a{cursor:pointer;font-weight:bold;overflow:auto}.competencyreport table.tile_info td a,
.competencyreport table.tile_info td span.nbcourses,
.competencyreport table.tile_info td
span.nbusers{display:inline-block;text-align:center;width:100%}.competencyreport table.tile_info td
span{line-height:28px}.competencyreport table.tile_info
span.right{margin-right:0;float:right;position:absolute;right:4%}.competencyreport .h1,
.competencyreport .h2,
.competencyreport .h3,
.competencyreport .h4,
.competencyreport .h5,
.competencyreport .h6,
.competencyreport h1,
.competencyreport h2,
.competencyreport h3,
.competencyreport h4,
.competencyreport h5,
.competencyreport
h6{color:inherit;font-family:inherit;font-weight:500;line-height:1.1}.competencyreport
.nav{margin-bottom:5px}.competencyreport .rate-competency{position:relative;top:10px;left:5px}.competencyreport .tile_stats_count .tile-stats .level-proficiency{font-size:13px;margin-right:5px;width:80px;text-align:center;line-height:1.5em;margin-top:17px}.competencyreport .tile_stats_count .tile-stats .icon-proficiency{clear:both;margin-top:30px;height:0;width:0}.competencyreport .tile_stats_count .tile-stats .icon-proficiency
i{font-size:35px}.competencyreport .fautocomplete .form-autocomplete-downarrow{color:#333;cursor:pointer;position:relative;top:0}.competencyreport .fautocomplete span[data-value=""]{padding:0}.competencyreport .fautocomplete input[type="text"]{margin-bottom:2px}.competencyreport .fautocomplete .label-info
span{padding:2px
4px}.competencyreport .input-group{margin-left:5px;border-collapse:separate;display:table;position:relative}.competencyreport  .input-group-addon,.input-group-btn{vertical-align:middle;white-space:nowrap;width:1%}.competencyreport .input-group-addon{background-color:#eee;border:1px
solid #ccc;border-radius:4px;color:#555;font-size:14px;font-weight:400;line-height:1;padding:8px
18px;text-align:center}.competencyreport .input-group-addon.input-sm{border-radius:3px;font-size:12px;padding:5px
10px}.competencyreport .input-group-addon.input-lg{border-radius:6px;font-size:18px;padding:10px
16px}.competencyreport .input-group-addon input[type="checkbox"],
.input-group-addon input[type="radio"]{margin-top:0}.competencyreport .input-group .form-control:first-child,
.competencyreport .input-group-addon:first-child,
.competencyreport .input-group-btn:first-child > .btn,
.competencyreport .input-group-btn:first-child > .btn-group > .btn,
.competencyreport .input-group-btn:first-child > .dropdown-toggle,
.competencyreport .input-group-btn:last-child > .btn-group:not(:last-child) > .btn,
.competencyreport .input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle){border-bottom-right-radius:0;border-top-right-radius:0}.competencyreport .input-group-addon:first-child{border-right:0 none}.competencyreport .input-group .form-control:last-child,
.competencyreport .input-group-addon:last-child,.input-group-btn:first-child>.btn-group:not(:first-child)>.btn,.input-group-btn:first-child>.btn:not(:first-child),.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group>.btn,.input-group-btn:last-child>.dropdown-toggle{border-bottom-left-radius:0;border-top-left-radius:0}.competencyreport .input-group-addon:last-child{border-left:0 none}.competencyreport .input-group-btn{font-size:0;position:relative;white-space:nowrap}.competencyreport .input-group-btn>.btn{position:relative}.competencyreport .input-group-btn>.btn+.btn{margin-left:-1px}.competencyreport .input-group-btn > .btn:active,
.input-group-btn > .btn:focus,
.competencyreport .input-group-btn>.btn:hover{z-index:2}.competencyreport .input-group-btn:first-child > .btn,
.competencyreport .input-group-btn:first-child>.btn-group{margin-right:-1px}.competencyreport .input-group-btn:last-child > .btn,
.competencyreport .input-group-btn:last-child>.btn-group{margin-left:-1px;z-index:2}.competencyreport
#loaderscalevalues{width:197px;text-align:center}.competencyreport #scalevalues .form-group{clear:both;display:table;margin-bottom:10px}.competencyreport #scalevalues span.input-group-addon,
.competencyreport #scalevalues input[type="text"]{float:left}.competencyreport #scalevalues span.input-group-addon{padding:8px;width:16px;height:16px}.competencyreport #scalevalues input[type="text"]{height:24px;width:150px;border-top-right-radius:0;border-bottom-right-radius:0}.competencyreport #scalevalues .fitemtitle.proficient label
small{display:block;color:#666}.competencyreport .disabled-option{display:none}.competencyreport .disabled-option .fautocomplete input,
.competencyreport .disabled-option .fautocomplete
select{background:#eee;cursor:not-allowed;pointer-events:none}.competencyreport .disabled-option .fautocomplete .form-autocomplete-downarrow{display:none}.competencyreport
#learningplanSelectorReport{margin-top:29px}.competencyreport
#studentselectorreport{margin-top:25px}.competencyreport
label.templabel{text-align:left;padding-left:0}.competencyreport button .fa-spin{margin-left:7px;position:static;display:none}.competencyreport button.loading .fa-spin{display:inline-table}.competencyreport span.user-nav-separator{display:block;border-left:2px solid #fff;height:50px}.competencyreport
.level{display:block;font-size:15px;font-weight:bold;line-height:30px;min-width:20px;opacity:0;position:absolute;right:5px;top:7px;transition:all 250ms ease-in-out 0s;visibility:hidden}.competencyreport .fa-certificate,
.competencyreport .fa-question-circle{color:#999}.competencyreport .panel-collapsed
.x_content{display:none}.competencyreport .panel-collapsed
.level{opacity:1;visibility:visible}.competencyreport .form-autocomplete-suggestions{z-index:40}#listPlanCompetencies{clear:both}#listPlanCompetencies p.alert-info{font-size:15px;margin-top:20px}.competencyreport canvas.detail-competency{margin:1px
1px 1px 0;width:80px;height:80px}.competencyreport .breadcrumb>li+li::before{color:#666;content:"/ ";padding:0
5px}.competencyreport .no-data-available{border-radius:50%;text-align:center;background:rgb(255, 255, 255);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;line-height:1.2;border:2px
solid rgb(204, 204, 204);padding:0.1em;height:74px;width:74px;white-space:normal}.competencyreport .no-data-available
span{font-size:0.8em}.cr-caption{max-width:100%}.label.cr-scalename{color:#000;font-size:13px;text-shadow:none;vertical-align:middle}#finalrating .label.cr-scalename.truncate{max-width:calc(100% - 100px)}.label.cr-scalename.light-color{color:#fff}@media (min-width: 1200px){.competencyreport
.scalecontainer{margin-top:5px}.competencyreport #scalevalues
.fitemtitle.proficient{padding-top:0;margin-top:-2px}.competencyreport
#loaderscalevalues{width:462px}}.competencyreport .templatelist
input{width:35%}.competencyreport
.compstats{display:flex;flex-flow:row wrap}.competencyreport .compstats .competency-detail{flex:0 1 315px;margin-right:20px}.competencyreport div.stats
.x_title{border-bottom-color:#cfd1d5}.competencyreport
td.convaschart{padding-top:30px;vertical-align:top}.competencyreport
.loaderstatscompetency{text-align:center;width:100%;min-height:190px}.competencyreport
.loaderstatscompetency{display:none}.competencyreport .loaderstatscompetency i.fa-refresh{line-height:190px;vertical-align:middle}.competencyreport .loading
.loaderstatscompetency{display:block}.competencyreport .plan-info-report{display:-webkit-flex;display:flex;-webkit-flex-flow:row wrap;display:flex;flex-flow:row wrap;padding:5px}.competencyreport .plan-info-report:empty{border-bottom:none}.competencyreport .report-stats-competencies{background:#fff none repeat scroll 0 0;border:1px
solid #cfd1d5;border-radius:8px;display:flex;flex-direction:column;margin:0.5em auto;padding:1em
1.5em;text-align:center}.competencyreport .report-stats-competencies .plan-status{padding-bottom:0.5em;flex:1 0 auto}.competencyreport .plan-info-report .report-stats-competencies .stats-cmp-proficient{font-size:12px}.competencyreport .plan-info-report .report-stats-competencies .count-stats{font-size:2.9em;font-weight:600;line-height:47px}.competencyreport .plan-info-report>div.report-stats-competencies{min-width:145px}.competencyreport .plan-info-report .report-stats-competencies .empty-value{color:#cfd1d5}.competencyreport .plan-info-report .collapsible-actions{text-align:right;position:relative;color:#555;align-self:end;min-width:120px}.competencyreport .compstats .competency-detail
.totalnbusers{font-size:0.8em}.competencyreport .compstats .competency-detail
.count{line-height:15px;padding-left:5px}.competencyreport .compstats .competency-detail
h5{border:medium none;font-size:11px;margin:10px
0;max-width:130px;padding:0;padding:0
0 0 5px}.competencyreport .compstats .competency-detail
td.convaschart{width:30%}.competencyreport .compstats .competency-detail
td.scalevalues{vertical-align:top}.competencyreport .compstats .competency-detail .tile_count
#rating{flex-grow:unset;width:100%}.competencyreport .compstats .tile_count
.tile_stats_count{padding:0}.competencyreport
.borderbottom{border-bottom:1px solid #cfd1d5}.lpmonitoringdialogue .stats-rated-column{min-width:20%}.lpmonitoringdialogue div.dataTables_paginate a.paginate_button.first,
.lpmonitoringdialogue div.dataTables_paginate
a.paginate_button.previous{position:relative;padding-left:24px}.lpmonitoringdialogue div.dataTables_paginate a.paginate_button.next,
.lpmonitoringdialogue div.dataTables_paginate
a.paginate_button.last{position:relative;padding-right:24px}.lpmonitoringdialogue div.dataTables_paginate a.first:before,
.lpmonitoringdialogue div.dataTables_paginate a.previous:before{display:block;font-family:FontAwesome;font-size:1.5em;left:10px;position:absolute;top:2px}.lpmonitoringdialogue div.dataTables_paginate a.next:after,
.lpmonitoringdialogue div.dataTables_paginate a.last:after{display:block;font-family:FontAwesome;font-size:1.5em;position:absolute;right:10px;top:2px}.lpmonitoringdialogue div.dataTables_paginate a.first:before{content:"\f100"}.lpmonitoringdialogue div.dataTables_paginate a.previous:before{content:"\f104"}.lpmonitoringdialogue div.dataTables_paginate a.next:after{content:"\f105"}.lpmonitoringdialogue div.dataTables_paginate a.last:after{content:"\f101"}.lpmonitoringdialogue
.dataTables_wrapper{position:relative;clear:both;*zoom:1;zoom:1}.lpmonitoringdialogue .dataTables_wrapper
.dataTables_length{float:left}.lpmonitoringdialogue .dataTables_wrapper
.dataTables_filter{float:right;text-align:right}.lpmonitoringdialogue .dataTables_wrapper .dataTables_filter
input{margin-left:0.5em}.lpmonitoringdialogue table.dataTable thead
th{position:relative;background-image:none !important}.lpmonitoringdialogue table.dataTable thead th.sorting:after,
.lpmonitoringdialogue table.dataTable thead th.sorting_asc:after,
.lpmonitoringdialogue table.dataTable thead th.sorting_desc:after{position:absolute;top:10px;right:8px;display:block;font-family:FontAwesome}.lpmonitoringdialogue table.dataTable thead th.sorting:after{content:"\f0dc";color:#ddd;font-size:0.8em;padding-top:0.12em}.lpmonitoringdialogue table.dataTable thead th.sorting_asc:after{content:"\f0de"}.lpmonitoringdialogue table.dataTable thead th.sorting_desc:after{content:"\f0dd"}.lpmonitoringdialogue div.dataTables_scrollBody table.dataTable thead th.sorting:after,
.lpmonitoringdialogue div.dataTables_scrollBody table.dataTable thead th.sorting_asc:after,
.lpmonitoringdialogue div.dataTables_scrollBody table.dataTable thead th.sorting_desc:after{content:""}.lpmonitoringdialogue table.dataTable thead .sorting_asc,
.lpmonitoringdialogue table.dataTable thead .sorting_desc,
.lpmonitoringdialogue table.dataTable thead
.sorting{cursor:pointer}.lpmonitoringdialogue .dataTables_wrapper .dataTables_paginate .paginate_button.disabled,
.lpmonitoringdialogue .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover,
.lpmonitoringdialogue .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active{background:transparent none repeat scroll 0 0;border:1px
solid transparent;box-shadow:none;color:#666 !important;cursor:default}.lpmonitoringdialogue .dataTables_wrapper .dataTables_paginate
.paginate_button{box-sizing:border-box;color:#333 !important;cursor:pointer;display:inline-block;line-height:1.5em;margin-left:2px;min-width:1.5em;padding:0.2em 0.6em;text-align:center;text-decoration:none !important;border-radius:3px}.lpmonitoringdialogue .dataTables_wrapper .dataTables_paginate .paginate_button.current,
.lpmonitoringdialogue .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover{background:rgba(0, 0, 0, 0) linear-gradient(to bottom, white 0%, gainsboro 100%) repeat scroll 0 0;border:1px
solid #cacaca;color:#333 !important}.lpmonitoringdialogue
.dataTables_paginate{text-align:center}.lpmonitoringdialogue .dataTables_wrapper .dataTables_paginate .paginate_button:hover{color:white !important;background-color:#0d70c4}.competencyreport .form-autocomplete-suggestions
.nbratinguser{float:right;margin-left:40px}.path-report-mygrades
table.dataTable{margin:0
auto;clear:both;width:100%}.path-report-mygrades table.dataTable thead
th{padding:3px
18px 3px 10px;border-bottom:1px solid black;font-weight:bold;cursor:pointer;*cursor:hand}.path-report-mygrades table.dataTable tfoot
th{padding:3px
18px 3px 10px;border-top:1px solid black;font-weight:bold}.path-report-mygrades table.dataTable
td{padding:3px
10px}.path-report-mygrades table.dataTable td.center,
.path-report-mygrades table.dataTable
td.dataTables_empty{text-align:center}.path-report-mygrades table.dataTable
tr.odd{background-color:#E2E4FF}.path-report-mygrades table.dataTable
tr.even{background-color:white}.path-report-mygrades table.dataTable tr.odd
td.sorting_1{background-color:#D3D6FF}.path-report-mygrades table.dataTable tr.odd
td.sorting_2{background-color:#DADCFF}.path-report-mygrades table.dataTable tr.odd
td.sorting_3{background-color:#E0E2FF}.path-report-mygrades table.dataTable tr.even
td.sorting_1{background-color:#EAEBFF}.path-report-mygrades table.dataTable tr.even
td.sorting_2{background-color:#F2F3FF}.path-report-mygrades table.dataTable tr.even
td.sorting_3{background-color:#F9F9FF}.path-report-mygrades
.dataTables_wrapper{position:relative;clear:both;*zoom:1}.path-report-mygrades
.dataTables_length{float:left}.path-report-mygrades
.dataTables_filter{float:right;text-align:right}.path-report-mygrades
.dataTables_info{clear:both;float:left}.path-report-mygrades
.dataTables_paginate{float:right;text-align:right}.path-report-mygrades .paginate_disabled_previous,
.path-report-mygrades .paginate_enabled_previous,
.path-report-mygrades .paginate_disabled_next,
.path-report-mygrades
.paginate_enabled_next{height:19px;float:left;cursor:pointer;*cursor:hand;color:#111 !important}.path-report-mygrades .paginate_disabled_previous:hover,
.path-report-mygrades .paginate_enabled_previous:hover,
.path-report-mygrades .paginate_disabled_next:hover,
.path-report-mygrades .paginate_enabled_next:hover{text-decoration:none !important}.path-report-mygrades .paginate_disabled_previous:active,
.path-report-mygrades .paginate_enabled_previous:active,
.path-report-mygrades .paginate_disabled_next:active,
.path-report-mygrades .paginate_enabled_next:active{outline:none}.path-report-mygrades .paginate_disabled_previous,
.path-report-mygrades
.paginate_disabled_next{color:#666 !important}.path-report-mygrades .paginate_disabled_previous,
.path-report-mygrades
.paginate_enabled_previous{padding-left:23px}.path-report-mygrades .paginate_disabled_next,
.path-report-mygrades
.paginate_enabled_next{padding-right:23px;margin-left:10px}.path-report-mygrades
.paging_full_numbers{height:22px;line-height:22px}.path-report-mygrades .paging_full_numbers a:active{outline:none}.path-report-mygrades .paging_full_numbers a:hover{text-decoration:none}.path-report-mygrades .paging_full_numbers a.paginate_button,
.path-report-mygrades .paging_full_numbers
a.paginate_active{border:1px
solid #aaa;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;padding:2px
5px;margin:0
3px;cursor:pointer;*cursor:hand;color:#333 !important}.path-report-mygrades .paging_full_numbers
a.paginate_button{background-color:#ddd}.path-report-mygrades .paging_full_numbers a.paginate_button:hover{background-color:#ccc;text-decoration:none !important}.path-report-mygrades .paging_full_numbers
a.paginate_active{background-color:#99B3FF}.path-report-mygrades
.dataTables_processing{position:absolute;top:50%;left:50%;width:250px;height:30px;margin-left:-125px;margin-top:-15px;padding:14px
0 2px 0;border:1px
solid #ddd;text-align:center;color:#999;font-size:14px;background-color:white}.path-report-mygrades
.sorting{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/sort) !important;background-position:center right !important;background-repeat:no-repeat !important}.path-report-mygrades
.sorting_asc{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/sort_asc) !important;background-position:center right !important;background-repeat:no-repeat !important}.path-report-mygrades
.sorting_desc{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/sort_desc) !important;background-position:center right !important;background-repeat:no-repeat !important}.path-report-mygrades table.dataTable thead th:active,
.path-report-mygrades table.dataTable thead td:active{outline:none}.path-report-mygrades
.dataTables_scroll{clear:both}.path-report-mygrades
.dataTables_scrollBody{*margin-top:-1px;-webkit-overflow-scrolling:touch}.path-report-mygrades
table.grades{color:#666;font-size:12px;background:#eaebec;width:100%;border:#ccc 1px solid}.path-report-mygrades table.grades
th{padding:8px
10px 8px 10px;border-top:1px solid #fafafa;border-bottom:1px solid #e0e0e0;background:#ededed}.path-report-mygrades table.grades th:first-child{text-align:center;padding-left:10px;width:80%;border-right:1px solid #e0e0e0}.path-report-mygrades table.grades
tr{text-align:center;padding-left:10px}.path-report-mygrades table.grades td:first-child{text-align:center;padding-left:5px;border-left:0}.path-report-mygrades table.grades td, .path-report-mygrades table.dataTable
tr.odd{padding:5px;border-top:1px solid #fff;border-bottom:1px solid #e0e0e0;border-left:1px solid #e0e0e0;min-width:80px;background:#fafafa !important}.path-report-mygrades table.grades tr.even td, .path-report-mygrades table.dataTable
tr.even{background:#f6f6f6 !important}.path-report-mygrades table.grades tr:last-child
td{border-bottom:0}.path-report-mygrades table.grades tr:hover
td{background:#f2f2f2 !important}#page-report-outline-index
td.numviews{text-align:right}#page-report-outline-index
tr.section{text-align:center}#page-report-outline-index
td.lastaccess{font-size:0.8em}#page-report-outline-user .section
.content{margin-left:30px;margin-right:30px}#page-report-outline-user .section
h2{margin-top:0}#page-report-outline-user
.section{margin-left:30px;margin-right:30px;margin-bottom:20px}#page-report-outline-user
.section{border-width:1px;border-style:solid;padding:10px}#page-admin-report-overviewstats-index .chartinfo,#page-report-overviewstats-index
.chartinfo{margin-bottom:1em}#page-admin-report-overviewstats-index .chartplaceholder,#page-report-overviewstats-index
.chartplaceholder{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/loading);background-repeat:no-repeat;background-position:center center;min-height:66px}#page-report-participation-index
.participationselectform{margin:10px
auto}#page-report-participation-index .participationselectform
label{margin-left:15px;margin-right:5px}#page-report-progress-index #completion-progress th,
#page-report-progress-index #completion-progress
td{padding:2px
4px;font-weight:normal;border-right:1px solid #EEE}#page-report-progress-index .progress-actions{text-align:center;list-style:none}#page-report-progress-index
.completion_pagingbar{margin:1em
0;text-align:center}#page-report-progress-index
.completion_prev{display:inline;margin-right:2em}#page-report-progress-index .completion_pagingbar
p{display:inline;margin:0}#page-report-progress-index
.completion_next{display:inline;margin-left:2em}#page-report-progress-index.dir-rtl #completion-progress th
svg{direction:ltr}#page-report-stats-index
.graph{margin-bottom:1em}.gradeimport_data_area{margin:0px
0px 10px;width:475px;height:209px}.path-grade-report-grader
.gradeparent{position:relative}.path-grade-report-grader .gradeparent .grader-information-tooltip{min-width:200px}.path-grade-report-grader .gradeparent
.graderreportoverlay{background-color:white;width:auto;padding:10px;font-size:12px;border:1px
solid #ccc;border-radius:4px}.path-grade-report-grader .gradeparent
table{border:1px
solid #ccc;border-collapse:separate;border-spacing:0;border-bottom-width:0;border-right-width:0;margin-bottom:2em}.dir-rtl.path-grade-report-grader .gradeparent
table{border-left-width:0;border-right-width:1px;max-width:initial}.path-grade-report-grader .gradeparent
.cell{border:1px
solid #ccc;border-top-width:0;border-left-width:0;padding:4px
5px;vertical-align:middle;text-align:right;white-space:nowrap}.dir-rtl.path-grade-report-grader .gradeparent
.cell{border-left-width:1px;border-right-width:0;text-align:left}.path-grade-report-grader .gradeparent tr:nth-of-type(even) .cell{background-color:#f9f9f9}.path-grade-report-grader .gradeparent
.floater{display:none}.path-grade-report-grader .gradeparent
.floating{display:block}.path-grade-report-grader .gradeparent .heading .cell,
.path-grade-report-grader .gradeparent .avg .cell,
.path-grade-report-grader .gradeparent
.user.cell{font-size:14px;font-weight:normal;text-align:left}.dir-rtl.path-grade-report-grader .gradeparent .heading .cell,
.dir-rtl.path-grade-report-grader .gradeparent .avg .cell,
.dir-rtl.path-grade-report-grader .gradeparent
.user.cell{text-align:right}.path-grade-report-grader .gradeparent .floater
.cell{background-color:#f9f9f9}.path-grade-report-grader .gradeparent
.user.cell{min-width:200px;width:200px;white-space:normal;vertical-align:top}.path-grade-report-grader .gradeparent .user.cell
.userpicture{margin:0
4px;border:none;vertical-align:middle}.path-grade-report-grader .gradeparent
.userfield{font-weight:normal;text-align:left}.dir-rtl.path-grade-report-grader .gradeparent
.userfield{text-align:right}.path-grade-report-grader .gradeparent .range .header,
.path-grade-report-grader .gradeparent .avg
.header{font-weight:bold}.path-grade-report-grader .gradeparent .avg.floating
.cell{border-top-width:1px}.path-grade-report-grader .gradeparent .avg
.cell{text-align:right}.dir-rtl.path-grade-report-grader .gradeparent .avg
.cell{text-align:left}.path-grade-report-grader .gradeparent .heading .cell
.iconsmall{padding-top:0;padding-bottom:0}.path-grade-report-grader .gradeparent
.sorticon{margin-left:3px}.dir-rtl.path-grade-report-grader .gradeparent
.sorticon{margin-left:0;margin-right:3px}.path-grade-report-grader .gradeparent
.gradevalue{display:inline-block}.path-grade-report-grader
span.gradepass{color:#298721}.path-grade-report-grader
span.gradefail{color:#890d0d}.path-grade-report-grader .gradeparent tr:nth-child(n) td.overridden:nth-child(n){background-color:#efd9a4}.path-grade-report-grader .gradeparent tr:nth-child(n) td.ajaxoverridden:nth-child(n){background-color:#ffe3a0}.path-grade-report-grader .gradeparent
.excludedfloater{font-weight:bold;color:red;font-size:9px;float:left}.dir-rtl.path-grade-report-grader .gradeparent
.excludedfloater{float:right}.path-grade-report .gradeparent .floater .controls.cell,
.path-grade-report-grader .gradeparent
.controls{background-color:#f3ead8}.path-grade-report-grader .gradeparent
.category{text-align:left}.dir-rtl.path-grade-report-grader .gradeparent
.category{text-align:right}.path-grade-report-grader .gradeparent
select{margin:0;padding:0}.path-grade-report-grader .gradeparent
.text{border:1px
solid #666;width:auto;margin:0;padding:0;text-align:center}.path-grade-report-grader .gradeparent
.quickfeedback{border:1px
dashed #000;width:auto;margin:0;padding:0;margin-left:10px}.dir-rtl.path-grade-report-grader .gradeparent
.quickfeedback{margin-left:0;margin-right:10px}.path-grade-report-grader .yui3-overlay{border:0;background:none;background-color:initial;min-width:200px}.path-grade-report-grader .yui3-overlay{background-color:white;width:auto;padding:10px;font-size:12px;border:1px
solid #ccc;border-radius:4px}.path-grade-report-history
div.gradeparent{overflow-x:scroll}.path-grade-report-history .singlebutton div,
.path-grade-report-history .singlebutton div input[type="button"]{margin:0}.yui3-gradereport_history_usp-hidden{display:none}.gradereport_history_usp .usp-content{position:relative}.gradereport_history_usp .usp-ajax-content{overflow:auto;border-top:1px solid #ccc;border-bottom:1px solid #ccc}.gradereport_history_usp .usp-ajax-content,
.gradereport_history_usp .usp-loading-lightbox{height:375px}.gradereport_history_usp .usp-loading-lightbox{background-color:#fff;opacity: .5;position:absolute;text-align:center;width:100%;top:0;left:0}.gradereport_history_usp .usp-loading-lightbox
img{margin-top:100px;opacity:1}.gradereport_history_usp .usp-search{text-align:center}.gradereport_history_usp .usp-user{width:100%;text-align:left;border-top:1px solid #eee}.gradereport_history_usp .usp-user:nth-child(odd){background-color:#f9f9f9}.gradereport_history_usp .usp-first-added{border-top:1px solid #bbb}.gradereport_history_usp .usp-checkbox{text-align:center;float:left;padding:11px
6px 0 6px}.gradereport_history_usp .usp-checkbox input[type=checkbox]{margin:0}.gradereport_history_usp .usp-picture{margin:6px
3px 0 3px;float:left}.gradereport_history_usp .usp-userpicture{cursor:pointer}.gradereport_history_usp .usp-user
.details{margin-left:67px;padding:3px
6px 0 6px;word-wrap:break-word}.gradereport_history_usp .usp-user .details
label{margin:0}.gradereport_history_usp .usp-more-results{padding:5px;border-top:1px solid #bbb}.gradereport_history_usp .usp-finish{padding-top:1em;text-align:center}.gradereport_history_usp .usp-finish
input{margin:0}.dir-rtl .gradereport_history_usp .usp-search-results .usp-user{text-align:right}.dir-rtl .gradereport_history_usp .usp-picture,
.dir-rtl .gradereport_history_usp .usp-checkbox{float:right}.dir-rtl .gradereport_history_usp .usp-user
.details{margin-right:67px;margin-left:0}.dir-rtl .gradereport_history_usp input.usp-search-btn{margin-right:5px}.path-grade-report-singleview
div.reporttable{text-align:center}.path-grade-report-singleview div.groupselector,
.path-grade-report-singleview div.reporttable form div.singleview_buttons,
.path-grade-report-singleview
div.selectitems{display:block;text-align:right;clear:both}.dir-rtl.path-grade-report-singleview div.groupselector,
.dir-rtl.path-grade-report-singleview div.reporttable form div.singleview_buttons,
.dir-rtl.path-grade-report-singleview
div.selectitems{text-align:left}.path-grade-report-singleview div.singleselect+div.singleselect select,
.path-grade-report-singleview div.groupselector
select{margin-right:0px}dir-rtl.path-grade-report-singleview div.singleselect+div.singleselect select,
dir-rtl.path-grade-report-singleview div.groupselector
select{margin-right:10px;margin-left:0px}.path-grade-report-singleview div.reporttable div.singleselect form
div{text-align:center}.path-grade-report-singleview div.reporttable
table.reporttable{margin:0
auto 15px auto}.path-grade-report-singleview div.reporttable form
div{text-align:center}.path-grade-report-singleview
.singleview_buttons{padding:10px
0}.path-grade-report-singleview div.reporttable
h2{text-align:center}.path-grade-report-singleview input[name^="finalgrade"]{width:50px}.path-grade-report-singleview .reporttable tbody th,
.path-grade-report-singleview .reporttable tbody
td.range{white-space:nowrap}.path-grade-report-singleview .reporttable tbody th>*{display:inline-block;vertical-align:middle;margin:0
2px}.path-grade-report-singleview
.itemnav{font-size:small;display:inline;margin-bottom:0.5em}.path-grade-report-singleview
itemnav.previtem{float:left}.path-grade-report-singleview.dir-rtl
div.previtem{float:right}.path-grade-report-singleview
div.nextitem{float:right}.path-grade-report-singleview.dir-rtl
div.nextitem{float:left}.path-grade-report-singleview
.reporttable{width:100%}.path-grade-report-singleview .reporttable
th{text-align:left}.dir-rtl.path-grade-report-singleview .reporttable
th{text-align:right}.path-grade-report-singleview div.reporttable form
div.singleview_bulk{display:inline-block;text-align:left;margin-bottom:1em}.dir-rtl.path-grade-report-singleview div.reporttable form
div.singleview_bulk{text-align:right}.path-grade-report-singleview .singleview_bulk div > *,
.path-grade-report-singleview .singleview_bulk fieldset>*{display:inline-block;vertical-align:middle;margin:0}.path-grade-report-singleview .singleselect select,
.path-grade-report-singleview div.reporttable form .singleview_bulk select,
.path-grade-report-singleview div.reporttable form .singleview_bulk
input{margin-left:10px;margin-right:10px}.path-grade-report-singleview .singleview_bulk>fieldset{display:block}.path-grade-report-singleview div.reporttable form .singleview_bulk>div.enable{margin-bottom:0.5em;text-align:left}.dir-rtl.path-grade-report-singleview div.reporttable form .singleview_bulk>div.enable{text-align:right}.path-grade-report-user
#graded_users_selector{float:right;margin-bottom:5px}.path-grade-report-user #graded_users_selector .singleselect
label{display:inline-block}.path-grade-report-user .user-grade{width:100%;border:1px
solid}.path-grade-report-user .user-grade thead
th{vertical-align:bottom}.path-grade-report-user .user-grade
th{text-align:left}.path-grade-report-user .user-grade
td{min-width:4.5em;vertical-align:top}.dir-rtl.path-grade-report-user .user-grade
td{direction:ltr}.dir-rtl.path-grade-report-user table.user-grade{border-collapse:separate}.path-grade-report-user .user-grade
.b1l{padding:0;width:24px;min-width:24px}.path-grade-report-user .user-grade tbody .column-itemname{padding-left:0;padding-right:8px}.path-grade-report-user .user-grade .column-itemname.item,
.path-grade-report-user .user-grade
.gradeitemdescription{font-weight:normal;padding-left:24px}.path-grade-report-user .user-grade .column-itemname.baggt,
.path-grade-report-user .user-grade .column-itemname.baggb{padding-left:24px}.path-grade-report-user .user-grade .baggt,
.path-grade-report-user .user-grade
.baggb{font-weight:bold}.dir-rtl.path-grade-report-user
#graded_users_selector{float:left}.dir-rtl.path-grade-report-user .user-grade
th{text-align:right}.dir-rtl.path-grade-report-user .user-grade tbody .column-itemname{padding-right:0;padding-left:8px}.dir-rtl.path-grade-report-user .user-grade .column-itemname.item,
.dir-rtl.path-grade-report-user .user-grade
.gradeitemdescription{padding-right:24px}.dir-rtl.path-grade-report-user .user-grade .column-itemname.baggt,
.dir-rtl.path-grade-report-user .user-grade .column-itemname.baggb{padding-right:24px}.gradingform_guide-regrade{padding:10px;background:#FDD;border:1px
solid #F00;margin-bottom:10px}.gradingform_guide-restored{padding:10px;background:#FFD;border:1px
solid #FF0;margin-bottom:10px}.gradingform_guide-error{color:red;font-weight:bold}.gradingform_guide_editform
.status{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE}.gradingform_guide_editform
.status.ready{background-color:#e7f1c3;border-color:#AEA}.gradingform_guide_editform
.status.draft{background-color:#f3f2aa;border-color:#EE2}.gradingform_guide.editor .criterion .controls,
.gradingform_guide .criterion .description,
.gradingform_guide .criterion
.remark{vertical-align:top}.gradingform_guide.editor .criterion .controls,
.gradingform_guide.editor .criterion .description,
.gradingform_guide.editor .criterion
.remark{padding:3px}.gradingform_guide
.criteria{height:100%}.gradingform_guide
.criterion{border:1px
solid #DDD;overflow:hidden}.gradingform_guide
.criterion.even{background:#F0F0F0}.gradingform_guide .criterion
.description{width:100%}.gradingform_guide .criterion .description .criterionmaxscore
input{width:20px}.gradingform_guide .criterion .description
.criterionname{font-weight:bold}.gradingform_guide .criterion
label{font-weight:bold;padding-right:5px}.gradingform_guide
.plainvalue.empty{font-style:italic;color:#AAA}.gradingform_guide
.plainvalue.editname{font-weight:bold}.gradingform_guide.editor .criterion.first.last .controls .delete input,
.gradingform_guide.editor .criterion.first .controls .moveup input,
.gradingform_guide.editor .criterion.last .controls .movedown
input{display:none}.gradingform_guide.editor .delete input,
.gradingform_guide.editor .moveup input,
.gradingform_guide.editor .movedown
input{text-indent:-1000em;cursor:pointer;border:none}.gradingform_guide.editor .criterion .controls .delete
input{width:20px;height:16px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/delete) no-repeat center top;margin-top:4px}.gradingform_guide.editor .moveup
input{width:20px;height:15px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/up) no-repeat center top;margin-top:4px}.gradingform_guide.editor .movedown
input{width:20px;height:15px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/down) no-repeat center top;margin-top:4px}.gradingform_guide.editor .addcriterion input,
.gradingform_guide.editor .addcomment
input{background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/add) no-repeat;display:block;color:#555;font-weight:bold;text-decoration:none}.gradingform_guide.editor .addcriterion input,
.gradingform_guide.editor .addcomment
input{background-position:5px 8px;height:30px;line-height:29px;margin-bottom:14px;padding-left:20px;padding-right:10px}.gradingform_guide .options
.optionsheading{font-weight:bold;font-size:1.1em;padding-bottom:5px}.gradingform_guide .options
.option{padding-bottom:2px}.gradingform_guide .options .option
label{margin-left:5px}.gradingform_guide .options .option
.value{margin-left:5px;font-weight:bold}.gradingform_guide .criterion
.description.error{background:#FDD}.gradingform_guide.editor
.hiddenelement{display:none}.gradingform_guide.editor
.pseudotablink{background-color:transparent;border:0
solid;height:1px;width:1px;color:transparent;padding:0;margin:0;position:relative;float:right}.jsenabled .gradingform_guide
.markingguidecomment{cursor:pointer}.jsenabled .gradingform_guide .markingguidecomment:before{content:url(/sunguru/theme/image.php/archaius/core/1531975376/t/add);padding-right:2px}.dir-rtl.jsenabled .gradingform_guide .markingguidecomment:before{padding-right:0;padding-left:2px}.gradingform_guide
.commentheader{font-weight:bold;font-size:1.1em;padding-bottom:5px}.jsenabled .gradingform_guide
.criterionnamelabel{display:none}.jsenabled .gradingform_guide
.criterionshortname{font-weight:bold}.gradingform_guide
table{width:100%}.gradingform_guide
.descriptionreadonly{vertical-align:top}.gradingform_guide
.criteriondescriptionmarkers{width:300px}.gradingform_guide
.markingguideremark{margin:0;width:100%;-moz-box-sizing:border-box;box-sizing:border-box}.gradingform_guide
.criteriondescriptionscore{display:inline}.gradingform_guide .score
label{display:block}.gradingform_guide .score
input{margin:0;width:auto}.gradingform_rubric_editform
.status{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE}.gradingform_rubric_editform
.status.ready{background-color:#e7f1c3;border-color:#AEA}.gradingform_rubric_editform
.status.draft{background-color:#f3f2aa;border-color:#EE2}.gradingform_rubric{overflow:auto;padding-bottom:1.5em;max-width:720px;position:relative}.gradingform_rubric.editor .criterion .controls,
.gradingform_rubric .criterion .description,
.gradingform_rubric .criterion .levels,
.gradingform_rubric.editor .criterion .addlevel,
.gradingform_rubric .criterion .remark,
.gradingform_rubric .criterion .levels
.level{vertical-align:top}.gradingform_rubric.editor .criterion .controls,
.gradingform_rubric .criterion .description,
.gradingform_rubric.editor .criterion .addlevel,
.gradingform_rubric .criterion .remark,
.gradingform_rubric .criterion .levels
.level{padding:3px}.gradingform_rubric
.criteria{height:100%}.gradingform_rubric
.criterion{border:1px
solid #DDD;overflow:hidden}.gradingform_rubric
.criterion.even{background:#F0F0F0}.gradingform_rubric .criterion
.description{width:150px;font-weight:bold}.gradingform_rubric .criterion .levels
table{width:100%;height:100%}.gradingform_rubric .criterion .levels,
.gradingform_rubric .criterion .levels table,
.gradingform_rubric .criterion .levels table
tbody{padding:0;margin:0}.gradingform_rubric .criterion .levels
.level{border-left:1px solid #DDD;max-width:150px}.gradingform_rubric .criterion .levels .level .level-wrapper{position:relative}.gradingform_rubric .criterion .levels
.level.last{border-right:1px solid #DDD}.gradingform_rubric
.plainvalue.empty{font-style:italic;color:#AAA}.gradingform_rubric.editor .criterion .levels .level
.delete{position:absolute;right:0}.gradingform_rubric .criterion .levels .level
.score{font-style:italic;color:#575;font-weight:bold;margin-top:5px;white-space:nowrap}.gradingform_rubric .criterion .levels .level .score
.scorevalue{padding-right:5px}.gradingform_rubric.editor .criterion.first .controls .moveup input,
.gradingform_rubric.editor .criterion.last .controls .movedown
input{display:none}.gradingform_rubric .criterion .levels
.level.currentchecked{background:#fff0f0}.gradingform_rubric .criterion .levels
.level.checked{background:#d0ffd0;border:1px
solid #555}.gradingform_rubric.evaluate .criterion .levels .level:hover{background:#30ff30}.gradingform_rubric.editor .delete input,
.gradingform_rubric.editor .duplicate input,
.gradingform_rubric.editor .moveup input,
.gradingform_rubric.editor .movedown
input{text-indent:-1000em;cursor:pointer;border:none}.gradingform_rubric.editor .criterion .controls .delete
input{width:12px;height:12px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/delete) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .criterion .controls .duplicate
input{width:12px;height:12px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/copy) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .levels .level .delete
input{width:12px;height:16px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/delete) no-repeat center center}.dir-rtl .gradingform_rubric.editor .levels .level .delete
input{margin-right: .45em;margin-left:0}.gradingform_rubric.editor .moveup
input{width:12px;height:12px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/up) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .movedown
input{width:12px;height:12px;background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/down) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .addcriterion input,
.gradingform_rubric.editor .addlevel
input{background:transparent url(/sunguru/theme/image.php/archaius/core/1531975376/t/add) no-repeat top left;display:block;color:#555;font-weight:bold;text-decoration:none}.gradingform_rubric.editor .addcriterion
input{background-position:5px 8px;height:30px;line-height:29px;margin-bottom:14px;padding-left:20px;padding-right:10px}.gradingform_rubric.editor .addlevel
input{background-position:5px 5px;height:25px;line-height:24px;margin-bottom:45px;padding-left:18px;padding-right:8px}.gradingform_rubric .options
.optionsheading{font-weight:bold;font-size:1.1em;padding-bottom:5px}.gradingform_rubric .options
.option{padding-bottom:2px}.gradingform_rubric .options .option
label{margin-left:5px}.gradingform_rubric .options .option
.value{margin-left:5px;font-weight:bold}.gradingform_rubric .criterion
.levels.error{border:1px
solid red}.gradingform_rubric .criterion .description.error,
.gradingform_rubric .criterion .levels .level .definition.error,
.gradingform_rubric .criterion .levels .level
.score.error{background:#FDD}.gradingform_rubric-regrade{padding:10px;background:#FDD;border:1px
solid #F00;margin-bottom:10px}.gradingform_rubric-restored{padding:10px;background:#FFD;border:1px
solid #FF0;margin-bottom:10px}.gradingform_rubric-error{color:red;font-weight:bold}.gradingform_rubric.editor
.hiddenelement{display:none}.gradingform_rubric.editor
.pseudotablink{background-color:transparent;border:0
solid;height:1px;width:1px;color:transparent;padding:0;margin:0;position:relative;float:right}.path-admin-mnet-service-enrol
.singlebutton{text-align:center}.path-admin-mnet-service-enrol table.remotehosts,
.path-admin-mnet-service-enrol table.otherenrolledusers,
.path-admin-mnet-service-enrol
table.remotecourses{margin:0px
auto 1em auto}.path-admin-mnet-service-enrol table.remotecourses
th.categoryname{text-align:left;background-color:#f6f6f6}.path-admin-mnet-service-enrol table.remotecourses
td.c1{font-weight:bold}.path-admin-mnet-service-enrol table.remotecourses th.categoryname
img{margin-right:1em}.path-admin-mnet-service-enrol
.collapsibleregioncaption{font-size:110%;font-weight:bold;text-align:center}.path-admin-mnet-service-enrol
.collapsibleregioninner{border:1px
solid #ddd;padding:1em}.path-admin-mnet-service-enrol
.collapsibleregion.remotecourse.summary{margin:0px
10em}.path-admin-mnet-service-enrol
.roleassigntable{margin:1em
auto}.qbehaviour_deferredcbm_slightlyunderconfident,.qbehaviour_deferredcbm_slightlyoverconfident{font-weight:bold;color:#600}.qbehaviour_deferredcbm_underconfident,.qbehaviour_deferredcbm_overconfident{font-weight:bold;color:#c00}.qbehaviour_deferredcbm_judgementok{font-weight:bold;color:#080}.qbehaviour_deferredcbm_actual_percentage{font-weight:bold}.qbehaviour_deferredcbm_summary_heading{margin:0}.que.deferredcbm .certaintychoices input[type="radio"]{margin-left:0.5em}.que.deferredcbm .certaintychoices
label{white-space:nowrap}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable
.c0{display:none}#page-admin-tool-assignmentupgrade-listnotupgraded.jsenabled .tool_assignmentupgrade_upgradetable
.c0{display:table-cell}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable tr.selectedrow
td{background-color:#fec}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable tr.unselectedrow
td{background-color:white}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_paginationform
.hidden{display:none}.steps-definitions{border-style:solid;border-width:1px;border-color:#BBB;padding:5px;margin:auto;width:50%}.steps-definitions
.step{margin:10px
0px 10px 0px}.steps-definitions
.stepdescription{color:#bf8c12}.steps-definitions
.steptype{color:#1467a6;margin-right:5px}.steps-definitions
.stepregex{color:#060}.path-admin-tool-capability
.comparisontable{margin-top:150px}.path-admin-tool-capability .comparisontable th,
.path-admin-tool-capability .comparisontable
td{vertical-align:middle;padding:0.4em 0.5em 0.3em}.path-admin-tool-capability .comparisontable thead
th{vertical-align:bottom;background:none}.path-admin-tool-capability .comparisontable thead th
div{position:relative}.path-admin-tool-capability .comparisontable thead th div>a{position:absolute;top:-1.75em;left:1em;width:150px;text-align:left;margin-bottom:1em;text-indent:-1.45em;-webkit-transform-origin:top left;-moz-transform-origin:top left;-ms-transform-origin:top left;-o-transform-origin:top left;-webkit-transform:rotate(315deg);-moz-transform:rotate(315deg);-ms-transform:rotate(315deg);-o-transform:rotate(315deg)}.path-admin-tool-capability .comparisontable tbody
th{background-color:#EEE;text-align:right;border:1px
solid #DFDFDF}.path-admin-tool-capability .comparisontable tbody th
span{display:block;color:#666;font-size:80%}.path-admin-tool-capability .comparisontable tbody
td{border:1px
solid #DFDFDF}.path-admin-tool-capability .comparisontable
.inherit{color:#666}.path-admin-tool-capability .comparisontable
.allow{background-color:#060;font-weight:bold;color:white}.path-admin-tool-capability .comparisontable
.prevent{background-color:#ad6704;font-weight:bold;color:white}.path-admin-tool-capability .comparisontable
.prohibit{background-color:#800;font-weight:bold;color:white}.path-admin-tool-customlang .langselectorbox,
.path-admin-tool-customlang fieldset.buttonsbar,
.path-admin-tool-customlang
.menu{margin:5px
auto;text-align:center}.path-admin-tool-customlang .menu .singlebutton,
.path-admin-tool-customlang .menu .singlebutton form,
.path-admin-tool-customlang .menu .singlebutton form
div{display:inline}.path-admin-tool-customlang
.mform.filterform{width:70%;margin-left:auto;margin-right:auto}.path-admin-tool-customlang .mform.filterform .fitem
.fitemtitle{width:30%}.path-admin-tool-customlang .mform.filterform .fitem
.felement{width:60%;margin-left:31%}.path-admin-tool-customlang
#translator{width:100%}.path-admin-tool-customlang #translator .standard,
.path-admin-tool-customlang #translator
.local{min-width:35%}.path-admin-tool-customlang #translator
.customized{background-color:#e7f1c3}.path-admin-tool-customlang #translator
.customized.outdated{background-color:#f3f2aa}.path-admin-tool-customlang #translator
.modified{background-color:#ffd3d9}.path-admin-tool-customlang #translator
.customized.modified{background-color:#d2ebff}.path-admin-tool-customlang #translator
textarea{width:100%;min-height:4em}.path-admin-tool-customlang #translator
.placeholderinfo{text-align:center;border:1px
dotted #ddd;background-color:#f6f6f6;margin-top:0.5em}#page-admin-tool-customlang-index
.continuebutton{margin-top:1em}.path-admin-tool-customlang #translator
.standard.master.cell.c2{word-break:break-all}#page-admin-tool-editrolesbycap-index
select#id_cap{width:100%}#page-admin-tool-editrolesbycap-index table.roledefs
.c1{white-space:nowrap}#page-admin-tool-editrolesbycap-index table.roledefs
td.lastcol{font-size:0.7em}#page-admin-tool-editrolesbycap-index
.capdefault{background-color:#DDD;border:1px
solid #CECECE}#page-admin-tool-editrolesbycap-index
.advancedbutton{text-align:right;margin:0
0 0.7em}#page-admin-tool-editrolesbycap-index
.submitbutton{text-align:center;margin-bottom:2em}.path-admin-tool-filetypes .generaltable .c0,
.path-admin-tool-filetypes .generaltable .c1,
.path-admin-tool-filetypes .generaltable .c2,
.path-admin-tool-filetypes .generaltable
th{white-space:nowrap}.path-admin-tool-filetypes .generaltable .deleted .c0
img{opacity:0.2}.path-admin-tool-filetypes .generaltable .deleted .c0
span{text-decoration:line-through}.path-admin-tool-filetypes .generaltable
.nonstandard{font-weight:bold}.path-admin-tool-filetypes .form-overridden{display:inline-block;margin-bottom:1em;padding:4px
6px}.path-admin-tool-health
div#healthnoproblemsfound{width:60%;margin:auto;padding:1em;border:1px
solid black;-moz-border-radius:6px}.path-admin-tool-health
dl.healthissues{width:60%;margin:auto}.path-admin-tool-health dl.critical dt,
.path-admin-tool-health dl.critical
dd{background-color:#a71501}.path-admin-tool-health dl.significant dt,
.path-admin-tool-health dl.significant
dd{background-color:#d36707}.path-admin-tool-health dl.annoyance dt,
.path-admin-tool-health dl.annoyance
dd{background-color:#dba707}.path-admin-tool-health dl.notice dt,
.path-admin-tool-health dl.notice
dd{background-color:#e5db36}.path-admin-tool-health dt.solution,
.path-admin-tool-health dd.solution,
.path-admin-tool-health
div#healthnoproblemsfound{background-color:#5BB83E !important}.path-admin-tool-health dl.healthissues dt,
.path-admin-tool-health dl.healthissues
dd{margin:0px;padding:1em;border:1px
solid black}.path-admin-tool-health dl.healthissues
dt{font-weight:bold;border-bottom:0;padding-bottom:0.5em}.path-admin-tool-health dl.healthissues
dd{border-top:0;padding-top:0.5em;margin-bottom:10px}.path-admin-tool-health dl.healthissues dd
form{margin-top:0.5em;text-align:right}.path-admin-tool-health
form#healthformreturn{text-align:center;margin:2em}.path-admin-tool-health dd.solution
p{padding:0px;margin:1em
0px}.path-admin-tool-health dd.solution
li{margin-top:1em}#page-admin-tool-installaddon-index
#installfromrepobox{text-align:center;padding-top:2em;padding-bottom:2em}#page-admin-tool-installaddon-index #installfromrepobox
.singlebutton{display:inline-block}#page-admin-tool-installaddon-index #installfromrepobox .singlebutton input[type=submit]{padding:1em}#page-admin-tool-langimport-index .generalbox
table{margin:auto;width:100%}#page-admin-tool-langimport-index .generalbox,
#page-admin-tool-langimport-index .generalbox
table{text-align:center}.path-admin-tool-lp [data-region="managecompetencies"] ul li,
.path-admin-tool-lp [data-region="plans"] ul li,
.path-admin-tool-lp [data-region="competencymovetree"] ul li,
.path-admin-tool-lp [data-region="competencylinktree"] ul
li{list-style-type:none}.path-admin-tool-lp
.progresstext{display:inline-block;vertical-align:top}.path-admin-tool-lp
.progress{width:100%;display:inline-block}.path-admin-tool-lp .progress
.bar{min-width:3em}.dir-rtl.path-admin-tool-lp .progress
.bar{float:right}.path-admin-tool-lp [data-region="managecompetencies"] ul[data-enhance="tree"],
.path-admin-tool-lp [data-region="plans"] ul[data-enhance="tree"],
.path-admin-tool-lp [data-region="competencylinktree"] ul[data-enhance="linktree"],
.path-admin-tool-lp [data-region="competencymovetree"] ul[data-enhance="movetree"]{border:1px
solid #ccc;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);transition:border linear .2s,box-shadow linear .2s;border-radius:4px;padding-left:20px;padding-right:20px;margin-left:10px;margin-right:10px}.path-admin-tool-lp [data-region="managecompetencies"] ul,
.path-admin-tool-lp [data-region="plans"] ul,
.path-admin-tool-lp [data-region="competencylinktree"] ul,
.path-admin-tool-lp [data-region="competencymovetree"] ul{cursor:pointer}.path-admin-tool-lp [data-region="competencylinktree"] ul li>span,
.path-admin-tool-lp [data-region="competencymovetree"] ul li>span,
.path-admin-tool-lp [data-region="plans"] ul li>span,
.path-admin-tool-lp [data-region="managecompetencies"] ul li>span{padding-top:2px;padding-bottom:2px;padding-left:4px;padding-right:4px;border-radius:4px}.path-admin-tool-lp [data-region="competencylinktree"] ul [aria-selected="true"]>span,
.path-admin-tool-lp [data-region="competencymovetree"] ul [aria-selected="true"]>span,
.path-admin-tool-lp [data-region="plans"] ul [aria-selected="true"]>span,
.path-admin-tool-lp [data-region="managecompetencies"] ul [aria-selected="true"]>span{background-color:#dfdfdf}.path-admin-tool-lp [data-region="competencylinktree"] ul [tabindex="0"]>span,
.path-admin-tool-lp [data-region="competencymovetree"] ul [tabindex="0"]>span,
.path-admin-tool-lp [data-region="plans"] ul [tabindex="0"]>span,
.path-admin-tool-lp [data-region="managecompetencies"] ul [tabindex="0"]>span{border:2px
solid #0070a8}.path-admin-tool-lp [data-region="filtercompetencies"] input{margin-left:10px}.dir-rtl.path-admin-tool-lp [data-region="managecompetencies"] .row-fluid [class*="span"]{float:right}.path-admin-tool-lp [data-region="link-buttons"],
.path-admin-tool-lp [data-region="move-buttons"]{text-align:center}.path-admin-tool-lp [data-region="competencylinktree"]>ul{overflow-y:auto;height:400px}.dir-rtl.path-admin-tool-lp [data-region="filtercompetencies"] input{margin-right:10px}.path-admin-tool-lp
span.currentdragtarget{border:1px
dashed}.path-admin-tool-lp
.competencyactionsmenu{display:inline-block;vertical-align:text-top}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-base"]{display:table;width:100%}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"],
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"]{display:table-row}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] label,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] label{padding-right:10px}.dir-rtl.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] label,
.dir-rtl.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] label{padding-left:10px;padding-right:0}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] label,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] select,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] label,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] select{display:table-cell}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] select,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] select,
.path-admin-tool-lp [data-region="competencylinktree"] select{width:100%}.path-admin-tool-lp [data-region] .generaltable.fullwidth{clear:both}.path-admin-tool-lp .competency-rule-points{margin-top:10px}.path-admin-tool-lp .competency-rule-points table
input{margin-bottom:0}.path-admin-tool-lp .competency-rule-points tr[data-competency] th{font-weight:normal}.path-admin-tool-lp .competency-rule-points input[type="number"]{width:50px}.competency-heading{margin-bottom:15px}.competency-heading
h4{margin:0}.tool-lp-menu{margin:0}.tool-lp-menu
li{float:left;display:inline;position:relative;list-style-type:none;white-space:nowrap}.tool-lp-sub-menu{position:absolute;list-style:none;margin:0;top:-10px}.tool-lp-sub-menu
li{float:none}.tool-lp-menu .tool-lp-sub-menu[aria-hidden=false]{display:block}.tool-lp-menu ul[aria-hidden=true]{display:none}.tool-lp-menu
.caret{margin:8px}.tool-lp-menu.tool-lp-menu-open-left .tool-lp-sub-menu{margin-left:-120px}.dir-rtl .tool-lp-menu.tool-lp-menu-open-left .tool-lp-sub-menu{margin-left:0px;margin-right:-120px}.tool-lp-menu .tool-lp-sub-menu .menu-focus
a{color:#fff;text-decoration:none;background-color:#00699e;background-image:linear-gradient(to bottom,#0070a8,#005f8f);background-repeat:repeat-x}input[type="radio"].tool_lp_scale_default,input[type="checkbox"].tool_lp_scale_proficient{margin-top:0px}.user-evidence-documents{margin:10px
20px;list-style:none}.user-evidence-competencies,
.user-evidence-documents
li{margin-bottom:5px;word-break:break-all}[data-region="user-evidence-list"] .user-evidence-competencies,
[data-region="user-evidence-list"] .user-evidence-documents{margin:0;list-style:none}.user-competency-course-navigation
select{display:none}.user-competency-course-navigation{width:240px}.user-competency-course-navigation
span{max-width:100%;overflow:hidden}.competency-grader
textarea{width:100%;max-width:100%;box-sizing:border-box}.dir-rtl.path-admin-tool-lp .pull-left{float:right}.dir-rtl.path-admin-tool-lp .pull-right{float:left}.dir-rtl.path-admin-tool-lp
dd{margin-right:10px}.dir-rtl.path-admin-tool-lp
ul.inline{margin-right:0}#page-admin-tool-messageinbound-index .handler-function{display:block;padding:0
0.5em;color:#888;font-size:0.75em}#page-admin-tool-messageinbound-index .state,
#page-admin-tool-messageinbound-index
.edit{text-align:center}.path-admin-tool-profiling .profilingruntable
.label{font-weight:bold}.path-admin-tool-profiling
.profiling_worse{color:red}.path-admin-tool-profiling
.profiling_better{color:green}.path-admin-tool-profiling
.profiling_same{color:dimgrey}.path-admin-tool-profiling .profiling_important,
.path-admin-tool-profiling .flexible
.referencerun{font-weight:bold}.path-admin-tool-profiling
.flexible{margin-left:auto;margin-right:auto}#page-admin-tool-task-scheduledtasks .task-class{display:block;padding:0
0.5em;color:#888;font-size:0.75em}[data-region="displaytemplateexample"]{border-radius:4px;border:1px
inset #e3e3e3;padding:1em}.assignfeedback_editpdf_widget .toolbar
ul{display:none}.assignfeedback_editpdf_widget .toolbar
li{list-style-type:none}.assignfeedback_editpdf_widget
.drawingcanvas{position:relative;min-width:817px;min-height:400px;cursor:crosshair;background-repeat:no-repeat;background-color:#ccc;margin-left:auto;margin-right:auto;box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 20px rgba(0,0,0,.2)}.assignfeedback_editpdf_widget .moodle-dialogue-bd
.drawingregion{position:inherit}.assignfeedback_editpdf_widget .drawingregion[data-currenttool=drag] .drawingcanvas{cursor:move}.assignfeedback_editpdf_widget .drawingregion[data-currenttool=select] .drawingcanvas{cursor:pointer}.assignfeedback_editpdf_widget
.drawingregion{border:1px
solid #ccc;left:1em;right:1em;top:52px;bottom:0px;position:absolute;overflow:auto;background-color:#ccc}.assignfeedback_editpdf_widget{user-select:none;-moz-user-select:none;-webkit-user-select:none;-o-user-select:none}.assignfeedback_editpdf_widget
.pageheader{background-color:#ebebeb;border-bottom:1px solid #ccc;padding:0px;padding-left:20px;padding-right:20px;min-height:50px;height:52px;overflow:auto}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_widget .moodle-dialogue-bd{padding:0px}.assignfeedback_editpdf_widget
.assignfeedback_editpdf_unsavedchanges.haschanges{display:inline-block}.assignfeedback_editpdf_widget
.assignfeedback_editpdf_unsavedchanges{display:none;position:absolute;left:20px;top:60px}.dir-rtl .assignfeedback_editpdf_widget
.assignfeedback_editpdf_unsavedchanges{float:right}.yui3-colourpicker-hidden,.yui3-commentsearch-hidden,.yui3-commentmenu-hidden{display:none}.assignfeedback_editpdf_widget .pageheader button
img{padding-top:3px;vertical-align:top}.assignfeedback_editpdf_widget .pageheader button:active{background-color:#ccc}.assignfeedback_editpdf_widget .pageheader select,
.assignfeedback_editpdf_widget .pageheader
button{background:none;padding:4px
7px;border:0px;border-radius:0px;margin:0px;height:30px;line-height:30px;vertical-align:top;cursor:pointer}.assignfeedback_editpdf_widget .pageheader
select{vertical-align:top;-webkit-appearance:none;-moz-appearance:menulist-text;background-color:#fff;padding:0px
10px}.assignfeedback_editpdf_widget .pageheader select::-ms-expand{display:none}.assignfeedback_editpdf_widget .pageheader .navigation button + button,
.assignfeedback_editpdf_widget .pageheader .toolbar button + button,
.assignfeedback_editpdf_widget .pageheader .navigation select + button,
.assignfeedback_editpdf_widget .pageheader .toolbar select+button{border-left:1px solid #ccc;border-right:0px}.assignfeedback_editpdf_widget .pageheader .navigation
button{border-right:1px solid #ccc}.assignfeedback_editpdf_widget .pageheader .toolbar,
.assignfeedback_editpdf_widget .pageheader .navigation-search,
.assignfeedback_editpdf_widget .pageheader
.navigation{border:1px
solid #ccc;border-bottom-color:#b3b3b3;border-radius:4px;margin:10px
4px;background-color:white;height:30px;line-height:30px;padding:0px}.assignfeedback_editpdf_commentsearch
ul{max-height:400px;overflow-y:auto;padding:1em}.assignfeedback_editpdf_commentsearch ul li
pre{background-color:#efefef}.assignfeedback_editpdf_commentsearch ul li pre:hover{background-color:#ddd}.assignfeedback_editpdf_commentsearch ul
li{line-height:0px;margin:2px}.assignfeedback_editpdf_commentsearch a
pre{font-family:helvetica;margin:0px;padding:4px}.assignfeedback_editpdf_widget .navigation-search,
.assignfeedback_editpdf_widget
.navigation{float:left}.dir-rtl .assignfeedback_editpdf_widget .navigation-search,
.dir-rtl .assignfeedback_editpdf_widget
.navigation{float:right}.assignfeedback_editpdf_widget .toolbar
button{box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none}.assignfeedback_editpdf_widget
.toolbar{float:right}.dir-rtl .assignfeedback_editpdf_widget
.toolbar{float:left}.assignfeedback_editpdf_widget .navigation,
.assignfeedback_editpdf_widget .navigation-search,
.assignfeedback_editpdf_widget
.toolbar{display:inline-block}.assignfeedback_editpdf_colourpicker
ul{margin:0px}.assignfeedback_editpdf_commentmenu
li.quicklist_comment{width:150px}.assignfeedback_editpdf_commentmenu li.quicklist_comment
a{white-space:nowrap;display:inline-block;max-width:130px;overflow:hidden;text-overflow:ellipsis}.assignfeedback_editpdf_commentmenu
a.delete_quicklist_comment{float:right}.dir-rtl .assignfeedback_editpdf_commentmenu
a.delete_quicklist_comment{float:left}.assignfeedback_editpdf_dropdown
button{border:0px;background:none;padding:6px
7px;border-radius:0px;border-top:1px solid #ccc}.assignfeedback_editpdf_dropdown li:first-child
button{border-top:0px}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_dropdown .moodle-dialogue-wrap{box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none;margin-left:0px;margin-right:0px;margin-top:0px;border-radius:4px}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_dropdown .moodle-dialogue-bd{padding:0px}.assignfeedback_editpdf_dropdown .moodle-dialogue-hd,
.assignfeedback_editpdf_dropdown .moodle-dialogue-ft{display:none}.assignfeedback_editpdf_menu li
hr{margin:0px}.assignfeedback_editpdf_menu li
a{text-decoration:none;color:#555;margin:10px}.assignfeedback_editpdf_menu li:hover,
.assignfeedback_editpdf_menu li:hover a,
.assignfeedback_editpdf_menu li a:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%)}ul.assignfeedback_editpdf_menu{margin:0px}.assignfeedback_editpdf_menu
li{list-style-type:none;margin:0px;border-radius:4px}.assignfeedback_editpdf_menu li
img{height:auto}.assignfeedback_editpdf_menu li
button{margin:0px;background:none}.assignfeedback_editpdf_widget .pageheader button:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%)}.assignfeedback_editpdf_widget .pageheader button.assignfeedback_editpdf_selectedbutton:hover,
.assignfeedback_editpdf_widget .pageheader
button.assignfeedback_editpdf_selectedbutton{background-color:#dfdfdf;background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%)}.assignfeedback_editpdf_widget .commentdrawable
img{padding:1px}.assignfeedback_editpdf_widget .commentdrawable
a{float:right;position:relative;left:-17px;top:2px;height:14px;background-color:white;border-left:1px solid #ccc;border-bottom:1px solid #ccc;line-height:14px}.dir-rtl .assignfeedback_editpdf_widget .commentdrawable
a{float:left;left:none;right:-17px;border-left:0px;border-right:1px solid #ccc}.assignfeedback_editpdf_widget .commentdrawable
textarea{padding:4px;padding-right:20px;resize:none;overflow:hidden;color:black;border:2px
solid #ccc;border-radius:4px;font-size:16px;font-family:helvetica;min-height:1.2em}.assignfeedback_editpdf_widget
.commentdrawable{display:inline-block}.dir-rtl .assignfeedback_editpdf_widget .commentdrawable
textarea{padding-left:20px;padding-right:4px}.assignfeedback_editpdf_widget .drawingcanvas .loading
.progressbarlabel{text-align:center}.hideoverflow{overflow:hidden;position:relative}@media (max-width: 960px){.assignfeedback_editpdf_widget
.pageheader{height:104px}.assignfeedback_editpdf_widget
.drawingregion{top:104px}}@media (max-width: 767px){.assignfeedback_editpdf_widget
.drawingregion{position:relative;margin-bottom:1em;top:0}.assignfeedback_editpdf_widget
.pageheader{height:auto}}@media (max-width: 480px){.assignfeedback_editpdf_widget
.pageheader{padding-left:5px;padding-right:5px}}#page-mod-quiz-report
#manualgradingform{width:100%}#page-mod-quiz-report #manualgradingform.mform
br{clear:none}#page-mod-quiz-report #manualgradingform.mform .clearfix:after{clear:none}#page-mod-quiz-report #manualgradingform
.que{margin-bottom:0.7em}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper,
.path-mod-workshop .assessmentform.rubric #id_rubric-grid-wrapper{border:none}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper legend,
.path-mod-workshop .assessmentform.rubric #id_rubric-grid-wrapper
legend{display:none}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper th,
.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper td,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper th,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
td{border:1px
solid #ddd;padding:5px;vertical-align:top}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
.criterion{text-align:center}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
.fitem{text-align:center}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem .fitemtitle,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem
.fitemtitle{display:none}.path-mod-workshop #id_rubric-grid-wrapper .rubric-grid{margin-left:auto;margin-right:auto}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem .felement,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem
.felement{width:100%;margin-left:auto;margin-right:auto}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem
.felement{border:none}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem .felement
span{display:block;text-align:center}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem .felement span
label{display:block;text-align:center}.path-mod-workshop .mform.frozen .fitem.description.rubric + .fitem .fitemtitle,
.path-mod-workshop .assessmentform.rubric.list #id_rubric-grid-wrapper .fitem
.fitemtitle{display:none}.path-mod-workshop .mform.frozen .fitem.description.rubric + .fitem .fitemtitle + .felement,
.path-mod-workshop .assessmentform.rubric.list .fitem
.felement{width:auto;border:none}.path-mod-workshop .assessmentform.rubric.list .fitem .felement span
input{display:block;float:left}.path-mod-workshop .assessmentform.rubric.list .fitem .felement.fgroup span
label{display:block;margin-left:30px}.path-mod-workshop .manual-allocator
.allocations{margin:0px
auto;width:100%}.path-mod-workshop .manual-allocator .allocations tbody tr:nth-of-type(odd){background-color:#eee}.path-mod-workshop .manual-allocator .allocations tbody tr:nth-of-type(odd).highlightreviewerof,
.path-mod-workshop .manual-allocator .allocations tbody tr:nth-of-type(odd).highlightreviewedby{background-color:inherit}.path-mod-workshop .manual-allocator .allocations .peer
.image{margin-right:5px;vertical-align:middle}.path-mod-workshop .manual-allocator .allocations .reviewedby .image,
.path-mod-workshop .manual-allocator .allocations .reviewerof
.image{margin-right:3px;vertical-align:middle}.path-mod-workshop .manual-allocator .allocations .highlightreviewedby .reviewedby,
.path-mod-workshop .manual-allocator .allocations .highlightreviewerof
.reviewerof{background-color:#fff3d2}.path-mod-workshop .manual-allocator .allocations tr
td{vertical-align:top;padding:5px}.path-mod-workshop .manual-allocator .allocations tr td
ul{margin:0px}.path-mod-workshop .manual-allocator .allocations tr td ul
li{list-style:none}.path-mod-workshop .manual-allocator .allocations tr
td.peer{border-left:1px solid #ccc;border-right:1px solid #ccc}.path-mod-workshop .manual-allocator .allocations .reviewedby .info,
.path-mod-workshop .manual-allocator .allocations .peer .info,
.path-mod-workshop .manual-allocator .allocations .reviewerof
.info{font-size:80%;color:#888;font-style:italic}.path-mod-workshop .manual-allocator .allocations .peer
.submission{font-size:90%;margin-top:1em}.path-mod-workshop .random-allocator
.warning{width:100%;margin:0px
auto 15px auto}.accessibilitywarnings
img{max-width:32px;max-height:32px}.atto_backcolor_button .dropdown-menu{min-width:inherit}.atto_charmap_selector
button{width:2em;padding:0
3px}@media (max-width: 768px){.toolbarbreak{display:none}}.atto_emoticon_map
ul{padding:0;margin:0;display:table;width:100%}.atto_emoticon_map
li{display:table-row;white-space:nowrap}.atto_emoticon_map li
div{display:table-cell;padding:0
1em}.atto_equation_library .yui3-tabview-list{border:none}.atto_equation_library .yui3-tab-selected .yui3-tab-label, .yui3-skin-sam #atto_equation_library .yui3-tab-selected .yui3-tab-label:focus, .yui3-skin-sam #atto_equation_library .yui3-tab-selected .yui3-tab-label:hover{background:none;color:black;border-top-left-radius:4px;border-top-right-radius:4px}.atto_equation_library
button{margin:0.25%;min-width:12%}#page-admin-setting-atto_equation_settings .form-defaultinfo{max-height:10em;overflow:auto;padding:5px;min-width:206px}.atto_form
.atto_equation_preview{margin-bottom:0px}.atto_fontcolor_button .dropdown-menu{min-width:inherit}.atto_image_preview{width:100%;height:100%;margin-left:auto;margin-right:auto}.atto_image_preview_box{max-height:200px;margin-bottom:1em;overflow:auto}.editor_atto_content
img{cursor:pointer}.atto_image_size{display:inline-block}.atto_image_size input[type=checkbox]{margin-left:1em;margin-right:1em}.atto_image_size input[type=text]{width:3em}.atto_image_size
label{display:inline-block}#atto_managefiles_manageform
#id_deletefileshdr{display:none}#atto_managefiles_manageform.has-unused-files
#id_deletefileshdr{display:block}#atto_managefiles_manageform
#id_missingfileshdr{display:none}#atto_managefiles_manageform.has-missing-files
#id_missingfileshdr{display:block}div.editor_atto_content td,
div.editor_atto_content th,
div.editor_atto_content
caption{border:1px
dashed #BBB;position:relative;min-width:30px;height:13px}div.editor_atto_content
caption{height:auto}div.availablecolors{max-width:55%;display:inline-block;vertical-align:middle}div.availablecolors label:not(.hideborder){border:1px
solid #ddd}div.availablecolors
label{border-radius:4px;display:inline-block;font-size:0.1em;padding:2px;padding-left:22px}div.availablecolors label input[type="radio"]{float:none;margin:0;margin-left:-15px}input[name="bordersize"],input[name="width"]{margin-right:0.3em}#tinymce_managefiles_manageform.hasunusedfiles
.managefilesstatus{display:none}#tinymce_managefiles_manageform.hasmissingfiles
.managefilesstatus{display:inline}#tinymce_managefiles_manageform
#id_deletefiles{display:none}#tinymce_managefiles_manageform.hasunusedfiles
#id_deletefiles{display:block}#tinymce_managefiles_manageform #id_deletefiles
.felement.fcheckbox{display:none}#tinymce_managefiles_manageform #id_deletefiles
.felement.fcheckbox.isunused{display:block}body{margin:auto 0px;width:auto}#page{width:100%;position:relative}#page-header{float:left;width:100%}#page-content{clear:both;float:left;overflow:hidden;position:relative;width:100%;min-width:900px}#page-content #region-main-box{float:left;left:200px;position:relative;width:200%}#page-content #region-post-box{float:left;left:50%;margin-left:-400px;position:relative;width:100%}#page-content #region-main-wrap{float:right;position:relative;right:100%;width:50%}#page-content #region-main{margin-right:0px;margin-left:400px;overflow:hidden}#page-content #region-pre{float:left;left:200px;overflow:hidden;position:relative;width:200px;margin-left:-50%}#page-content #region-post{float:left;left:0px;overflow:hidden;position:relative;width:200px}#page-content .region-content{padding:10px}#page-footer{clear:both;float:left;width:100%}.side-pre-only #page-content #region-post-box{margin-left:-200px}.side-pre-only #page-content #region-main{margin-left:200px}.side-pre-only #page-content #region-pre{left:0px}.side-pre-only #page-content #region-post{width:0px}.side-post-only #page-content #region-main-box{left:0px}.side-post-only #page-content #region-post-box{margin-left:-200px}.side-post-only #page-content #region-main{margin-left:200px}.side-post-only #page-content #region-pre{width:0px}.has_dock.side-post-only .page-middle #region-main{margin-left:200px}.blocks-moving.side-pre-only #page-content #region-post-box{margin-left:-400px}.blocks-moving.side-pre-only #page-content #region-main{margin-left:400px}.blocks-moving.side-pre-only #page-content #region-pre{left:200px}.blocks-moving.side-pre-only #page-content #region-post{width:200px}.blocks-moving.side-post-only #page-content #region-main-box{left:200px;width:200%}.blocks-moving.side-post-only #page-content #region-post-box{margin-left:-400px}.blocks-moving.side-post-only #page-content #region-main{margin-left:400px}.blocks-moving.side-post-only #page-content #region-pre{left:200px;width:200px}.blocks-moving.side-post-only #page-content #region-post{left:0px;width:200px}.content-only #page-content{min-width:0}.content-only #page-content #region-main-box{left:0px}.content-only #page-content #region-post-box{margin-left:0px}.content-only #page-content #region-main{margin-left:0px}.content-only #page-content #region-pre{left:0;width:0px}.content-only #page-content #region-post{width:0}#region-content.block-region
.header{background-image:none}.ie6 #region-pre .region-content,
.ie6 #region-post .region-content{padding:0
!important;width:100%;float:none}.ie6 #region-pre .region-content .block,
.ie6 #region-post .region-content
.block{width:auto;padding:0;margin:10px}.pagelayout-report
#page{width:auto;position:relative}.pagelayout-report #page-header{float:none}.pagelayout-report #page-content{float:none;overflow:visible;width:auto}.pagelayout-report #report-main-content{float:left;width:100%}.pagelayout-report #report-main-content .region-content{margin-left:200px}.pagelayout-report #report-main-content .region-content
table{background-color:#FFF}.pagelayout-report #report-region-wrap{width:0;float:right;position:relative;left:-100%}.pagelayout-report #report-region-pre{width:200px}.pagelayout-report #page-footer{float:none}.pagelayout-report #page-content .region-content{overflow:visible}.pagelayout-report.content-only #report-main-content .region-content{margin-left:0}.dir-rtl.pagelayout-report #report-main-content .region-content{margin-left:0;margin-right:200px}.dir-rtl.pagelayout-report #report-region-wrap{left:0}.ie6.pagelayout-report #report-main-content{float:none;width:auto}.ie6.pagelayout-report #report-region-wrap{float:none;width:200px;left:auto;position:absolute;top:0}.ie6.pagelayout-report #report-region-pre,
.ie6.pagelayout-report #report-region-pre
.block{width:100%}input[type=text],input[type=password],textarea{width:auto}input[type=checkbox],input[type=radio]{margin-right:7px}strong{font-style:inherit}em{font-weight:inherit}th,
td,
a
img{border-width:0}acronym,abbr{cursor:help}.dir-ltr,
.mdl-left,
.dir-rtl .mdl-right{text-align:left}.dir-rtl,
.mdl-right,
.dir-rtl .mdl-left{text-align:right}#add,#remove,.centerpara,.mdl-align{text-align:center}a.dimmed,
a.dimmed:link,
a.dimmed:visited,
a.dimmed_text,
a.dimmed_text:link,
a.dimmed_text:visited,
.dimmed_text,
.dimmed_text a,
.dimmed_text a:link,
.dimmed_text a:visited,
.usersuspended,
.usersuspended a,
.usersuspended a:link,
.usersuspended a:visited,
.dimmed_category,
.dimmed_category a,
.dimmed_category a:link,
.dimmed_category a:visited{color:#AAA}.activity.label
.dimmed_text{opacity:0.5;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";filter:alpha(opacity=50)}.unlist,
.unlist li,
.inline-list,
.inline-list li,
.block .list,
.block .list li,
.sitetopic .section li.activity,
.course-content .section li.activity,
.sitetopic .section li.movehere,
.course-content .section
li.movehere{list-style:none;margin:0;padding:0}.course-content
.current{background:#E3E3E3}.inline,
.inline-list
li{display:inline}.notifytiny{font-size:0.7em}.notifytiny li,
.notifytiny
td{font-size:100%}.red,.notifyproblem{color:#600}.green,.notifysuccess{color:#060}.reportlink{text-align:right}a.autolink.glossary:hover{cursor:help}.collapsibleregioncaption{white-space:nowrap}.pagelayout-mydashboard.jsenabled
.collapsibleregioncaption{cursor:pointer}.collapsibleregioncaption
img{vertical-align:middle}.jsenabled
.hiddenifjs{display:none}.visibleifjs{display:none}.jsenabled
.visibleifjs{display:inline}.jsenabled
.collapsibleregion{overflow:hidden}.jsenabled .collapsed
.collapsibleregioninner{visibility:hidden}.yui-overlay .yui-widget-bd{background-color:#FFEE69;border:1px
solid #A6982B;border-top-color:#D4C237;color:#000;left:0;padding:2px
5px;position:relative;top:0;z-index:1}.clearer{background:transparent;border-width:0;clear:both;display:block;height:1px;margin:0;padding:0}.clearfix:after{clear:both;content:".";display:block;height:0;min-width:0;visibility:hidden}.bold,
.warning,
.errorbox .title,
.pagingbar .title,
.pagingbar .thispage,
#site-news-forum h2,
#frontpage-course-list h2,
#frontpage-category-names h2,
#frontpage-category-combo
h2{font-weight:bold}img.resize{height:1em;width:1em}.block img.resize,
.breadcrumb
img.resize{height:0.9em;width:0.8em}img.icon{height:16px;vertical-align:text-bottom;width:16px;padding-right:6px}.dir-rtl
img.icon{padding-left:6px;padding-right:0}img.iconsmall{height:12px;margin-right:3px;margin-left:3px;vertical-align:middle;width:12px}img.iconhelp, .helplink
img{height:16px;padding-left:3px;vertical-align:text-bottom;width:16px}.dir-rtl img.iconhelp, .dir-rtl .helplink
img{padding-right:3px;padding-left:0}img.iconlarge{height:24px;width:24px;vertical-align:middle}img.iconsort{vertical-align:text-bottom;padding-left: .3em;margin-bottom: .15em}.dir-rtl
img.iconsort{padding-right: .3em;padding-left:0}img.icontoggle{height:17px;vertical-align:middle;width:50px}img.iconkbhelp{height:17px;width:49px}img.icon-pre, .dir-rtl img.icon-post{padding-right:3px;padding-left:0}img.icon-post, .dir-rtl img.icon-pre{padding-left:3px;padding-right:0}.generalbox{border:1px
solid}.boxaligncenter{margin-left:auto;margin-right:auto}.boxalignright{margin-left:auto;margin-right:0}.boxalignleft{margin-left:0;margin-right:auto}.boxwidthnarrow{width:30%}.boxwidthnormal{width:50%}.boxwidthwide{width:80%}.buttons .singlebutton,
.buttons .singlebutton form,
.buttons .singlebutton
div{display:inline}.buttons .singlebutton
input{margin:20px
5px}.headermain{font-weight:bold}#maincontent{display:block;height:1px;overflow:hidden}img.uihint{cursor:help}#addmembersform
table{margin-left:auto;margin-right:auto}.formtable tbody th,
.generaltable
th.header{vertical-align:top}.cell{vertical-align:top}img.emoticon{vertical-align:middle;width:15px;height:15px}form.popupform,
form.popupform
div{display:inline}.arrow_button
input{overflow:hidden}.action-icon
img.smallicon{vertical-align:text-bottom;margin-left: .45em}.dir-rtl .action-icon
img.smallicon{margin-right: .45em;margin-left:0}h1 img.icon,
h1 img.iconhelp,
h2 img.icon,
h2 img.iconhelp,
h3 img.icon,
h3 img.iconhelp,
h4 img.icon,
h4 img.iconhelp,
h5 img.icon,
h5 img.iconhelp,
h6 img.icon,
h6
img.iconhelp{vertical-align:middle;padding:4px}table
caption{font-size:24px;font-weight:bold;line-height:42px;text-align:left}.dir-rtl table
caption{text-align:right}.no-overflow{overflow:auto;padding-bottom:1px}.pagelayout-report .no-overflow{overflow:visible}.no-overflow>.generaltable{margin-bottom:0}.ie6 .no-overflow{width:100%}.ie6
li.section{line-height:1.2em;width:100%}.accesshide{position:absolute;left:-10000px;font-weight:normal;font-size:1em}.dir-rtl
.accesshide{top:-30000px;left:auto}span.hide,div.hide{display:none}.invisiblefieldset{display:inline;border-width:0;padding:0;margin:0}a.skip-block,a.skip{position:absolute;top:-1000em;font-size:0.85em;text-decoration:none}a.skip-block:focus,a.skip-block:active,a.skip:focus,a.skip:active{position:static;display:block}.skip-block-to{display:block;height:1px;overflow:hidden}.arrow,
.arrow_button
input{font-family:Arial,Helvetica,Courier,sans-serif}.headermain{float:left;margin:15px;font-size:2.3em}.headermenu{float:right;margin:10px;font-size:0.8em;text-align:right}#course-header{clear:both}.usermenu{}.usermenu .moodle-actionmenu{}.usermenu .moodle-actionmenu .toggle-display{display:block;opacity:1;height:40px;line-height:40px;padding:6px;color:inherit}.usermenu .moodle-actionmenu .toggle-display
.userbutton{height:40px;line-height:40px}.usermenu .moodle-actionmenu .toggle-display .userbutton
.avatars{display:inline-block;height:36px;width:36px;vertical-align:middle;margin-right:6px;margin-left:6px}.usermenu .moodle-actionmenu .toggle-display .userbutton .avatars .avatar,
.usermenu .moodle-actionmenu .toggle-display .userbutton .avatars
img{display:block}.usermenu .moodle-actionmenu .toggle-display .userbutton
.usertext{display:inline-block;vertical-align:middle;font-size:14px;line-height:1em;color:#777}.usermenu .moodle-actionmenu:hover .toggle-display .userbutton
.usertext{color:#000}.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext .meta,
.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext
.role{display:block;font-size:12px}.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext .meta .value,
.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext .role
.value{font-weight:bold}.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext
.role{font-weight:bold}.usermenu .moodle-actionmenu .toggle-display
.caret{display:none}.usermenu .moodle-actionmenu .menu .menu-action.icon
img{border-radius:0;background:transparent;box-shadow:none}.usermenu .moodle-actionmenu .menu .menu-action.icon:hover
img{background:#fff;border-radius:2px;box-shadow:0px 0px 16px rgba(0, 0, 0, 0.25)}.usermenu .moodle-actionmenu[data-enhanced] .menu .menu-action.icon img,
.usermenu .moodle-actionmenu[data-enhanced] .menu .menu-action.icon:hover
img{border-radius:0;background:transparent;box-shadow:none}.userloggedinas .usermenu .userbutton .avatars
.avatar{overflow:hidden}.userloggedinas .usermenu .userbutton .avatars .avatar
img{width:inherit;height:inherit}.userloggedinas .usermenu .userbutton .avatars
.avatar.current{position:relative;top:4px;left:4px;width:20px;height:20px;margin-top:11px;margin-bottom:-34px;border:1px
solid #fff;border-radius:50%;box-shadow:-2px -2px 16px rgba(0, 0, 0, 0.25)}.jsenabled .usermenu .moodle-actionmenu .toggle-display{display:block}.jsenabled .usermenu .moodle-actionmenu .toggle-display
.caret{display:inline-block;position:relative;top:9px}.jsenabled .usermenu .moodle-actionmenu>.menubar{display:block;margin:0px}.jsenabled .usermenu .moodle-actionmenu>.menu{min-width:160px;font-size:14px}.jsenabled .usermenu .moodle-actionmenu > .menu
.filler{display:block;height:1px;margin:9px
1px;overflow:hidden;background-color:#e5e5e5;border-bottom:1px solid #fff}.jsenabled .usermenu .moodle-actionmenu.show
.menu{padding:5px
0;margin:2px
0 0;background-clip:padding-box}.jsenabled .usermenu .moodle-actionmenu.show .menu:before{content:'';display:inline-block;border-left:7px solid transparent;border-right:7px solid transparent;border-bottom:7px solid #ccc;border-bottom-color:rgba(0,0,0,.2);position:absolute;top:-7px}.jsenabled .usermenu .moodle-actionmenu.show .menu:after{content:'';display:inline-block;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:6px solid #fff;position:absolute;top:-6px}.jsenabled .usermenu .moodle-actionmenu.show .menu li
a{white-space:nowrap;border-radius:0}.jsenabled .usermenu .moodle-actionmenu.show .menu a:focus,
.jsenabled .usermenu .moodle-actionmenu.show .menu a:hover{text-decoration:none}.dir-ltr
.usermenu{float:right}.dir-ltr .usermenu>.moodle-actionmenu>.menu:before{right:9px}.dir-ltr .usermenu>.moodle-actionmenu>.menu:after{right:10px}.dir-ltr .usermenu > .moodle-actionmenu > .menubar li
a{text-align:right}.dir-ltr.userloggedinas .usermenu .userbutton .avatars
.avatar.current{left:16px}.dir-rtl
.usermenu{float:left}.dir-rtl .usermenu>.moodle-actionmenu>.menu{margin-right:0px}.dir-rtl .usermenu>.moodle-actionmenu>.menu:before{left:9px}.dir-rtl .usermenu>.moodle-actionmenu>.menu:after{left:10px}.dir-rtl .usermenu > .moodle-actionmenu > .menubar li
a{text-align:left}.dir-rtl.userloggedinas .usermenu .userbutton .avatars
.avatar.current{left:-14px}.navbar{clear:both;overflow:hidden}.ie6
.navbar{overflow:hidden;height:100%}.breadcrumb{float:left}.navbutton{text-align:right}.breadcrumb
ul{padding:0;margin:0;text-indent:0;list-style:none}.navbutton{float:right}.navbutton
.singlebutton{margin-left:4px}.breadcrumb li,
.navbutton div,
.navbutton
form{display:inline}#page-footer{text-align:center;font-size:0.9em}#page-footer
.homelink{margin:1em
0}#page-footer .homelink
a{padding-left:1em;padding-right:1em}#page-footer .logininfo,
#page-footer .sitelink,
#page-footer
.helplink{margin:0px
10px}#page-footer
.performanceinfo{text-align:center;margin:10px
20%}#page-footer .performanceinfo
span{display:block}#page-footer
.validators{margin-top:40px;padding-top:5px;border-top:1px dotted gray}#page-footer .validators
ul{margin:0px;padding:0px;list-style-type:none}#page-footer .validators ul
li{display:inline;margin-right:10px;margin-left:10px}#page-footer .performanceinfo
.cachesused{margin-top:1em}#page-footer .performanceinfo .cachesused .cache-stats-heading{font-weight:bold;display:block}#page-footer .performanceinfo .cachesused .cache-definition-stats{margin:0.3em;padding:0px;border:1px
solid #999;display:inline-block;vertical-align:top;min-height:4em;color:#000;background-color:#eee}#page-footer .performanceinfo .cachesused .cache-definition-stats
span{padding-left:0.5em;padding-right:0.5em;display:block}#page-footer .performanceinfo .cachesused .cache-definition-stats .cache-definition-stats-heading{background-color:#eee}#page-footer .performanceinfo .cachesused .cache-store-stats{text-indent:1em}#page-footer .performanceinfo .cachesused .cache-store-stats.nohits{background-color:#ffd3d9}#page-footer .performanceinfo .cachesused .cache-store-stats.lowhits{background-color:#f3f2aa}#page-footer .performanceinfo .cachesused .cache-store-stats.hihits{background-color:#e7f1c3}#page-footer .performanceinfo .cachesused .cache-total-stats{display:block;font-weight:bold;margin-top:0.3em}#course-footer{clear:both}.tabtree{position:relative;margin-bottom:3.5em}.tabtree
li{display:inline}.tabtree
ul{margin:5px}.tabtree ul li.here
ul{position:absolute;top:100%;width:100%}.tabtree ul li.here
.empty{display:none}.mform
fieldset{border:1px
solid}.mform fieldset
fieldset{border-width:0}.mform fieldset
legend{font-weight:bold;margin-left:0.5em;padding:0
0.35em}.mform fieldset
div{margin:10px;margin-top:0}.mform fieldset div
div{margin:0}.mform fieldset
.advancedbutton{text-align:right}.mform
fieldset.hidden{border-width:0}.mform
fieldset.group{margin-bottom:0}.mform
fieldset.error{border:1px
solid #A00}.collapsible-actions{display:none}.jsenabled .collapsible-actions{text-align:right;display:block}.dir-rtl .collapsible-actions{text-align:left}.collapseexpand{background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed) left center no-repeat;padding-left:18px}.dir-rtl
.collapseexpand{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_rtl);background-position:right center;padding-left:0;padding-right:18px}.collapse-all,
.dir-rtl .collapse-all{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/expanded)}.mform fieldset
legend{padding:0
0.35em}.mform fieldset.collapsible legend
a.fheader{padding-left:18px;background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/expanded) left center no-repeat}.mform fieldset.collapsed legend
a.fheader{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed)}.jsenabled .mform
fieldset.collapsed{border-width:1px 0 0 1px;padding:0;border-color:transparent}.jsenabled .mform fieldset.collapsed
div.fcontainer{display:none}.mform
.fitem{width:100%;overflow:hidden;margin-top:5px;margin-bottom:1px;clear:right}.jsenabled .mform .containsadvancedelements
.advanced{display:none}.mform .containsadvancedelements
.advanced.show{display:block}.mform .fitem
.fitemtitle{width:15%;text-align:right;float:left}.dir-rtl .mform .fitem
.fitemtitle{text-align:left}.mform .fitem .fitemtitle
div{display:inline}.mform .fitem
.felement{border-width:0;width:80%;margin-left:16%}.mform .fitem
fieldset.felement{margin-left:15%;padding-left:1%;margin-bottom:0}#adminsettings span.error,
.mform .error,
.mform
.required{color:#A00}#adminsettings span.error,
.mform
span.error{display:inline-block;padding:4px;margin-bottom:4px;background-color:#F2DEDE;border:1px
solid #EED3D7}.mform .required .fgroup span
label{color:#000}.mform
.fdescription.required{color:#A00;text-align:right}.dir-rtl .mform
.fdescription.required{text-align:left}.mform .fpassword
.unmask{display:inline;margin-left:0.5em}.mform .ftextarea
#id_alltext{width:100%}.mform
.fstaticlabel{font-weight:bold}.mform ul.file-list{padding:0;margin:0;list-style:none}.mform
label{display:inline-block}.mform
.iconhelp{margin-left:4px}.dir-rtl .mform
.iconhelp{margin-right:4px}.mform label .req,
.mform label
.adv{cursor:help}.mform .fcheckbox
input{margin-left:0}.mform .fcheckbox label,
.mform .fduration label,
.mform .fitem fieldset.fgroup label,
.mform .fradio label,
.mform fieldset.fdate_selector label,
.mform fieldset.fdate_time_selector
label{display:inline;float:none;margin-left: .3em;vertical-align:text-bottom}.dir-rtl .mform .fcheckbox label,
.dir-rtl .mform .fduration label,
.dir-rtl .mform .fitem fieldset.fgroup label,
.dir-rtl .mform .fradio label,
.dir-rtl .mform fieldset.fdate_selector label,
.dir-rtl .mform fieldset.fdate_time_selector
label{margin-right: .3em;margin-left:0}.mform .ftags
label.accesshide{display:block;position:static}.mform .ftags
select{margin-bottom:0.7em;min-width:22em}.mform .moreless-toggler{background:url(/sunguru/theme/image.php/archaius/core/1531975376/t/more) left center no-repeat;padding-left:16px}.dir-rtl .moreless-toggler{padding-left:0;padding-right:16px;background-position:right center}.mform .moreless-less{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/less)}.mform .helplink
img{margin:0
0 0 .45em;padding:0}.dir-rtl .mform .helplink
img{margin:0
.45em 0 0;padding:0}.mform legend .helplink
img{margin-right: .2em}.dir-rtl .mform legend .helplink
img{margin:0
.45em 0 .2em}.urlselect label,
.singleselect
label{margin-right: .3em}.dir-rtl .urlselect label,
.dir-rtl .singleselect
label{margin-left: .3em;margin-right:0}.dir-rtl .mform fieldset
legend{margin-right:0.5em;margin-left:0}.dir-rtl .mform fieldset.collapsible legend
a.fheader{background-position:right center;padding-right:18px;padding-left:0}.dir-rtl .mform fieldset.collapsed legend
a.fheader{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_rtl)}.dir-rtl.jsenabled .mform
fieldset.collapsed{border-width:1px 1px 0 0}.dir-rtl .mform .fitem
fieldset.felement{padding-right:1%;margin-right:15%}.mform .btn-cancel, .mform .btn-cancel:active, .mform .btn-cancel[disabled]{background-color:transparent;background-image:none;box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none;-o-box-shadow:none;-ms-box-shadow:none;margin-left: .5em}.mform .btn-cancel{border-color:transparent;border-radius:0 0 0 0;-moz-border-radius:0 0 0 0;-webkit-border-radius:0 0 0 0;-o-border-radius:0 0 0 0;-ms-border-radius:0 0 0 0;color:#08C;cursor:pointer}.mform .btn-cancel:hover, .mform .btn-cancel:focus{background-color:transparent;color:#005580;text-decoration:underline}.mform .btn-cancel[disabled]:hover, .mform .btn-cancel[disabled]:focus{color:#333;text-decoration:none}input#id_externalurl{direction:ltr}#portfolio-add-button{display:inline}#region-main .mform:not(.unresponsive) .fitem .fitemtitle
label{font-weight:bold}@media (max-width: 1199px){#region-main .mform:not(.unresponsive) .fitem
.fitemtitle{display:block;margin-top:4px;margin-bottom:4px;text-align:left;width:100%}#region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:8px}.dir-rtl #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{margin-right:0px;margin-left:8px}.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{text-align:right}#region-main .mform:not(.unresponsive) .fitem
.felement{margin-left:0;width:100%;float:left;margin-bottom:6px;padding-left:0;padding-right:0}#region-main .mform:not(.unresponsive) .fitem .fstatic:empty{display:none}#region-main .mform:not(.unresponsive) .femptylabel
.felement{display:inline-block;margin-top:4px;width:auto}.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.felement{margin-right:0;float:right;padding-right:0;padding-left:0}#region-main .mform:not(.unresponsive) .fitem_fcheckbox .fitemtitle,
#region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{display:inline-block;width:auto}.dir-rtl #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{float:right}#region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{padding:6px}}.phpinfo
.center{text-align:center}.phpinfo .center
table{margin-left:auto;margin-right:auto;text-align:left;border-collapse:collapse}.phpinfo .center
th{text-align:center}.phpinfo .e,
.phpinfo .v,
.phpinfo
.h{border:1px
solid #000;font-size:0.8em;vertical-align:baseline;color:#000;background-color:#ccc}.phpinfo
.e{background-color:#ccf;font-weight:bold}.phpinfo
.h{background-color:#99c;font-weight:bold}.addbloglink{text-align:center}.blog_entry
.audience{text-align:right;padding-right:4px}.blog_entry
.tags{margin-top:15px}.blog_entry .tags .action-icon
img.smallicon{height:16px;width:16px}.blog_entry
.content{margin-left:43px}#page-group-index
#groupeditform{text-align:center}#doc-contents
h1{margin:1em
0 0 0}#doc-contents
ul{margin:0;padding:0;width:90%}#doc-contents ul
li{list-style-type:none}.groupmanagementtable
td{vertical-align:top}.groupmanagementtable #existingcell,
.groupmanagementtable
#potentialcell{width:42%}.groupmanagementtable
#buttonscell{width:16%}.groupmanagementtable #buttonscell
input{width:80%}.groupmanagementtable #buttonscell p.arrow_button
input{width:auto;min-width:80%;margin:0
auto}.groupmanagementtable #removeselect_wrapper,
.groupmanagementtable
#addselect_wrapper{width:100%}.groupmanagementtable #removeselect_wrapper label,
.groupmanagementtable #addselect_wrapper
label{font-weight:normal}.dir-rtl .groupmanagementtable
p{text-align:right}#group-usersummary{width:14em}.groupselector{margin-top:3px;margin-bottom:3px;display:inline-block}.loginbox{margin:15px;overflow:visible}.loginbox.twocolumns{margin:15px}.loginbox h2,
.loginbox
.subcontent{margin:5px;padding:10px;text-align:center}.loginbox .loginpanel
.desc{margin:0;padding:0;margin-bottom:5px;margin-top:15px}.loginbox .signuppanel
.subcontent{text-align:left}.dir-rtl .loginbox .signuppanel
.subcontent{text-align:right}.loginbox
.loginsub{margin-left:0;margin-right:0}.loginbox .guestsub,
.loginbox .forgotsub,
.loginbox
.potentialidps{margin:5px
12%}.loginbox .potentialidps
.potentialidplist{margin-left:40%}.loginbox .potentialidps .potentialidplist
div{text-align:left}.loginbox
.loginform{margin-top:1em;text-align:left}.loginbox .loginform .form-label{float:left;text-align:right;width:49%;white-space:nowrap}.loginbox .loginform .form-input{float:right;width:50%}.dir-rtl .loginbox .loginform .form-input{margin-right:1%}.loginbox .loginform .form-input
input{width:6em}.loginbox
.signupform{margin-top:1em;text-align:center}.loginbox.twocolumns
.loginpanel{float:left;width:49.5%;border-right:1px solid;margin-bottom:-2000px;padding-bottom:2000px}.loginbox.twocolumns
.signuppanel{float:right;width:50%;margin-bottom:-2000px;padding-bottom:2000px}.loginbox .potentialidp
.smallicon{vertical-align:text-bottom;margin:0
.3em}.dir-rtl .loginbox.twocolumns .loginpanel, .dir-rtl.loginbox.twocolumns
.signuppanel{float:right}.notepost{margin-bottom:1em}.notepost
.userpicture{float:left;margin-right:5px}.notepost .content,
.notepost
.footer{clear:both}.notesgroup{margin-left:20px}.path-my .coursebox
.overview{margin:15px
30px 10px 30px}.path-my .coursebox
.info{float:none;margin:0}.logtable
th{text-align:left}.mod_introbox{border:1px
solid;padding:10px}table.mod_index{width:100%}.comment-ctrl{font-size:12px;display:none;margin:0;padding:0}.comment-ctrl
h5{margin:0;padding:5px}.comment-area{max-width:400px;padding:5px}.comment-area
textarea{width:100%;overflow:auto}.comment-area
textarea.fullwidth{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.comment-area
.fd{text-align:right}.comment-meta
span{color:gray}.comment-link
img{vertical-align:text-bottom}.comment-list{font-size:11px;overflow:auto;list-style:none;padding:0;margin:0}.comment-list
li{margin:2px;list-style:none;margin-bottom:5px;clear:both;padding: .3em;position:relative}.comment-list
li.first{display:none}.comment-paging{text-align:center}.comment-paging
.pageno{padding:2px}.comment-paging
.curpage{border:1px
solid #CCC}.comment-message
.picture{width:20px;float:left}.dir-rtl .comment-message
.picture{float:right}.comment-message
.text{margin:0;padding:0}.comment-message .text
p{padding:0;margin:0
18px 0 0}.comment-delete{position:absolute;top:0;right:0;margin: .3em}.dir-rtl .comment-delete{position:absolute;left:0;right:auto;margin: .3em}.comment-delete-confirm{background:#eee;padding:2px;width:5em;text-align:center}.comment-container{float:left;margin:4px}.comment-report-selectall{display:none}.comment-link{display:none}.jsenabled .comment-link{display:block}.jsenabled
.showcommentsnonjs{display:none}.jsenabled .comment-report-selectall{display:inline}.completion-expired{background:#FDD}.completion-expected{font-size:0.75em}.completion-sortchoice,.completion-identifyfield{font-size:0.75em;vertical-align:bottom}.completion-progresscell{text-align:right}.completion-expired .completion-expected{font-weight:bold}#tag-management-box{margin-bottom:10px;line-height:20px}img.user-image{height:100px;width:100px}#tag-search-box{text-align:center;margin:10px
auto}.tagarea{clear:both;overflow:hidden}.tagarea
.controls{text-align:center}.tagarea .controls
.gotopage.nextpage{float:right}.tagarea .controls
.gotopage.prevpage{float:left}.tagarea .controls
.exclusivemode{display:inline-block}.dir-rtl .tagarea .controls
.gotopage.nextpage{float:left}.dir-rtl .tagarea .controls
.gotopage.prevpage{float:right}.tagarea .controls.controls-bottom{margin-top:5px}span.flagged-tag,
tr.flagged-tag,
span.flagged-tag a,
tr.flagged-tag
a{color:#F00}.tag-management-table td,
.tag-management-table
th{vertical-align:middle;padding:4px}.tag-management-table .inplaceeditable.inplaceeditingon
input{width:150px}.tag_feed .media, .tag_feed .media-body{overflow:hidden}.tag_feed.media-list .media
.itemimage{float:left}.dir-rtl .tag_feed.media-list .media
.itemimage{float:right}.tag_feed.media-list .media .itemimage
img{height:35px;width:35px}.tag_feed.media-list .media .media-body{padding-right:10px;padding-left:10px}.tag_cloud{text-align:center}.tag_cloud .inline-list
li{padding:0px
0.2em}.tag_cloud
.tag_overflow{margin-top:1em;font-style:italic}.tag_cloud
.s20{font-size:2.7em}.tag_cloud
.s19{font-size:2.6em}.tag_cloud
.s18{font-size:2.5em}.tag_cloud
.s17{font-size:2.4em}.tag_cloud
.s16{font-size:2.3em}.tag_cloud
.s15{font-size:2.2em}.tag_cloud
.s14{font-size:2.1em}.tag_cloud
.s13{font-size:2em}.tag_cloud
.s12{font-size:1.9em}.tag_cloud
.s11{font-size:1.8em}.tag_cloud
.s10{font-size:1.7em}.tag_cloud
.s9{font-size:1.6em}.tag_cloud
.s8{font-size:1.5em}.tag_cloud
.s7{font-size:1.4em}.tag_cloud
.s6{font-size:1.3em}.tag_cloud
.s5{font-size:1.2em}.tag_cloud
.s4{font-size:1.1em}.tag_cloud
.s3{font-size:1em}.tag_cloud
.s2{font-size:0.9em}.tag_cloud
.s1{font-size:0.8em}.tag_cloud
.s0{font-size:0.7em}.path-backup .mform
.grouped_settings.section_level{clear:both}.path-backup .mform
.grouped_settings{clear:both;overflow:hidden}.path-backup .mform .grouped_settings .fitem
.fitemtitle{width:40%;padding-right:10px}.path-backup.dir-rtl .mform .grouped_settings .fitem
.fitemtitle{width:60%}.path-backup .mform .grouped_settings .fitem
.felement{width:50%}.path-backup .mform .grouped_settings .fitem.backup_selector
.felement{width:100%}.path-backup.dir-rtl .mform .grouped_settings .fitem
.felement{width:99%}.path-backup .mform .grouped_settings.section_level
.include_setting{width:50%;margin:0;float:left;clear:left;font-weight:bold}.path-backup.dir-rtl  .mform .grouped_settings.section_level
.include_setting{float:right;clear:right}.path-backup .mform .grouped_settings.section_level
.normal_setting{width:50%;margin:0;margin-left:50%}.path-backup.dir-rtl  .mform .grouped_settings.section_level
.normal_setting{margin:0}.path-backup .mform .grouped_settings.activity_level .include_setting
label{font-weight:normal}.path-backup.dir-rtl .mform .grouped_settings.activity_level .include_setting label
img{float:right}.path-backup .mform .fitem
fieldset.felement{margin-left:0;width:auto;padding-left:0}.path-backup
.notification.dependencies_enforced{text-align:center;color:#A00;font-weight:bold}.path-backup
.backup_progress{text-align:center}.path-backup .backup_progress
span.backup_stage{color:#999}.path-backup .backup_progress
.backup_stage.backup_stage_current{font-weight:bold;color:inherit}.path-backup .backup_progress
.backup_stage.backup_stage_next{}.path-backup .backup_progress
span.backup_stage.backup_stage_complete{color:inherit}#page-backup-restore
.filealiasesfailures{background-color:#ffd3d9}#page-backup-restore .filealiasesfailures
.aliaseslist{width:90%;margin:0.8em auto;background-color:white;border:1px
dotted #666}.path-backup .fitemtitle .iconlarge.icon-post{padding-left:6px}.path-backup.dir-rtl .fitemtitle .iconlarge.icon-post{padding-right:6px;padding-right:0}.path-backup .fitem
.smallicon{vertical-align:text-bottom}.path-backup
.wibbler{width:500px;margin:0
auto 10px;border-bottom:1px solid black;border-right:1px solid black;border-left:1px solid black;position:relative;min-height:4px}.path-backup .wibbler
.wibble{position:absolute;left:0;right:0;top:0;height:4px}.path-backup .wibbler
.state0{background:#eee}.path-backup .wibbler
.state1{background:#ddd}.path-backup .wibbler
.state2{background:#ccc}.path-backup .wibbler
.state3{background:#bbb}.path-backup .wibbler
.state4{background:#aaa}.path-backup .wibbler
.state5{background:#999}.path-backup .wibbler
.state6{background:#888}.path-backup .wibbler
.state7{background:#777}.path-backup .wibbler
.state8{background:#666}.path-backup .wibbler
.state9{background:#555}.path-backup .wibbler
.state10{background:#444}.path-backup .wibbler
.state11{background:#333}.path-backup .wibbler
.state12{background:#222}.path-backup
.backup_log{margin-top:2em}.path-backup .backup_log
h2{font-size:1em}.path-backup
.backup_log_contents{border:1px
solid #ddd;padding:10px;height:300px;overflow-y:scroll}#fitem_id_availabilityconditionsjson
.label{background:#999;padding:2px
4px;border-radius:4px;font-size:0.8em;font-weight:bold;color:#fff}#fitem_id_availabilityconditionsjson .label-warning{background:#f89406;position:relative;top:-1px}#fitem_id_availabilityconditionsjson .label:empty{display:none}#fitem_id_availabilityconditionsjson *[aria-hidden=true]{display:none}x#fitem_id_availabilityconditionsjson select,
x#fitem_id_availabilityconditionsjson input[type=text]{position:relative;top:4px}#fitem_id_availabilityconditionsjson
label{display:inline}#fitem_id_availabilityconditionsjson .availability-group{margin-right:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-group{margin-right:0;margin-left:8px}#fitem_id_availabilityconditionsjson .availability-item,
#fitem_id_availabilityconditionsjson .availability-header{margin-bottom:6px}#fitem_id_availabilityconditionsjson .availability-none{margin-left:20px;margin-bottom:4px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-none{margin-right:20px;margin-left:0}#fitem_id_availabilityconditionsjson .availability-plugincontrols{padding:4px
0px 4px 4px;background:none repeat scroll 0% 0% #eee;border:1px
solid #ddd;border-radius:4px;display:inline-block;margin-right:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-plugincontrols{padding-right:4px;padding-left:0px;margin-right:0;margin-left:8px}#fitem_id_availabilityconditionsjson .availability-eye,
#fitem_id_availabilityconditionsjson .availability-delete{margin-right:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-eye,
.dir-rtl #fitem_id_availabilityconditionsjson .availability-delete{margin-left:8px;margin-right:0}#fitem_id_availabilityconditionsjson .availability-eye[aria-hidden=true]{display:inline;visibility:hidden}#fitem_id_availabilityconditionsjson .availability-list > .availability-eye
img{vertical-align:top;margin-top:12px}#fitem_id_availabilityconditionsjson .availability-button{margin-left:15px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-button{margin-right:15px;margin-left:0}#fitem_id_availabilityconditionsjson .availability-childlist>.availability-inner{display:inline-block;background:#eee;border:1px
solid #ddd;border-radius:4px;padding:6px;margin-bottom:6px}#fitem_id_availabilityconditionsjson .availability-childlist .availability-childlist>.availability-inner{background:white}#fitem_id_availabilityconditionsjson .availability-connector{margin-left:20px;margin-bottom:6px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-connector{margin-right:20px;margin-left:0}.mform .error .availability-field{color:black}.availability-dialogue.moodle-dialogue-base .moodle-dialogue .moodle-dialogue-bd{padding-left:0;padding-right:0;padding-bottom:2px}.availability-dialogue
ul{display:block;margin:0}.availability-dialogue
li{display:block;list-style-type:none;padding:0
0 4px;clear:both;border-bottom:1px solid #eee;margin-bottom:4px}.availability-dialogue ul
button{float:left;margin-left:1em;min-width:140px;margin-top:4px}.dir-rtl .availability-dialogue ul
button{float:right;margin-right:1em;margin-left:0}.availability-dialogue
label{margin-left:170px;margin-right:1em;margin-bottom:0;display:block;line-height:1.5}.dir-rtl .availability-dialogue
label{margin-right:170px;margin-left:1em}.availability-dialogue .availability-buttons
button{margin-left:1em;margin-right:1em;margin-top:4px}#webservice-doc-generator
td{text-align:left;border:0px
solid black}#custommenu{clear:both}#custommenu .yui3-menu .yui3-menu{z-index:500}#custommenu .yui3-menu-horizontal.javascript-disabled .yui3-menu-content,
#custommenu .yui3-menu-horizontal.javascript-disabled .yui3-menu-content
.ul{border:1px
solid #000}#custommenu .yui3-menu-horizontal.javascript-disabled
ul{margin:0;padding:0}#custommenu .yui3-menu-horizontal.javascript-disabled
li{margin:0;padding:0;list-style:none;width:auto;position:relative}#custommenu .yui3-menu-horizontal.javascript-disabled .yui3-menu .yui3-menu-label{padding-right:20px}#custommenu .yui3-menu-horizontal.javascript-disabled>.yui3-menu-content>ul>li{float:left}#custommenu .yui3-menu-horizontal.javascript-disabled li
a{padding:0
10px}#custommenu .yui3-menu-horizontal.javascript-disabled .yui3-menu{position:absolute;top:-10000px;left:-10000px;visibility:hidden;white-space:nowrap;max-width:250px;background-color:#FFF}#custommenu .yui3-menu-horizontal.javascript-disabled li:hover>.yui3-menu{top:100%;left:0;visibility:visible;z-index:10}#custommenu .yui3-menu-horizontal.javascript-disabled li:hover .yui3-menu .yui3-menu{top:0;left:100%;min-width:200px}#custommenu .yui3-menu-horizontal.javascript-disabled>.yui3-menu-content>ul:after{content:"";display:block;clear:both;line-height:0;font-size:0;visibility:hidden}#custommenu .yui3-menu-horizontal.javascript-disabled .yui3-menu-content{font-size:93%;line-height:2;padding:0}#custommenu .yui3-menu-horizontal.javascript-disabled .yui3-menu-content .yui3-menu-content{font-size:100%}#custommenu .yui3-menu-label,
#custommenu .yui3-menuitem-content{cursor:pointer}#custommenu .yui3-menuitem-active{background-color:#B3D4FF}#custommenu .yui3-menuitem-active,
#custommenu .yui3-menuitem-active .yui3-menuitem-content,
#custommenu .yui3-menu-horizontal .yui3-menu-label,
#custommenu .yui3-menu-horizontal .yui3-menu-content{background-image:none;background-position:right center;background-repeat:no-repeat}#custommenu .yui3-menu-label,
#custommenu .yui3-menu .yui3-menu .yui3-menu-label{background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/vertical-menu-submenu-indicator);padding-right:20px}#custommenu .yui3-menu .yui3-menu .yui3-menu-label-menuvisible{background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/horizontal-menu-submenu-indicator)}.yui3-menu.yui3-menu-horizontal .yui3-menuitem.divider{overflow:hidden;width:0;height:24px;border-left:1px solid #ddd}.yui3-menu .yui3-menu .yui3-menuitem.divider{width:auto;height:0;margin:4px
1px;border-left:0px none;border-top:1px solid #ddd}.yui3-menu .yui3-menuitem.divider
a{visibility:invisible}.smartselect{position:absolute}.smartselect
.smartselect_mask{background-color:#fff}.smartselect
ul{padding:0;margin:0}.smartselect ul
li{list-style:none}.smartselect
.smartselect_menu{margin-right:5px}.safari .smartselect
.smartselect_menu{margin-left:2px}.smartselect .smartselect_menu,
.smartselect
.smartselect_submenu{border:1px
solid #000;background-color:#FFF;display:none}.smartselect .smartselect_menu.visible,
.smartselect
.smartselect_submenu.visible{display:block}.smartselect .smartselect_menu_content ul
li{position:relative;padding:2px
5px}.smartselect .smartselect_menu_content ul li
a{color:#333;text-decoration:none}.smartselect .smartselect_menu_content ul li
a.selectable{color:inherit}.smartselect
.smartselect_submenuitem{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed);background-repeat:no-repeat;background-position:100%}.smartselect.spanningmenu
.smartselect_submenu{position:absolute;top:-1px;left:100%}.smartselect.spanningmenu .smartselect_submenu
a{white-space:nowrap;padding-right:16px}.smartselect.spanningmenu .smartselect_menu_content ul li a.selectable:hover{text-decoration:underline}.smartselect.compactmenu
.smartselect_submenu{position:relative;margin:2px
-3px;margin-left:10px;display:none;border-width:0;z-index:1010}.smartselect.compactmenu
.smartselect_submenu.visible{display:block}.smartselect.compactmenu
.smartselect_menu{z-index:1000;overflow:hidden}.smartselect.compactmenu .smartselect_submenu
.smartselect_submenu{z-index:1020}.smartselect.compactmenu .smartselect_submenuitem:hover>.smartselect_menuitem_label{font-weight:bold}#page-admin-registration-register
.registration_textfield{width:300px}.userenrolment{width:100%;border-collapse:collapse}.userenrolment
tr{vertical-align:top}.userenrolment
td{height:41px;padding:3px}.userenrolment td>*{margin:3px}.userenrolment
.subfield{margin-right:5px}.userenrolment .col_userdetails
.subfield_picture{float:left}.userenrolment
.col_lastseen{width:150px}.userenrolment
.col_role{width:262px}.userenrolment .col_role .roles,
.userenrolment .col_group
.groups{margin-right:30px}.userenrolment .col_role .role,
.userenrolment .col_group
.group{float:left;white-space:nowrap;margin-right:6px}.userenrolment .col_role .role a,
.userenrolment .col_group .group
a{margin-left:3px;cursor:pointer}.userenrolment .col_role .addrole,
.userenrolment .col_group
.addgroup{float:right}.userenrolment .col_role .addrole a img,
.userenrolment .col_group .addgroup a
img{vertical-align:bottom}.userenrolment .hasAllRoles .col_role
.addrole{display:none}.dir-rtl .userenrolment .col_role
.role{float:right}.userenrolment .col_enrol
.enrolment{float:left}.userenrolment .col_enrol .enrolment
a{float:right;margin-left:3px}#page-enrol-users
.enrol_user_buttons{float:right}#page-enrol-users .enrol_user_buttons
.singlebutton{margin-top:2px;line-height:2}#page-enrol-users .enrol_user_buttons
.enrolusersbutton{margin-left:1em;display:inline}#page-enrol-users .enrol_user_buttons .enrolusersbutton div,
#page-enrol-users .enrol_user_buttons .enrolusersbutton
form{display:inline}#page-enrol-users .enrol_user_buttons .enrolusersbutton
input{padding-left:6px;padding-right:6px}#page-enrol-users.dir-rtl .col_userdetails
.subfield_picture{float:right}#page-enrol-users #filterform div,
#page-enrol-users #filterform
fieldset{display:inline;float:none;clear:none;width:auto;margin:0;line-height:2}#page-enrol-users #filterform
.fitem{white-space:nowrap}#page-enrol-users #filterform fieldset>div{display:block;float:left;background:#f2f2f2;padding:2px}#page-enrol-users #filterform select,
#page-enrol-users #filterform .ftext
input{width:8em}#page-enrol-users #filterform #fitem_id_role,
#page-enrol-users #filterform #fitem_id_ifilter,
#page-enrol-users #filterform
#fgroup_id_buttons{margin-left:0.5em}#page-enrol-users
.paging{clear:right}.dir-rtl
.headermain{float:right}.dir-rtl
.headermenu{float:left;text-align:left}.dir-rtl
.breadcrumb{float:right}.dir-rtl
.navbutton{float:left}.dir-rtl .navbutton
.singlebutton{margin-right:4px}.dir-rtl .breadcrumb ul
li{float:right;margin-left:5px}.dir-rtl .mform .fitem
.fitemtitle{float:right}.dir-rtl .loginbox .loginform .form-label{float:right;text-align:left}.dir-rtl .loginbox .loginform .form-input{text-align:right}.dir-rtl .yui3-menu-hidden{left:0px}#page-admin-roles-define.dir-rtl #rolesform
.felement{margin-right:180px}#page-message-edit.dir-rtl table.generaltable
th.c0{text-align:right}.backup-restore .backup-section{clear:both;border:1px
solid #ddd;background-color:#f6f6f6;margin-bottom:1em}.backup-restore .backup-section>h2.header{padding:5px
6px;margin:0;border-bottom:1px solid #ddd}.backup-restore .backup-section
.noticebox{margin:1em
auto;width:60%;text-align:center}.backup-restore .backup-section .backup-sub-section{margin:0
25px;background-color:#f9f9f9;border:1px
solid #f3f3f3;margin-bottom:1em}.backup-restore .backup-section .backup-sub-section
h3{text-align:right;border-bottom:1px solid #DDD;padding:5px
86% 5px 6px;margin:0;background-color:#e9e9e9}.backup-restore .backup-section.settings-section .detail-pair{margin:0;padding:0;width:50%;display:inline-block}.backup-restore .backup-section.settings-section .detail-pair .detail-pair-label{width:65%}.backup-restore .backup-section.settings-section .detail-pair .detail-pair-value{width:25%}.backup-restore
.activitytable{width:60%;min-width:500px}.backup-restore .activitytable
.modulename{width:100px}.backup-restore .activitytable
.moduleincluded{width:50px}.backup-restore .activitytable
.userinfoincluded{width:50px}.backup-restore .detail-pair{}.backup-restore .detail-pair-label{display:inline-block;width:25%;padding:8px;margin:0;text-align:right;font-weight:bold;color:#444;vertical-align:top}.backup-restore .detail-pair-value{display:inline-block;width:65%;padding:8px;margin:0}.backup-restore .detail-pair-value>.sub-detail{display:block;color:#1580B6;margin-left:2em;font-size:90%;font-style:italic}.backup-restore>.singlebutton{text-align:right}.path-backup .mform .fgroup .proceedbutton,
.path-backup .mform .fgroup
.oneclickbackup{float:right;margin-right:1%}.dir-rtl.path-backup .mform .fgroup .proceedbutton,
.dir-rtl.path-backup .mform .fgroup
.oneclickbackup{float:left;margin-left:1%;margin-right:0}.restore-course-search .rcs-results{width:70%;min-width:400px;border:1px
solid #ddd;margin:5px
0}.restore-course-search .rcs-results
table{width:100%;margin:0;border-width:0}.restore-course-search .rcs-results table .no-overflow{max-width:600px}.restore-course-search .rcs-results
.paging{text-align:left;margin:0;background-color:#eee;padding:3px}.restore-course-category .rcs-results{width:70%;min-width:400px;border:1px
solid #ddd;margin:5px
0}.restore-course-category .rcs-results
table{width:100%;margin:0;border-width:0}.restore-course-category .rcs-results table .no-overflow{max-width:600px}.restore-course-category .rcs-results
.paging{text-align:left;margin:0;background-color:#eee;padding:3px}.corelightbox{background-color:#CCC;position:absolute;top:0;left:0;width:100%;height:100%;text-align:center}.corelightbox
img{position:fixed;top:50%;left:50%}.mod-indent{display:table-cell}.label .mod-indent{float:left;padding-top:20px}.mod-indent-1{width:30px}.mod-indent-2{width:60px}.mod-indent-3{width:90px}.mod-indent-4{width:120px}.mod-indent-5{width:150px}.mod-indent-6{width:180px}.mod-indent-7{width:210px}.mod-indent-8{width:240px}.mod-indent-9{width:270px}.mod-indent-10{width:300px}.mod-indent-11{width:330px}.mod-indent-12{width:360px}.mod-indent-13{width:390px}.mod-indent-14{width:420px}.mod-indent-15{width:450px}.mod-indent-16,.mod-indent-huge{width:480px}.dir-rtl .mform .fitem
.felement{margin-right:16%;margin-left:auto;text-align:right}.dir-rtl .mform .fitem .felement input[name=email],
.dir-rtl .mform .fitem .felement input[name=email2],
.dir-rtl .mform .fitem .felement input[name=url],
.dir-rtl .mform .fitem .felement input[name=idnumber],
.dir-rtl .mform .fitem .felement input[name=phone1],
.dir-rtl .mform .fitem .felement input[name=phone2]{text-align:left;direction:ltr}.resourcecontent .mediaplugin_mp3
object{height:25px;width:600px}.resourcecontent
audio.mediaplugin_html5audio{width:600px}.resourceimage{max-width:100%}.mediaplugin_mp3
object{height:15px;width:300px}audio.mediaplugin_html5audio{width:300px}.core_media_preview.pagelayout-embedded #page-content{padding:0}.core_media_preview.pagelayout-embedded
#maincontent{height:0}.core_media_preview.pagelayout-embedded
.mediaplugin{margin:0}sub{vertical-align:sub}sup{vertical-align:super}.dir-rtl .ygtvtn,
.dir-rtl .ygtvtm,
.dir-rtl .ygtvtmh,
.dir-rtl .ygtvtmhh,
.dir-rtl .ygtvtp,
.dir-rtl .ygtvtph,
.dir-rtl .ygtvtphh,
.dir-rtl .ygtvln,
.dir-rtl .ygtvlm,
.dir-rtl .ygtvlmh,
.dir-rtl .ygtvlmhh,
.dir-rtl .ygtvlp,
.dir-rtl .ygtvlph,
.dir-rtl .ygtvlphh,
.dir-rtl .ygtvdepthcell,
.dir-rtl .ygtvok,
.dir-rtl .ygtvok:hover,
.dir-rtl .ygtvcancel,
.dir-rtl .ygtvcancel:hover{width:18px;height:22px;background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/yui2-treeview-sprite-rtl);background-repeat:no-repeat;cursor:pointer}.dir-rtl
.ygtvtn{background-position:0 -5600px}.dir-rtl
.ygtvtm{background-position:0 -4000px}.dir-rtl .ygtvtmh,
.dir-rtl
.ygtvtmhh{background-position:0 -4800px}.dir-rtl
.ygtvtp{background-position:0 -6400px}.dir-rtl .ygtvtph,
.dir-rtl
.ygtvtphh{background-position:0 -7200px}.dir-rtl
.ygtvln{background-position:0 -1600px}.dir-rtl
.ygtvlm{background-position:0 0}.dir-rtl .ygtvlmh,
.dir-rtl
.ygtvlmhh{background-position:0 -800px}.dir-rtl
.ygtvlp{background-position:0 -2400px}.dir-rtl .ygtvlph,
.dir-rtl
.ygtvlphh{background-position:0 -3200px}.dir-rtl
.ygtvdepthcell{background-position:0 -8000px}.dir-rtl
.ygtvok{background-position:0 -8800px}.dir-rtl .ygtvok:hover{background-position:0 -8844px}.dir-rtl
.ygtvcancel{background-position:0 -8822px}.dir-rtl .ygtvcancel:hover{background-position:0 -8866px}.dir-rtl.yui-skin-sam .yui-panel
.hd{text-align:left}.dir-rtl .yui-skin-sam .yui-layout .yui-layout-unit div.yui-layout-bd{text-align:right}.dir-rtl .clearlooks2.ie9 .mceAlert .mceMiddle span,.dir-rtl .clearlooks2 .mceConfirm .mceMiddle
span{top:44px}.dir-rtl .o2k7Skin table,
.dir-rtl .o2k7Skin tbody,
.dir-rtl .o2k7Skin a,
.dir-rtl .o2k7Skin img,
.dir-rtl .o2k7Skin tr,
.dir-rtl .o2k7Skin div,
.dir-rtl .o2k7Skin td,
.dir-rtl .o2k7Skin iframe,
.dir-rtl .o2k7Skin span,
.dir-rtl .o2k7Skin *,
.dir-rtl .o2k7Skin .mceText,
.dir-rtl .o2k7Skin .mceListBox
.mceText{text-align:right}.path-rating
.ratingtable{width:100%;margin-bottom:1em}.path-rating .ratingtable
th.rating{width:100%}.path-rating .ratingtable td.rating,
.path-rating .ratingtable
td.time{white-space:nowrap;text-align:center}.course-content ul.weeks .content .summary ul,
.course-content ul.topics .content .summary
ul{list-style:disc outside none}.course-content ul.weeks .content .summary ul ul,
.course-content ul.topics .content .summary ul
ul{list-style:circle outside none}.course-content ul.weeks .content .summary ul ul ul,
.course-content ul.topics .content .summary ul ul
ul{list-style:square outside none}.course-content ul.weeks .content .summary ol,
.course-content ul.topics .content .summary
ol{list-style:decimal outside none}.dir-rtl #adminsettings #id_s__pathtodu,
.dir-rtl #adminsettings #id_s__aspellpath,
.dir-rtl #adminsettings #id_s__pathtodot,
.dir-rtl #adminsettings #id_s__supportemail,
.dir-rtl #adminsettings #id_s__supportpage,
.dir-rtl #adminsettings #id_s__sessioncookie,
.dir-rtl #adminsettings #id_s__sessioncookiepath,
.dir-rtl #adminsettings #id_s__sessioncookiedomain,
.dir-rtl #adminsettings #id_s__proxyhost,
.dir-rtl #adminsettings #id_s__proxyuser,
.dir-rtl #adminsettings #id_s__proxypassword,
.dir-rtl #adminsettings #id_s__proxybypass,
.dir-rtl #adminsettings #id_s__jabberhost,
.dir-rtl #adminsettings #id_s__jabberserver,
.dir-rtl #adminsettings #id_s__jabberusername,
.dir-rtl #adminsettings #id_s__jabberpassword,
.dir-rtl #adminsettings #id_s__additionalhtmlhead,
.dir-rtl #adminsettings #id_s__additionalhtmltopofbody,
.dir-rtl #adminsettings #id_s__additionalhtmlfooter,
.dir-rtl #adminsettings #id_s__docroot,
.dir-rtl #adminsettings #id_s__filter_tex_latexpreamble,
.dir-rtl #adminsettings #id_s__filter_tex_latexbackground,
.dir-rtl #adminsettings #id_s__filter_tex_pathlatex,
.dir-rtl #adminsettings #id_s__filter_tex_pathdvips,
.dir-rtl #adminsettings #id_s__filter_tex_pathconvert,
.dir-rtl #adminsettings #id_s__blockedip,
.dir-rtl #adminsettings #id_s__pathtoclam,
.dir-rtl #adminsettings #id_s__quarantinedir,
.dir-rtl #adminsettings #id_s__sitepolicy,
.dir-rtl #adminsettings #id_s__sitepolicyguest,
.dir-rtl #adminsettings #id_s__cronremotepassword,
.dir-rtl #adminsettings #id_s__allowedip,
.dir-rtl #adminsettings #id_s__blockedip,
.dir-rtl #adminsettings #id_s_enrol_meta_nosyncroleids,
.dir-rtl #adminsettings #id_s_enrol_ldap_host_url,
.dir-rtl #adminsettings #id_s_enrol_ldap_ldapencoding,
.dir-rtl #adminsettings #id_s_enrol_ldap_bind_dn,
.dir-rtl #adminsettings #id_s_enrol_ldap_bind_pw,
.dir-rtl #adminsettings #admin-emoticons .form-text,
.dir-rtl #adminsettings #admin-role_mapping input[type=text],
.dir-rtl #adminsettings #id_s_enrol_paypal_paypalbusiness,
.dir-rtl #adminsettings #id_s_enrol_flatfile_location,
#page-admin-setting-enrolsettingsflatfile.dir-rtl input[type=text],
#page-admin-setting-enrolsettingsdatabase.dir-rtl input[type=text],
#page-admin-auth-db.dir-rtl input[type=text]{direction:ltr}#page-admin-setting-enrolsettingsflatfile.dir-rtl
.informationbox{direction:ltr;text-align:left}#page-admin-grade-edit-scale-edit.dir-rtl .error
input#id_name{margin-right:170px}.initialbar
a{padding-right:2px}.moodle-dialogue-base .moodle-dialogue-lightbox{background-color:#AAA}.moodle-dialogue-base .moodle-dialogue{outline:#000 dotted 0}.moodle-dialogue-base .hidden,
.moodle-dialogue-base .moodle-dialogue-hidden{display:none}.moodle-dialogue-base .moodle-dialogue{padding:0;margin:0;background:none;border:none;z-index:600}.no-scrolling{overflow:hidden}.moodle-dialogue-base .moodle-dialogue-fullscreen{left:0px;top:0px;right:0px;bottom:-50px;position:fixed}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-content{overflow:auto}.moodle-dialogue-base .moodle-dialogue-fullscreen
.closebutton{width:28px;height:16px;background-size:100%}.moodle-dialogue-base .moodle-dialogue-wrap{margin-top:-3px;margin-left:-3px;background-color:#FFF;border:1px
solid #CCC;border-radius:10px;box-shadow:5px 5px 20px 0px #666;-webkit-box-shadow:5px 5px 20px 0px #666;-moz-box-shadow:5px 5px 20px 0px #666;overflow:hidden}.moodle-dialogue-base
h3{margin:0;line-height:20px}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd,
.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd.yui3-widget-hd{margin:0;padding:5px;font-size:12px;font-weight:normal;letter-spacing:1px;color:#333;text-align:center;text-shadow:1px 1px 1px #FFF;border-radius:10px 10px 0px 0px;border-bottom:1px solid #BBB;background-color:#CCC;-ms-filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#FFFFFF', endColorstr='#CCCCCC')!important;-ms-filter:dropshadow(color=#FFFFFF, offx=1, offy=1);background-image:-webkit-linear-gradient(top, #FFFFFF, #CCCCCC);background-image:-moz-linear-gradient(top, #FFFFFF, #CCCCCC);background-image:-ms-linear-gradient(top, #FFFFFF, #CCCCCC);background-image:-o-linear-gradient(top, #FFFFFF, #CCCCCC);background-image:linear-gradient(to bottom, #FFFFFF, #CCCCCC)}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd
h1{margin:0;padding:0;display:inline;font-size:100%;font-weight:bold}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd .yui3-widget-buttons{padding:5px}.moodle-dialogue-base
.closebutton{width:25px;height:15px;float:right;vertical-align:middle;display:inline-block;cursor:pointer;padding:0px;background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/sprite);background-repeat:no-repeat;border-style:none}.dir-rtl .moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd .yui3-widget-buttons{left:0px;right:auto}.moodle-dialogue-base .moodle-dialogue .moodle-dialogue-bd{padding:1em;line-height:2em;color:#555;font-size:12px}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-content{padding:0px;background:#FFF}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-hd{padding:10px;font-size:16px}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-content{overflow:auto;position:absolute;top:0px;bottom:50px;left:0px;right:0px;margin:0px;border:0px}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-hd,
.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-wrap{border-radius:0px}.moodle-dialogue-confirm .confirmation-dialogue{text-align:center}.moodle-dialogue-confirm .confirmation-dialogue
input{text-align:center}.moodle-dialogue-exception .moodle-exception-message{text-align:center}.moodle-dialogue-exception .moodle-exception-param
label{font-weight:bold}.moodle-dialogue-exception .param-stacktrace
label{background-color:#EEE;border:1px
solid #ccc;border-bottom-width:0}.moodle-dialogue-exception .param-stacktrace
pre{border:1px
solid #ccc;background-color:#fff}.moodle-dialogue-exception .param-stacktrace .stacktrace-file{color:navy;font-size:80%}.moodle-dialogue-exception .param-stacktrace .stacktrace-line{color:#A00;font-size:80%}.moodle-dialogue-exception .param-stacktrace .stacktrace-call{color:#333;font-size:90%;border-bottom:1px solid #eee}.moodle-dialogue-base .moodle-dialogue .moodle-dialogue-content .moodle-dialogue-ft{padding:0px;margin:0.7em 1em;text-align:right;background-color:#FFF;font-size:12px}.moodle-dialogue-confirm .confirmation-message{margin:0.5em 1em}.moodle-dialogue-confirm .confirmation-dialogue
input{min-width:80px}.moodle-dialogue-exception .moodle-exception-message{margin:1em}.moodle-dialogue-exception .moodle-exception-param{margin-bottom:0.5em}.moodle-dialogue-exception .moodle-exception-param
label{width:150px}.moodle-dialogue-exception .param-stacktrace
label{display:block;margin:0;padding:4px
1em}.moodle-dialogue-exception .param-stacktrace
pre{display:block;height:200px;overflow:auto}.moodle-dialogue-exception .param-stacktrace .stacktrace-file{display:inline-block;margin:4px
0}.moodle-dialogue-exception .param-stacktrace .stacktrace-line{display:inline-block;width:50px;margin:4px
1em}.moodle-dialogue-exception .param-stacktrace .stacktrace-call{padding-left:25px;margin-bottom:4px;padding-bottom:4px}.moodle-dialogue .moodle-dialogue-bd .content-lightbox{opacity: .75;width:100%;height:100%;top:0;left:0;background-color:white;text-align:center;padding:10% 0}.moodle-dialogue
.tooltiptext{max-height:300px}.moodle-dialogue-base .moodle-dialogue.moodle-dialogue-tooltip{z-index:3001}.moodle-dialogue-base .moodle-dialogue.moodle-dialogue-tooltip .moodle-dialogue-bd{overflow:auto}#page-question-edit.dir-rtl a.container-close{right:auto;left:6px}.chooserdialoguebody,.choosertitle{display:none}.moodle-dialogue.chooserdialogue .moodle-dialogue-content .moodle-dialogue-ft{margin:0}.chooserdialogue .moodle-dialogue-wrap .moodle-dialogue-bd{padding:0px;background:#F2F2F2;border-bottom-left-radius:10px;border-bottom-right-radius:10px}.choosercontainer #chooseform
.submitbuttons{padding:0.7em 0;text-align:center}.choosercontainer #chooseform .submitbuttons
input{min-width:100px;margin:0px
0.5em}.choosercontainer #chooseform
.options{position:relative;border-bottom:1px solid #BBB}.jschooser .choosercontainer #chooseform
.alloptions{overflow-x:hidden;overflow-y:auto;max-width:20.3em;box-shadow:inset 0px 0px 30px 0px #CCC;-webkit-box-shadow:inset 0px 0px 30px 0px #CCC;-moz-box-shadow:inset 0px 0px 30px 0px #CCC}.jschooser .choosercontainer #chooseform .alloptions .option input[type=radio],
.jschooser .choosercontainer #chooseform .alloptions .option
.modicon{display:inline-block}.jschooser .choosercontainer #chooseform .alloptions .option
.typename{display:inline-block;width:65%}.dir-rtl.jschooser .choosercontainer #chooseform
.alloptions{max-width:18.3em}.choosercontainer #chooseform .moduletypetitle,
.choosercontainer #chooseform .option,
.choosercontainer #chooseform
.nonoption{margin-bottom:0;padding:0
1.6em 0 1.6em}.choosercontainer #chooseform
.moduletypetitle{text-transform:uppercase;padding-top:1.2em;padding-bottom:0.4em}.choosercontainer #chooseform .option .typename,
.choosercontainer #chooseform .option span.modicon img.icon,
.choosercontainer #chooseform .nonoption .typename,
.choosercontainer #chooseform .nonoption span.modicon
img.icon{padding:0
0 0 0.5em}.dir-rtl .choosercontainer #chooseform .option .typename,
.dir-rtl .choosercontainer #chooseform .option span.modicon img.icon,
.dir-rtl .choosercontainer #chooseform .nonoption .typename,
.dir-rtl .choosercontainer #chooseform .nonoption span.modicon
img.icon{padding:0
0.5em 0 0}.chooserdialogue-course-modchooser .choosercontainer #chooseform .option span.modicon img.icon,
.chooserdialogue-course-modchooser .choosercontainer #chooseform .nonoption span.modicon
img.icon{height:24px;width:24px}.choosercontainer #chooseform .option input[type=radio],
.choosercontainer #chooseform .option span.typename,
.choosercontainer #chooseform .option
span.modicon{vertical-align:middle}.choosercontainer #chooseform .option
label{display:block;padding:0.3em 0 0.1em 0;border-bottom:1px solid #FFF}.choosercontainer #chooseform
.nonoption{padding-left:2.7em;padding-top:0.3em;padding-bottom:0.1em}.dir-rtl .choosercontainer #chooseform
.nonoption{padding-right:2.7em;padding-left:0}.choosercontainer #chooseform
.subtype{margin-bottom:0;padding:0
1.6em 0 3.2em}.dir-rtl .choosercontainer #chooseform
.subtype{padding:0
3.2em 0 1.6em}.choosercontainer #chooseform .subtype
.typename{margin:0
0 0 0.2em}.dir-rtl .choosercontainer #chooseform .subtype
.typename{margin:0
0.2em 0 0}.jschooser .choosercontainer #chooseform .instruction,
.jschooser .choosercontainer #chooseform
.typesummary{display:none;position:absolute;top:0px;right:0px;bottom:0px;left:20.3em;margin:0;padding:1.6em;background-color:#FFF;overflow-x:hidden;overflow-y:auto;line-height:2em}.dir-rtl.jschooser .choosercontainer #chooseform .instruction,
.dir-rtl.jschooser .choosercontainer #chooseform
.typesummary{left:0px;right:18.5em;border-right:1px solid grey}.jschooser .choosercontainer #chooseform .instruction,
.choosercontainer #chooseform .selected
.typesummary{display:block}.choosercontainer #chooseform
.selected{background-color:#FFF;box-shadow:0px 0px 10px 0px #CCC;-webkit-box-shadow:0px 0px 10px 0px #CCC;-moz-box-shadow:0px 0px 10px 0px #CCC}.section-modchooser-link
img.smallicon{padding-right:3px}.dir-rtl .section-modchooser-link
img.smallicon{padding-left:3px;padding-right:0}form#installform #id_wwwroot,form#installform #id_dirroot ,form#installform #id_dataroot,
form#installform #id_dbhost, form#installform #id_dbname, form#installform #id_dbuser,
form#installform #id_dbpass, form#installform
#id_prefix{direction:ltr}html[dir=rtl] .breadcrumb,
html[dir=rtl] .headermain,
html[dir=rtl] #page-header,
html[dir=rtl] #page-content{float:right}html[dir=rtl] .formrow
label.formlabel{float:right}html[dir=rtl] .configphp{direction:ltr;text-align:left}table.flexible>tbody>tr:nth-of-type(odd),table.generaltable>tbody>tr:nth-of-type(odd){background-color:#F0F0F0}table.flexible>tbody>tr:nth-of-type(even),table.generaltable>tbody>tr:nth-of-type(even){background-color:#FAFAFA}table.flexible
.emptyrow{display:none}.formlistingradio{padding-bottom:25px;padding-right:10px}.formlistinginputradio{float:left}.formlistingmain{min-height:225px}.formlistingradiocontent{}.formlisting{position:relative;margin:15px
0;padding:1px
19px 14px;background-color:white;border:1px
solid #DDD;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.formlistingmore{position:absolute;cursor:pointer;bottom:-1px;right:-1px;padding:3px
7px;font-size:12px;font-weight:bold;background-color:whiteSmoke;border:1px
solid #DDD;color:#9DA0A4;-webkit-border-radius:4px 0 4px 0;-moz-border-radius:4px 0 4px 0;border-radius:4px 0 4px 0}.formlistingall{margin:15px
0;padding:0px
0px 0px;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.formlistingrow{cursor:pointer;border-bottom:1px solid;border-color:#E1E1E8;border-left:1px solid #E1E1E8;border-right:1px solid #E1E1E8;background-color:#F7F7F9;-webkit-border-radius:0px 0px 4px 4px;-moz-border-radius:0px 0px 4px 4px;padding:6px;top:50%;left:50%;min-height:34px;float:left;width:150px}body.jsenabled
.formlistingradio{display:none}body.jsenabled
.formlisting{display:block}#badge-overview h3,
#badge
h3{clear:both;text-align:left;padding-top:10px}.dir-rtl #badge
h3{text-align:right}#badge-image,#badge-details{display:inline-block}#badge-image{width:200px;vertical-align:top}#badge-image
.singlebutton{padding-top:5px;margin-left:20px}#badge-overview dl,
#badge-details
dl{margin:0}#badge-overview dt,
#badge-details
dt{font-weight:bold;clear:both;float:left;width:20%}#badge-overview dd,
#badge-details
dd{float:left;width:75%}#badge-overview dd,
#badge-details dd,
#badge-overview dt,
#badge-details
dt{padding:3px
0}#page-badges-view
.collection{width:90%;margin:1em
auto}#page-badges-index
.collection{width:85%;margin:1em
auto}table.collection
th{font-size:inherit !important;border-width:1px;border-style:solid;border-color:#CCC;padding-left:5px;padding-right:5px;vertical-align:top;text-align:center !important}table.collection
td{border-width:1px;border-style:solid;border-color:#CCC;padding-left:5px;padding-right:5px;vertical-align:top}table.collection>tbody>tr:nth-of-type(even){background-color:#FFF}table.collection>tbody>tr:nth-of-type(odd){background-color:#F6F6F6}table.collection
ul{margin:0.5em 0.5em 0.5em 2em}.dir-rtl table.collection
ul{margin:0.5em 2em 0.5em 0.5em}#page-badges-view table.collection .badgeimage,
#page-badges-index table.collection
.status{width:15%;text-align:center;vertical-align:middle}#page-badges-view table.collection .awards,
#page-badges-index table.collection
.awards{width:10%;text-align:center;vertical-align:middle}#page-badges-view table.collection
.description{width:25%;text-align:left}#page-badges-view.dir-rtl table.collection
.description{width:25%;text-align:right}table.collection
.name{text-align:left;vertical-align:middle}.dir-rtl table.collection
.name{text-align:right;vertical-align:middle}#page-badges-view table.collection
.criteria{width:35%;text-align:left;vertical-align:top}#page-badges-view.dir-rtl table.collection
.criteria{text-align:right}#page-badges-index table.collection
.criteria{width:40%;text-align:left;vertical-align:top}#page-badges-index.dir-rtl table.collection
.criteria{text-align:right}#page-badges-index table.collection
.actions{width:11em;text-align:center;vertical-align:middle}a.criteria-action{padding:0px
3px;float:right}.dir-rtl a.criteria-action{float:left}ul.badges{margin:0;list-style:none}.badges
li{position:relative;display:inline-block;padding-bottom:2em;text-align:center;vertical-align:top;width:150px}.badges li .badge-name{display:block;padding:5px}.badges li>img{position:absolute}.badges li .badge-image{width:100px;height:100px;left:10px;top:0px;z-index:1}.dir-rtl .badges li .badge-image{right:10px}.badges li .badge-actions{position:relative}div.badge{position:relative;display:block}div.badge
.expireimage{width:100px;height:100px;left:0px;top:0px}.expireimage{width:100px;height:100px;left:25px;top:0px;position:absolute;z-index:10;filter:alpha(opacity = 85);-moz-opacity:0.85;-khtml-opacity:0.85;opacity:0.85}.badge-profile{vertical-align:top}.connected{color:#060}.notconnected{color:#600}#page-badges-award
.recipienttable{background-color:#EEE;border:1px
solid #BBB;width:100%;vertical-align:top}#page-badges-award .recipienttable tr
td{vertical-align:top}#page-badges-award .recipienttable tr
td.actions{width:16%;padding-top:3em}#page-badges-award .recipienttable tr td.actions
.actionbutton{margin:0.3em 0;padding:0.5em 0;width:100%}#page-badges-award .recipienttable tr td.existing,
#page-badges-award .recipienttable tr
td.potential{width:42%}#issued-badge-table
.activatebadge{display:inline-block}#issued-badge-table
div.activatebadge{margin-left:3px}.statusbox{border-color:#BBB;padding:5px;text-align:center}.statusbox.active{background-color:#D9F991}.statusbox.inactive{background-color:#FFEBA8}.statusbox
.activatebadge{display:inline-block}.statusbox .activatebadge input[type=submit]{margin:3px}.dir-rtl
.activatebadge{text-align:right}.addcourse{float:right}.dir-rtl
.addcourse{float:left}img#persona_signin{cursor:pointer}div#dateselector-calendar-panel{z-index:3100}.path-mod-lesson
.centerpadded{padding:5px;text-align:center}.moodle-actionmenu,.moodle-actionmenu>ul,.moodle-actionmenu>ul>li{display:inline-block}.moodle-actionmenu
ul{padding:0;margin:0;list-style-type:none}.section_action_menu .moodle-actionmenu
ul.menubar{margin:0}.section_action_menu .moodle-actionmenu
ul.menu{margin:0
10px 10px 0}#page .moodle-actionmenu
a.hidden{display:none}.moodle-actionmenu .toggle-display,
.moodle-actionmenu .menu-action-text{display:none}.jsenabled .block
.editing_move{display:none}.jsenabled .moodle-actionmenu[data-enhance]{display:block}.jsenabled .moodle-actionmenu[data-enhance] .menu{display:none}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display{display:inline;opacity:0.5;filter:alpha(opacity=50)}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu{display:block;margin-left:4px;padding-left:4px;padding-right:4px}.jsenabled.dir-rtl .moodle-actionmenu[data-enhance] .toggle-display.textmenu{margin-right:4px;margin-left:initial}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.iconsmall{margin:8px
4px 0px 2px}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-top:4px;margin-left:2px}.jsenabled.dir-rtl .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-right:2px;margin-left:initial}.jsenabled .moodle-actionmenu[data-enhanced] .toggle-display{opacity:1;filter:alpha(opacity=100)}.jsenabled .moodle-actionmenu[data-enhanced] .menu-action-text{display:inline}.moodle-actionmenu[data-enhanced].show{position:relative}.moodle-actionmenu[data-enhanced].show
.menu{position:absolute;text-align:left;z-index:1000;display:block;background-color:#fff;border:1px
solid #ccc;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}.moodle-actionmenu[data-enhanced].show .menu
a{display:block;padding:2px
1em 2px 28px;color:#333}.moodle-actionmenu[data-enhanced].show .menu a>img{margin:4px
4px 4px -24px;padding:4px;width:12px;height:12px}.moodle-actionmenu[data-enhanced].show .menu a > img,
.moodle-actionmenu[data-enhanced].show .menu a>span{display:inline-block;vertical-align:middle}.moodle-actionmenu[data-enhanced].show .menu a:hover{color:#fff;background-color:#08c}.moodle-actionmenu[data-enhanced].show .menu a:first-child{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topright:4px;-moz-border-radius-topleft:4px}.moodle-actionmenu[data-enhanced].show .menu a:last-child{-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-moz-border-radius-bottomright:4px;-moz-border-radius-bottomleft:4px}.moodle-actionmenu[data-enhanced].show .menu
a.hidden{display:none}.moodle-actionmenu[data-enhanced].show .menu
img{vertical-align:middle}.moodle-actionmenu[data-enhanced].show .menu>li{display:block}.block .moodle-actionmenu{text-align:right}.dir-rtl .block .moodle-actionmenu{text-align:right}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu
a{display:block;padding:2px
28px 2px 1em}.dir-rtl .moodle-actionmenu[data-enhanced].show
.menu{text-align:right;right:auto;left:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu .iconsmall,
.dir-rtl .moodle-actionmenu[data-enhanced].show .menu
.smallicon{margin-right:-24px;margin-left:4px}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tl-bl{top:100%;left:0;margin-top:4px}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tr-bl{top:100%;right:100%}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-bl-bl{bottom:100%;left:0}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-br-bl{right:100%;bottom:100%}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tl-br{top:100%;left:100%}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tr-br{top:100%;right:0;margin-top:4px}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-bl-br{bottom:100%;left:100%}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-br-br{right:0;bottom:100%}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tl-tl{top:0;left:0}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tr-tl{top:0;right:100%;margin-right:4px}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-bl-tl{bottom:100%;left:0;margin-bottom:4px}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-br-tl{right:100%;bottom:100%}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tl-tr{top:0;left:100%;margin-left:4px}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tr-tr{top:0;right:0}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-bl-tr{bottom:100%;left:100%}.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-br-tr{right:0;bottom:100%;margin-bottom:4px}.moodle-actionmenu>ul>li[role="menuitem"]{display:none}.jsenabled .moodle-actionmenu[data-enhance="moodle-core-actionmenu"]>ul>li[role="menuitem"]{display:inline-block}.dir-rtl .menu.align-tl-bl{right:0;left:auto}.dir-rtl .menu.align-tr-bl{right:auto;left:100%}.dir-rtl .menu.align-bl-bl{right:0;left:auto}.dir-rtl .menu.align-br-bl{right:auto;left:100%}.dir-rtl .menu.align-tl-br{right:100%;left:auto}.dir-rtl .menu.align-tr-br{right:auto;left:0}.dir-rtl .menu.align-bl-br{right:100%;left:auto}.dir-rtl .menu.align-br-br{right:auto;left:0}.dir-rtl .menu.align-tl-tl{right:0;left:auto}.dir-rtl .menu.align-tr-tl{right:auto;left:100%}.dir-rtl .menu.align-bl-tl{right:0;left:auto}.dir-rtl .menu.align-br-tl{right:auto;left:100%}.dir-rtl .menu.align-tl-tr{right:100%;left:auto}.dir-rtl .menu.align-tr-tr{right:auto;left:0}.dir-rtl .menu.align-bl-tr{right:100%;left:auto}.dir-rtl .menu.align-br-tr{right:auto;left:0}ul.dragdrop-keyboard-drag
li{list-style-type:none}.block-control-actions .moodle-core-dragdrop-draghandle
img{width:12px;height:12px}.block .header h2,
.course-content h3,
.pagelayout-frontpage h2,
.pagelayout-frontpage h3,
.pagelayout-frontpage h4,
.pagelayout-frontpage h5,
.pagelayout-frontpage h6,
.pagelayout-coursecategory h3,
.pagelayout-coursecategory h4,
.pagelayout-coursecategory h5,
.pagelayout-coursecategory
h6{text-align:inherit}a.disabled:hover,a.disabled{text-decoration:none;cursor:default;font-style:italic;color:#808080}.caret{display:inline-block;width:0;height:0;vertical-align:top;border-top:4px solid #777;border-right:4px solid transparent;border-left:4px solid transparent;content:""}a:focus .caret,
a:hover
.caret{border-top-color:#555}@-webkit-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-moz-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-o-keyframes progress-bar-stripes{from{background-position:0 0}to{background-position:40px 0}}@keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}.progress{height:20px;margin-bottom:20px;overflow:hidden;background-color:#f7f7f7;background-image:-moz-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#f5f5f5), to(#f9f9f9));background-image:-webkit-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:-o-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:linear-gradient(to bottom, #f5f5f5, #f9f9f9);background-repeat:repeat-x;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5', endColorstr='#fff9f9f9', GradientType=0);-webkit-box-shadow:inset 0 1px 2px rgba(0, 0, 0, 0.1);-moz-box-shadow:inset 0 1px 2px rgba(0, 0, 0, 0.1);box-shadow:inset 0 1px 2px rgba(0, 0, 0, 0.1)}.progress
.bar{float:left;width:0;height:100%;font-size:12px;color:#fff;text-align:center;text-shadow:0 -1px 0 rgba(0, 0, 0, 0.25);background-color:#0e90d2;background-image:-moz-linear-gradient(top, #149bdf, #0480be);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#149bdf), to(#0480be));background-image:-webkit-linear-gradient(top, #149bdf, #0480be);background-image:-o-linear-gradient(top, #149bdf, #0480be);background-image:linear-gradient(to bottom, #149bdf, #0480be);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf', endColorstr='#ff0480be', GradientType=0);-webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, 0.15);-moz-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, 0.15);box-shadow:inset 0 -1px 0 rgba(0, 0, 0, 0.15);-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-transition:width 0.6s ease;-moz-transition:width 0.6s ease;-o-transition:width 0.6s ease;transition:width 0.6s ease}.progress .bar+.bar{-webkit-box-shadow:inset 1px 0 0 rgba(0, 0, 0, 0.15), inset 0 -1px 0 rgba(0, 0, 0, 0.15);-moz-box-shadow:inset 1px 0 0 rgba(0, 0, 0, 0.15), inset 0 -1px 0 rgba(0, 0, 0, 0.15);box-shadow:inset 1px 0 0 rgba(0, 0, 0, 0.15), inset 0 -1px 0 rgba(0, 0, 0, 0.15)}.progress-striped
.bar{background-color:#149bdf;background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.15)), color-stop(0.75, rgba(255, 255, 255, 0.15)), color-stop(0.75, transparent), to(transparent));background-image:-webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);background-image:-moz-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);-webkit-background-size:40px 40px;-moz-background-size:40px 40px;-o-background-size:40px 40px;background-size:40px 40px}.progress.active
.bar{-webkit-animation:progress-bar-stripes 2s linear infinite;-moz-animation:progress-bar-stripes 2s linear infinite;-ms-animation:progress-bar-stripes 2s linear infinite;-o-animation:progress-bar-stripes 2s linear infinite;animation:progress-bar-stripes 2s linear infinite}body.lockscroll{height:100%;overflow:hidden}.dropdown-menu{background-color:#fff;border:1px
solid #ccc;border:1px
solid rgba(0, 0, 0, 0.2);position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px
0;margin:2px
0 0;list-style:none;*border-right-width:2px;*border-bottom-width:2px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0, 0, 0, 0.2);-moz-box-shadow:0 5px 10px rgba(0, 0, 0, 0.2);box-shadow:0 5px 10px rgba(0,0,0,0.2);-webkit-background-clip:padding-box;-moz-background-clip:padding;background-clip:padding-box}.dropdown-menu>li>a{display:block;padding:3px
20px;clear:both;font-weight:normal;line-height:20px;white-space:nowrap}.dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus{text-decoration:none;background-repeat:repeat-x}.dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus{text-decoration:none;outline:0}.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{text-decoration:none;background-color:transparent;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);cursor:default}.open{*z-index:1000}.open>.dropdown-menu{display:block}.editor_atto_menu .moodle-dialogue-content{padding:0;border:inherit}.well{min-height:20px;padding:19px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-radius:4px;box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.well-small{padding:9px}.progressbar_container{max-width:500px;margin:0
auto}.ie10 .yui3-calendar-header-label{display:inline-block}.inplaceeditable.inplaceeditingon{position:relative}.inplaceeditable.inplaceeditingon
.editinstructions{margin-top:-30px;font-weight:normal;margin-right:-300px;margin-left:0}.dir-rtl .inplaceeditable.inplaceeditingon
.editinstructions{margin-left:-300px;margin-right:0}.inplaceeditable .quickeditlink .quickediticon
img{opacity:0.2}.inplaceeditable
a.quickeditlink{color:inherit;text-decoration:inherit}.inplaceeditable:hover .quickeditlink .quickediticon img,
.inplaceeditable .quickeditlink:focus .quickediticon
img{opacity:1}.inplaceeditable.inplaceeditable-toggle
.quickediticon{display:none}.inplaceeditable.inplaceeditingon
input{width:330px;height:16px;vertical-align:text-bottom;margin-bottom:0}.formtable tbody
th{font-weight:normal;text-align:right}.path-admin #manageauthtable,
.path-admin
.admintable{width:100%}.path-admin
#assignrole{width:60%;margin-left:auto;margin-right:auto}.path-admin .admintable
.leftalign{text-align:left}.dir-rtl.path-admin .admintable
.leftalign{text-align:right}.path-admin .admintable
.centeralign{text-align:center}.path-admin .admintable.environmenttable .name,
.path-admin .admintable.environmenttable .status,
.path-admin .admintable.environmenttable
.info{width:10%;white-space:nowrap}.path-admin #cohorts .admintable
.name{width:20%}.path-admin #cohorts .admintable .id,
.path-admin #cohorts .admintable .size,
.path-admin #cohorts .admintable .action,
.path-admin #cohorts .admintable
.source{width:10%}.path-admin #cohorts .admintable
.description{width:40%}.path-admin .admintable.externalservices
.service{width:30%}.path-admin .admintable.externalservices .plugin,
.path-admin .admintable.externalservices
.delete{width:20%}.path-admin .admintable.externalservices
.functions{width:20%}.path-admin .admintable.externalservices
.users{width:20%}.path-admin .admintable.externalservices
.action{width:10%}.path-admin .wsoverview.admintable
.step{width:30%}.path-admin .wsoverview.admintable
.status{width:10%}.path-admin .wsoverview.admintable
.description{width:60%}.path-admin #assignrole .admintable .role,
.path-admin #assignrole .admintable .userrole,
.path-admin #assignrole .admintable
.roleholder{white-space:nowrap}.path-admin .admintable.environmenttable
.report{width:100%}.path-admin #configchanges .admintable
.date{width:30%}.path-admin #configchanges .admintable .name,
.path-admin #configchanges .admintable .plugin,
.path-admin #configchanges .admintable
.setting{width:10%}.path-admin #configchanges .admintable .newvalue,
.path-admin #configchanges .admintable
.originalvalue{width:20%}.path-admin .securityreport.admintable
.issue{width:30%}.path-admin .securityreport.admintable
.status{width:10%}.path-admin .securityreport.admintable
.desc{width:50%}.path-admin .securityreport.admintable
.config{width:10%}.path-admin #securityreporttable .admintable
.desc{width:60%}#page-admin-index
.c0{vertical-align:top}#page-admin-index
.c1{vertical-align:middle}#page-admin-blocks .generaltable th,
#page-admin-filters .generaltable th,
#page-admin-auth .generaltable th,
#page-admin-modules .generaltable th,
#page-admin-modules .generaltable
td.c0{white-space:nowrap;padding:4px}#page-admin-blocks .generaltable td.cell,
#page-admin-filters .generaltable td.cell,
#page-admin-modules .generaltable td.cell,
#page-admin-auth .generaltable
td.cell{padding:4px}.path-admin .incompatibleblockstable
td.c0{font-weight:bold}#page-admin-course-manage
.addcategory{padding:10px}#page-admin-course-manage
.buttons{margin-bottom:15px}#page-admin-course-manage
.editcourse{margin:20px
auto}#page-admin-course-manage .editcourse th,
#page-admin-course-manage .editcourse
td{padding-left:10px;padding-right:10px}#page-admin-course-manage .editcourse
.count{text-align:right}#page-admin-course-manage.dir-rtl .editcourse td[align="left"]{text-align:right}#page-admin-course-manage.dir-rtl .editcourse td[align="right"]{text-align:left}#page-admin-report-security-index
.timewarninghidden{display:none}#page-admin-report-security-index .statuswarning, #page-admin-report-performance-index
.statuswarning{background-color:#f0e000}#page-admin-report-security-index .statusserious, #page-admin-report-performance-index
.statusserious{background-color:#f07000}#page-admin-report-security-index .statuscritical, #page-admin-report-performance-index
.statuscritical{background-color:#f00000}#page-admin-report-capability-index .rolecaps
th{text-align:left}#page-admin-report-capability-index #settingsform
#capabilitysearch{width:30em}#page-admin-report-backups-index .backup-report{width:100%}#page-admin-report-backups-index .backup-error,
#page-admin-report-backups-index .backup-unfinished{color:#f00000}#page-admin-report-backups-index .backup-skipped,
#page-admin-report-backups-index .backup-ok{color:#006400}#page-admin-report-backups-index .backup-warning{color:#f90}#page-admin-report-backups-index .backup-notyetrun{color:#006400}#page-admin-qbehaviours
.disabled{color:gray}#page-admin-qbehaviours
th{white-space:normal}#page-admin-qbehaviours .cell.c1,
#page-admin-qbehaviours
.cell.c2{text-align:right}#page-admin-qbehaviours
.cell.c3{font-size:0.7em}#page-admin-qbehaviours #qbehaviours div,
#page-admin-qbehaviours #qbehaviours
form{display:inline}#page-admin-qbehaviours #qbehaviours
img.spacer{width:16px}#page-admin-qbehaviours #qbehaviours
img{padding-right: .45em}#page-admin-qtypes
.disabled{color:gray}#page-admin-qtypes
th{white-space:normal}#page-admin-qtypes .cell.c1,
#page-admin-qtypes
.cell.c2{text-align:right}#page-admin-qtypes
.cell.c3{font-size:0.7em}#page-admin-qtypes #qtypes div,
#page-admin-qtypes #qtypes
form{display:inline}#page-admin-qtypes #qtypes
img.spacer{width:16px}#page-admin-qtypes #qtypes
img{padding-right: .45em;vertical-align:text-bottom}.path-admin-roles .buttons .singlebutton,
#page-admin-course-manage
.buttons{display:inline;padding:5px}.path-admin-roles
.capabilitysearchui{text-align:left;margin-left:auto;margin-right:auto}#page-admin-roles-define
.topfields{margin:1em
0 2em}#page-admin-roles-define
.mform{width:100%}#page-admin-roles-define
.capdefault{background-color:#eee;border:1px
solid #cecece}#page-filter-manage .backlink,
.path-admin-roles
.backlink{margin-top:1em}#page-admin-roles-explain #chooseuser h3,
#page-admin-roles-usersroles
.contextname{margin-top:0}#page-admin-roles-explain
#chooseusersubmit{margin-top:0;text-align:center}#page-admin-roles-usersroles
p{margin:0}#page-admin-roles-override .cell.c1,
#page-admin-roles-assign .cell.c3,
#page-admin-roles-assign
.cell.c1{padding-top:0.75em}#page-admin-roles-override .overridenotice,
#page-admin-roles-define
.definenotice{margin:1em
10% 2em 10%;text-align:left}#page-admin-index
.adminerror{background-color:#ffd3d9}#page-admin-index .adminerror .singlebutton,
#page-admin-index .adminwarning .singlebutton,
#page-admin-index #layout-table
.singlebutton{margin:20px}#page-admin-index .adminwarning.availableupdatesinfo
.moodleupdateinfo{line-height:1.8;margin:20px
auto;width:60%;text-align:left}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo
.info.release{margin-right:10px;padding:5px
10px;-moz-border-radius:10px;-webkit-border-radius:10px;border-radius:10px}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity50
.info.release{background-color:#ffd3d9}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity100 .info.release,
#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity150
.info.release{background-color:#f3f2aa}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity200
.info.release{background-color:#d2ebff}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo span,
#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo
a{padding-right:1em}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo
.separator{border-left:1px dotted #333}#page-admin-index .updateplugin div,
#page-admin-plugins .updateplugin
div{margin-bottom:0.5em}#page-admin-index .updateplugin .updatepluginconfirmexternal,
#page-admin-plugins .updateplugin
.updatepluginconfirmexternal{padding:1em;background-color:#ffd3d9;border:1px
solid #EAA}#page-admin-plugins
.uninstalldeleteconfirmexternal{margin:1em
auto;padding:1em;background-color:#ffd3d9;border:1px
solid #EAA}#page-admin-user-user_bulk #users
.fgroup{white-space:nowrap}#page-admin-report-stats-index
.graph{text-align:center;margin-bottom:1em}#page-admin-report-courseoverview-index
.graph{text-align:center;margin-bottom:1em}#page-admin-lang
.translator{border-width:1px;border-style:solid}#page-admin-uploaduser
table#uuresults{margin-bottom:2em}#page-admin-uploaduser table#uupreview,
#page-admin-uploaduser table#uuresults
td.cell{padding:3px}.path-admin
.roleassigntable{width:100%}.path-admin .roleassigntable
td{vertical-align:top;padding:0.2em 0.3em}.path-admin .roleassigntable
p{text-align:left;margin:0.2em 0}.path-admin .roleassigntable #existingcell,
.path-admin .roleassigntable
#potentialcell{width:42%}.path-admin .roleassigntable #existingcell label,
.path-admin .roleassigntable #potentialcell
label{font-weight:bold}.path-admin .roleassigntable
#buttonscell{width:16%}.path-admin .roleassigntable #buttonscell #add,
.path-admin .roleassigntable #buttonscell
#remove{width:100%;margin:0.3em 0;padding:0.5em 0}.path-admin .roleassigntable #buttonscell
p{margin:0.3em 0}.path-admin .roleassigntable #buttonscell
#assignoptions{font-size:0.75em}.path-admin .roleassigntable #buttonscell #assignoptions
.collapsibleregioncaption{font-weight:bold}.path-admin .roleassigntable #buttonscell
#addcontrols{margin-top:3em;height:13em}.path-admin .roleassigntable #removeselect_wrapper,
.path-admin .roleassigntable
#addselect_wrapper{width:100%}.path-admin .roleassigntable #removeselect_wrapper label,
.path-admin .roleassigntable #addselect_wrapper
label{font-weight:normal}.path-admin
table.rolecap{margin-left:auto;margin-right:auto}.path-admin table.rolecap tr.rolecap
th{text-align:left;font-weight:normal}.path-admin.dir-rtl table.rolecap tr.rolecap
th{text-align:right}.path-admin .rolecap
.hiddenrow{display:none}.path-admin .rolecap .inherit,
.path-admin .rolecap .allow,
.path-admin .rolecap .prevent,
.path-admin .rolecap
.prohibit{text-align:center}.path-admin .rolecap .cap-name,
.path-admin .rolecap
.note{display:block;padding:0
0.5em}.path-admin .rolecap
label{display:block;width:100%;min-height:2.5em}#page-admin-enrol
.enrolplugintable{width:100%}.plugincheckwrapper{width:100%}.adminsearchform{padding-top:10px}.environmentbox{margin-top:1em}#mnetconfig table,.environmenttable{margin-left:auto;margin-right:auto}.environmenttable
.cell{padding:0.15em 0.5em}.environmenttable
img.iconhelp{padding-right:0.3em}.dir-rtl .environmenttable
img.iconhelp{padding-left:0.3em;padding-right:0}#trustedhosts
.generaltable{margin-left:auto;margin-right:auto;width:500px}#trustedhosts
.standard{width:auto}.form-buttons{margin:10px
0 0 13em}#adminsettings
fieldset{margin-top:1em;padding:1em
0.5em}#adminsettings
legend{display:none}#adminsettings
fieldset.error{margin:0.2em 0 0.5em 0;padding:0.5em 0 0 0}#adminsettings fieldset.error
legend{display:block}#adminsettings .form-item{clear:both;margin:1em
0 2em 0}#adminsettings .form-item .form-label{display:block;float:left;width:12.5em;text-align:right}.dir-rtl #adminsettings .form-item .form-label{float:right}#adminsettings .form-item .form-label .form-shortname{display:block}.dir-rtl #adminsettings .form-item .form-label .form-shortname{text-align:left}#adminsettings .form-item .form-setting{display:block;margin-left:13.5em;text-align:left}.dir-rtl #adminsettings .form-item .form-setting{margin-right:13.5em;margin-left:auto;text-align:right}.dir-rtl #admin-spelllanguagelist textarea,
#page-admin-setting-editorsettingstinymce.dir-rtl .form-textarea
textarea{text-align:left;direction:ltr}#adminsettings .form-item .form-setting .form-htmlarea{width:640px;display:inline}#adminsettings .form-item .form-setting .form-htmlarea
.htmlarea{width:640px;display:block}#adminsettings .form-item .form-setting .form-multicheckbox
li{list-style:none}#adminsettings .form-item .form-setting .form-multicheckbox
ul{padding:0;margin:0}#adminsettings .form-item .form-setting
.defaultsnext{margin-right:0.5em;display:inline}#adminsettings .form-item .form-setting .locked-checkbox{margin-right:0.2em;margin-left:0.5em;display:inline}.dir-rtl #adminsettings .form-item .form-setting .locked-checkbox{margin-right:0.5em;margin-left:0.2em;display:inline}#adminsettings .form-item .form-setting .form-password .unmask,
#adminsettings .form-item .form-setting .form-defaultinfo{display:inline}#adminsettings .form-item .form-description{display:block;margin:0.5em 0 0em 14.25em;text-align:left}.dir-rtl #adminsettings .form-item .form-description{margin:0.5em 14.25em 0em 0em}#adminsettings .form-item .pathok,
#adminsettings .form-item
.patherror{margin-left:0.5em}#adminsettings #admin-emoticons table td
input{width:8em}#adminsettings #admin-emoticons table td.c0
input{width:4em}#adminsettings .form-overridden{background-color:yellow}#adminthemeselector .selectedtheme
td.c0{border:1px
solid;border-right-width:0}#adminthemeselector .selectedtheme
td.c1{border:1px
solid;border-left-width:0}.admin_colourpicker,.admin_colourpicker_preview{display:none}.jsenabled
.admin_colourpicker_preview{display:inline}.jsenabled
.admin_colourpicker{display:block;height:102px;width:410px;margin-bottom:10px}.admin_colourpicker
.loadingicon{vertical-align:middle;margin-left:auto}.admin_colourpicker
.colourdialogue{float:left;border:1px
solid #000}.admin_colourpicker
.previewcolour{border:1px
solid #000;margin-left:301px}.admin_colourpicker
.currentcolour{border:1px
solid #000;margin-left:301px;border-top-width:0}.adminsettingsflags{float:right}.dir-rtl
.adminsettingsflags{float:left}.adminsettingsflags
label{margin-right:7px}.dir-rtl .adminsettingsflags
label{margin-left:7px}.dir-rtl #adminsettings .form-item  .form-setting,
.dir-rtl #adminsettings .form-item  .form-label,
.dir-rtl #adminsettings .form-item .form-description{text-align:right}.dir-rtl.path-admin .roleassigntable
p{text-align:right}#page-admin-index
.checkforupdates{text-align:center}#page-admin-index #plugins-check-info{text-align:center;margin:1em}#page-admin-index #plugins-check
td{vertical-align:top}#page-admin-index #plugins-check{margin-left:auto;margin-right:auto}#page-admin-index #plugins-check .displayname
.pluginicon{width:16px;margin-right:5px}#page-admin-index #plugins-check .displayname
.plugindir{font-size:0.7em;color:#999}#page-admin-index #plugins-check .msg
td{text-align:center}#page-admin-index #plugins-check .status-downgrade
.status{background-color:#ffd3d9}#page-admin-index #plugins-check .status-missing
.status{background-color:#ffd3d9}#page-admin-index #plugins-check .status-new
.status{background-color:#e7f1c3}#page-admin-index #plugins-check .status-nodb .status
.statustext{color:#999}#page-admin-index #plugins-check .status-delete
.status{background-color:#d2ebff}#page-admin-index #plugins-check .status-upgrade
.status{background-color:#d2ebff}#page-admin-index #plugins-check .status-uptodate .status
.statustext{color:#999}#page-admin-index #plugins-check .status .sourcetext:after{content:" / "}#page-admin-index #plugins-check .standard .status
.sourcetext{color:#999}#page-admin-index #plugins-check .requires
ul{font-size:0.7em;margin:0}#page-admin-index #plugins-check .requires
li{display:block}#page-admin-index #plugins-check .requires-ok{color:#999}#page-admin-index #plugins-check .requires-failed{background-color:#ffd3d9}#page-admin-index #plugins-check .requires-failed .label-important{color:red}#page-admin-index #plugins-check
.pluginupdateinfo{padding:5px;margin:10px
0;background-color:#d2ebff;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px}#page-admin-index #plugins-check
.pluginupdateinfo.maturity50{background-color:#ffd3d9}#page-admin-index #plugins-check .pluginupdateinfo.maturity100,
#page-admin-index #plugins-check
.pluginupdateinfo.maturity150{background-color:#f3f2aa}#page-admin-index #plugins-check .pluginupdateinfo
.info{display:inline-block}#page-admin-index #plugins-check .pluginupdateinfo .separator:after{content:" | "}#page-admin-index
.upgradepluginsinfo{text-align:center}#page-admin-index .plugins-check-dependencies{text-align:center}#page-admin-index #plugins-check-available-dependencies{margin-left:auto;margin-right:auto}#page-admin-plugins
.checkforupdates{margin:0
auto 1em;text-align:center}#page-admin-plugins #plugins-control-panel{margin-left:auto;margin-right:auto}#page-admin-plugins #plugins-control-panel .pluginname
.pluginicon{width:16px}#page-admin-plugins #plugins-control-panel .pluginname
.componentname{font-size:0.8em;color:#999;margin-left:26px}#page-admin-plugins #plugins-control-panel
.statusmsg{background-color:#eee;padding:3px;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px}#page-admin-plugins #plugins-control-panel .status-missing
td{background-color:#ffd3d9}#page-admin-plugins #plugins-control-panel .status-missing
.statusmsg{color:#600}#page-admin-plugins #plugins-control-panel .status-new
td{background-color:#e7f1c3}#page-admin-plugins #plugins-control-panel .status-new
.statusmsg{color:#060}#page-admin-plugins #plugins-control-panel .disabled
.availability{background-color:#eee}#page-admin-plugins #plugins-control-panel .msg
td{text-align:center}#page-admin-plugins #plugins-control-panel
.requiredby{font-size:0.8em;color:#999}#page-admin-plugins #plugins-overview-panel{margin:1em
auto;text-align:center}#page-admin-plugins #plugins-overview-panel
.info{padding:5px
10px}#page-admin-plugins #plugins-control-panel .displayname
img.icon{padding-top:0;padding-bottom:0}#page-admin-plugins #plugins-control-panel .uninstall
a{color:#900}#page-admin-plugins #plugins-control-panel
.pluginupdateinfo{padding:5px;margin:10px
0;background-color:#d2ebff;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px}#page-admin-plugins #plugins-control-panel
.pluginupdateinfo.maturity50{background-color:#ffd3d9}#page-admin-plugins #plugins-control-panel .pluginupdateinfo.maturity100,
#page-admin-plugins #plugins-control-panel
.pluginupdateinfo.maturity150{background-color:#f3f2aa}#page-admin-plugins #plugins-control-panel .pluginupdateinfo
.info{display:inline-block}#page-admin-plugins #plugins-control-panel .pluginupdateinfo .separator:after{content:" | "}.dir-rtl #plugins-check
.pluginupdateinfo{text-align:center;direction:ltr}.dir-rtl #plugins-check .requires-ok{text-align:left;direction:ltr}#page-admin-mnet-peers
.box.deletedhosts{margin-bottom:1em;font-size:80%}#page-admin-mnet-peers .mform
.certdetails{background-color:white}#page-admin-mnet-peers .mform
.deletedhostinfo{background-color:#ffd3d9;border:2px
solid #eaa;padding:4px;margin-bottom:5px}#core-cache-plugin-summaries table,
#core-cache-store-summaries
table{width:100%}#core-cache-lock-summary table,
#core-cache-definition-summaries table,
#core-cache-mode-mappings
table{margin:0
auto}#core-cache-store-summaries .default-store
td{color:#333;font-style:italic}#core-cache-rescan-definitions,
#core-cache-mode-mappings .edit-link,
#core-cache-lock-summary .new-instance{margin-top:0.5em;text-align:center}#core-cache-store-summaries .store-requires-attention{background-color:#ffd3d9}.tinymcesubplugins
img.icon{padding-top:0;padding-bottom:0}.maintenancewarning{padding:3px
1em;text-align:center;position:fixed;bottom:0;right:0;overflow:hidden;z-index:1}.maintenancewarning.error{background-color:#F2DEDE;border:2px
solid #EED3D7;font-weight:bold}.maintenancewarning.warning{background-color:#ffd3d9;border:2px
solid #EED3D7}.block{border:1px
solid;margin-bottom:1em}.block .header
h2{padding: .2em 0 0 .2em;margin:0;word-wrap:break-word}.block .header
.block_action{float:right;margin:4px
0 3px 0;vertical-align:top}.block .header .block_action img,
.block .header .block_action
input{margin:0
3px;width:12px;height:12px}.block
.content{padding:4px}.jsenabled .block.hidden
.content{display:none}.block .content
.userpicture{width:16px;height:16px;margin-right:6px}.block .content .list
li.listentry{clear:both}.block .content .list
.c0{display:inline}.block .content .list
.c1{margin-left:5px;display:inline}.block
.footer{margin-bottom:4px}.block_navigation .block_tree
li{overflow:hidden}.block_calendar_upcoming
.footer{margin-top: .5em}.block.list_block .unlist>li>.column{display:inline-block}.ie6 .block.list_block .unlist
.column{display:inline}.block.beingmoved{border-width:2px;border-style:dashed}.blockmovetarget{display:block;height:1em;margin-bottom:1em;border-width:2px;border-style:dashed}.block-region block.invisible .header
h2{opacity:0.5;filter:alpha(opacity=50)}.block .block-hider-show,
.block .block-hider-hide{cursor:pointer}.block .block-hider-show,
.block.hidden .block-hider-hide{display:none}.block.hidden .block-hider-show{display:inline}.block_completionstatus
.generaltable{border:0px}.block_completionstatus .generaltable
.cell{border:0px}.block-region{min-height:400px;overflow:hidden}.editing .block .header
.commands{text-align:right;clear:both}.editing .block .header .commands>a{margin:0
3px}.editing .block .header .commands .icon
img{width:12px;height:12px}.editing .block .header .commands
img.actionmenu{width:auto}.dir-rtl .block .header
h2{padding: .2em .2em 0 0}.dir-rtl .block .header
.block_action{float:left}.dir-rtl.editing .block .header
.commands{text-align:left}.calendartable{width:100%}.calendartable th,
.calendartable
td{width:14%;vertical-align:top;text-align:center;border-width:1px}.calendar_event_course{background-color:#FFD3BD}.calendar_event_global{background-color:#D6F8CD}.calendar_event_group{background-color:#FEE7AE}.calendar_event_user{background-color:#DCE7EC}.path-calendar .calendar-controls .previous,
.path-calendar .calendar-controls .next,
.path-calendar .calendar-controls
.current{display:block;float:left;width:12%}.path-calendar .calendar-controls
.previous{text-align:left}.path-calendar .calendar-controls
.current{text-align:center;width:76%}.path-calendar .calendar-controls
.next{text-align:right}.path-calendar{}.path-calendar
.maincalendar{vertical-align:top;padding:0}.path-calendar .maincalendar
.bottom{text-align:center;padding:5px
0 0 0}.path-calendar .maincalendar
.heightcontainer{height:100%;position:relative}.path-calendar .maincalendar
.calendarmonth{width:98%;margin:10px
auto}.path-calendar .maincalendar .calendarmonth
ul{margin:0}.path-calendar .maincalendar .calendarmonth ul
li{list-style-type:none;margin-top:4px}.path-calendar .maincalendar .calendarmonth
td{height:5em}.path-calendar .maincalendar .calendar-controls .previous,
.path-calendar .maincalendar .calendar-controls
.next{width:30%}.path-calendar .maincalendar .calendar-controls
.current{width:39.95%}.path-calendar .maincalendar
.controls{width:98%;margin:10px
auto}.path-calendar .maincalendar
.eventlist{margin:0}.path-calendar .maincalendar .eventlist
.event{width:100%;margin-bottom:10px;border-spacing:0px;border-collapse:separate;border-width:1px;border-style:solid;list-style-type:none}.path-calendar .maincalendar .eventlist .event>img{float:left}.path-calendar .maincalendar .eventlist .event>img{float:right}.path-calendar .maincalendar .eventlist .event
.name{float:left;margin:0}.dir-rtl.path-calendar .maincalendar .eventlist .event
.name{float:right}.path-calendar .maincalendar .eventlist .event
.date{float:right}.dir-rtl.path-calendar .maincalendar .eventlist .event
.date{float:left}.path-calendar .maincalendar .eventlist .event
.subscription{float:left;clear:left}.dir-rtl.path-calendar .maincalendar .eventlist .event
.subscription{float:right;clear:right}.path-calendar .maincalendar .eventlist .event
.course{float:left;clear:left}.dir-rtl.path-calendar .maincalendar .eventlist .event
.course{float:right;clear:right}.path-calendar .maincalendar .eventlist .event
.side{width:32px}.path-calendar .maincalendar .eventlist .event .commands
a{margin:0
3px}.path-calendar .maincalendar .eventlist
.description{clear:both}.path-calendar .maincalendar
.header{overflow:hidden}.path-calendar .maincalendar .header
.buttons{float:right}.dir-rtl.path-calendar .maincalendar .header
.buttons{float:left}.path-calendar .filters
table{border-collapse:separate;border-spacing:2px;width:100%}#page-calendar-export
.indent{padding-left:20px}.path-calendar
div.cal_courses_flt{float:left}.dir-rtl.path-calendar
div.cal_courses_flt{float:right}.path-calendar .cal_courses_flt
label{margin-right: .45em}.dir-rtl.path-calendar .cal_courses_flt
label{margin-left: .45em;margin-right:0}.block
.minicalendar{width:100%;margin:10px
auto}.block .minicalendar th,
.block .minicalendar
td{padding:2px;font-size:0.8em}.block .minicalendar
caption{font-size:inherit;font-weight:inherit;line-height:inherit;text-align:center}.block .minicalendar
td.weekend{color:#A00}.block .calendar-controls
.previous{text-align:left;display:block;float:left;width:12%}.block .calendar-controls
.current{float:left;text-align:center;display:block;width:76%}.block .calendar-controls
.next{text-align:right;display:block;float:left;width:12%}.block .calendar_filters
ul{list-style:none;margin:0}.block .calendar_filters
li{margin-bottom: .2em}.block .calendar_filters li span
img{padding:0
.2em}.block .calendar_filters
.eventname{padding-left: .2em}.dir-rtl .block .calendar_filters
.eventname{padding-right: .2em;padding-left:0}.block .content
h3.eventskey{margin-top:0.5em}.ical-link{font-size:10px;font-weight:bold;background-color:#f60;padding:0px
5px;color:#fff;border-top:1px solid #f93;border-left:1px solid #f93;border-bottom:1px solid #013;border-right:1px solid #013;margin:3px;text-decoration:none}.ical-link:hover,.ical-link:active,.ical-link:focus,.ical-link:visited{color:#fff;text-decoration:none}.section_add_menus{text-align:right}.dir-rtl
.section_add_menus{text-align:left}.section_add_menus .horizontal div,
.section_add_menus .horizontal
form{display:inline}.section_add_menus
optgroup{font-weight:normal;font-style:italic}.section_add_menus
.urlselect{margin-left: .4em}.dir-rtl .section_add_menus
.urlselect{margin-right: .4em;margin-left:0}.section_add_menus .urlselect
select{margin-left: .2em}.dir-rtl .section_add_menus .urlselect
select{margin-right: .2em;margin-left:0}.section_add_menus .urlselect
img.iconhelp{padding:0;margin:0;vertical-align:text-bottom}.sitetopic
ul.section{margin:5px;padding:0}.course-content
ul.section{margin:1em}.sitetopic .section .activity img.activityicon,
.course-content .section .activity
img.activityicon{vertical-align:text-bottom;margin-right:3px;margin-left:3px;width:24px;height:24px}.sitetopic .section .activity .activityinstance,
.course-content .section .activity .activityinstance,
.section .activity
.activityinstance{display:inline-block}.section
.side.left{float:left}.dir-rtl .section
.side.left{float:right}.section
.side.right{float:right}.dir-rtl .section
.side.right{float:left}.section .activity
.editing_move{position:absolute;left:0;top:0}.dir-rtl .section .activity
.editing_move{left:auto;right:0}.section .activity .mod-indent-outer{display:table;padding-left:24px}.section .label .mod-indent-outer{padding-left:24px;display:block}.dir-rtl .section .activity .mod-indent-outer{padding-left:auto;padding-right:24px}.section .activity
.actions{position:absolute;right:0;top:0}.dir-rtl .section .activity
.actions{left:0;right:auto}.course-content  li.section li.activity
ul{list-style:disc}.course-content  li.section li.activity ul
ul{list-style:circle}.course-content  li.section li.activity ul ul
ul{list-style:square}.sitetopic .section .activity .activityinstance div,
.course-content .section .activity .activityinstance
div{display:inline}.course-content .section .activity .activityinstance
form{display:inline}.sitetopic .section .activity .activityinstance,
.course-content .section .activity
.activityinstance{height:2em}.editing .sitetopic .section .activity .activityinstance,
.editing .course-content .section .activity .activityinstance,
.editing .sitetopic .section .activity .contentwithoutlink,
.editing .course-content .section .activity
.contentwithoutlink{padding-right:200px}.dir-rtl.editing .sitetopic .section .activity .activityinstance,
.dir-rtl.editing .course-content .section .activity .activityinstance,
.dir-rtl.editing .sitetopic .section .activity .contentwithoutlink,
.dir-rtl.editing .course-content .section .activity
.contentwithoutlink{padding-left:200px;padding-right:initial}.sitetopic .section .activity .activityinstance,
.course-content .section .activity .activityinstance,
.sitetopic .section .activity .contentwithoutlink,
.course-content .section .activity
.contentwithoutlink{padding-right:32px;height:2em;display:table-cell}.sitetopic .section .label .activityinstance,
.course-content .section .label .activityinstance,
.sitetopic .section .label .contentwithoutlink,
.course-content .section .label
.contentwithoutlink{padding-right:32px;display:block;height:inherit}.dir-rtl .sitetopic .section .activity .activityinstance,
.dir-rtl .course-content .section .activity .activityinstance,
.dir-rtl .sitetopic .section .activity .contentwithoutlink,
.dir-rtl .course-content .section .activity
.contentwithoutlink{padding-left:32px;padding-right:initial}.sitetopic .section .activity .filler,
.course-content .section .activity
.filler{width:16px;height:16px;margin:4px;display:inline-block;vertical-align:text-bottom}.dir-rtl .sitetopic .section .activity .activityinstance,
.dir-rtl .course-content .section .activity
.activityinstance{padding-right:0;padding-left:3em}.sitetopic .section .activity .commands,
.course-content .section .activity
.commands{white-space:nowrap;display:inline-block}.section .activity .moodle-actionmenu .menu > li > *,
.section .activity .moodle-actionmenu .menubar>li>*{display:inline-block;min-height:16px}.section .activity .moodle-actionmenu[data-enhanced] .menu>li>*{display:block}.section .activity .moodle-actionmenu[data-enhanced] .menu{margin-left:-2.8em}.section .activity .moodle-actionmenu:not([data-enhanced]) .menubar > li .toggle-display{display:none}.section
img.iconsmall{vertical-align:text-bottom;width:16px;height:16px;margin:4px}.section .editing_title
img.iconsmall{width:12px;height:12px;margin:4px
8px 4px 0}.section .activity.editor_displayed a.editing_title,
.section .activity.editor_displayed .moodle-actionmenu{display:none}.single-section
h3.sectionname{text-align:center;clear:both}.sitetopic .section li.activity,
.course-content .section
li.activity{padding: .2em}.section .activity .activityinstance
.groupinglabel{padding-left: .45em}.sitetopic .section .activity .availabilityinfo,
.sitetopic .section .activity .contentafterlink,
.course-content .section .activity .availabilityinfo,
.course-content .section .activity
.contentafterlink{margin-top:0.5em}.dir-rtl .sitetopic .section .activity .availabilityinfo,
.dir-rtl .sitetopic .section .activity .contentafterlink,
.dir-rtl .course-content .section .activity .availabilityinfo,
.dir-rtl .course-content .section .activity
.contentafterlink{margin-left:0;margin-right:30px}.availabilityinfo>ul{margin-top:0}.section .activity .contentafterlink
p{margin:.5em 0}.sitetopic .section .activity:hover,
.course-content .section .activity:hover{background-color:#EEE}.course-content .section-summary{border:1px
solid #DDD;margin-top:5px;list-style:none}.course-content .section-summary .section-title{margin:2px
5px 10px 5px}.course-content .section-summary
.summarytext{margin:2px
5px 2px 5px}.course-content .section-summary .section-summary-activities .activity-count{color:#AAA;font-size:12px;margin-right:15px}.course-content .section-summary
.summary{margin-top:5px}.course-content .single-section{margin-top:1em}.course-content .single-section .section-navigation{display:block;padding:0.5em;margin-bottom:-0.5em}.course-content .single-section .section-navigation
.title{font-weight:bold;font-size:108%}.course-content .single-section .section-navigation .mdl-left{font-weight:normal;float:left;margin-right:1em}.dir-rtl .course-content .single-section .section-navigation .mdl-left{float:right}.course-content .single-section .section-navigation .mdl-left
.larrow{margin-right:0.1em}.course-content .single-section .section-navigation .mdl-right{font-weight:normal;float:right;margin-left:1em}.dir-rtl .course-content .single-section .section-navigation .mdl-right{float:left}.course-content .single-section .section-navigation .mdl-right
.rarrow{margin-left:0.1em}.course-content .single-section .section-navigation .mdl-bottom{margin-top:0}#page-site-index
.subscribelink{text-align:right}#site-news-forum h2,
#frontpage-course-list h2,
#frontpage-category-names h2,
#frontpage-category-combo
h2{margin-bottom:9px}#page-site-index
.clearfloat{float:none;clear:both;height:0px}.path-course-view a.reduce-sections{padding-left:0.2em}.path-course-view
.subscribelink{text-align:right}.path-course-view
.unread{margin-left:3em}.path-course-view .block.drag
.header{cursor:move}.path-course-view
.completionprogress{text-align:right}.dir-rtl.path-course-view
.completionprogress{text-align:left}.path-course-view .single-section
.completionprogress{margin-right:5px}.path-course-view .section
.summary{line-height:normal}.path-site li.activity > div,
.path-course-view li.activity>div{position:relative}.path-course-view li.activity form.togglecompletion
.ajaxworking{position:absolute;right:22px;width:16px;height:16px;background:url(/sunguru/theme/image.php/archaius/core/1531975376/i/ajaxloader) no-repeat}.path-course-view li.activity form.togglecompletion
div{display:inline}.dir-rtl.path-course-view li.activity form.togglecompletion,
.dir-rtl.path-course-view li.activity
span.autocompletion{left:1.7em;right:auto;padding:0px}.dir-rtl.path-course-view
.completionprogress{float:none}.dir-rtl.path-course-view li.activity form.togglecompletion
.ajaxworking{right:-22px}li.section.hidden span.commands a.editing_hide,
li.section.hidden span.commands
a.editing_show{cursor:default}.section
img.movetarget{height:16px;width:80px}.weeks-format,.topics-format{margin-top:8px;min-width:763px}#page-course-pending .singlebutton,
#page-course-index .singlebutton,
#page-course-index-category .singlebutton,
#page-course-editsection
.singlebutton{text-align:center}#coursesearch{margin-top:1em;text-align:center}#page-course-pending
.pendingcourserequests{margin-bottom:1em}#page-course-pending .pendingcourserequests
.singlebutton{display:inline}#page-course-pending .pendingcourserequests
.cell{padding:0
5px}#page-course-pending .pendingcourserequests
.cell.c6{white-space:nowrap}.coursebox{width:100%;margin-bottom:15px}.coursebox.collapsed{margin-bottom:0}.coursebox.collapsed>.content{display:none}.coursebox > .info > .coursename
a{display:block;background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/course);background-repeat:no-repeat;padding-left:21px;background-position:left top}.coursebox.remotehost .coursename
a{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/i/mnethost)}.coursebox > .info > .coursename,
.coursebox .content .teachers,
.coursebox .content .courseimage,
.coursebox .content
.coursefile{float:left;width:40%;clear:left}.coursebox .content .teachers
li{list-style-type:none;padding:0;margin:0}.coursebox
.enrolmenticons{padding:3px
0;float:right}.coursebox
.moreinfo{padding:3px
0;float:right}.coursebox .enrolmenticons img,
.coursebox .moreinfo
img{margin:0
.2em}.coursebox
.content{clear:both;overflow:hidden}.coursebox .content .summary,
.coursebox .content
.coursecat{float:right;width:55%}.coursebox .content
.coursecat{text-align:right;clear:right}.coursebox.remotecoursebox
.remotecourseinfo{float:left;width:40%}.coursebox .content .courseimage
img{max-width:100px;max-height:100px}.coursebox>.info>.coursename{margin:5px;padding:0}.coursebox .content .teachers,
.coursebox .content .coursecat,
.coursebox .content .summary,
.coursebox .content .courseimage,
.coursebox .content .coursefile,
.coursebox.remotecoursebox
.remotecourseinfo{margin:3px
5px;padding:0}.dir-rtl .coursebox > .info > .coursename
a{padding-left:0;padding-right:21px;background-position:top right}.dir-rtl .coursebox > .info > .coursename,
.dir-rtl .coursebox .teachers,
.dir-rtl .coursebox .content .courseimage,
.dir-rtl .coursebox .content
.coursefile{float:right;clear:right}.dir-rtl .coursebox .enrolmenticons,
.dir-rtl .coursebox
.moreinfo{float:left}.dir-rtl .coursebox .summary,
.dir-rtl .coursebox
.coursecat{float:left}.dir-rtl .coursebox
.coursecat{text-align:left;clear:left}.course_category_tree .category
.numberofcourse{font-size:0.85em}.dir-rtl .course_category_tree .category
.numberofcourse{padding-right:20px}.course_category_tree
.controls{visibility:hidden}.course_category_tree .controls
div{display:inline;cursor:pointer}.jsenabled .course_category_tree
.controls{visibility:visible}.course_category_tree .category>.info>.categoryname{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_empty);background-repeat:no-repeat;background-position:center left;margin:0.5em 5px}.dir-rtl .course_category_tree .category>.info>.categoryname{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_empty_rtl);background-position:center right;margin:0.5em 5px}.course_category_tree .category.with_children>.info>.categoryname{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/expanded)}.course_category_tree .category.with_children.collapsed>.info>.categoryname{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed)}.dir-rtl .course_category_tree .category.with_children.collapsed >.info
.categoryname{background-image:url(/sunguru/theme/image.php/archaius/core/1531975376/t/collapsed_rtl)}.course_category_tree .category.collapsed>.content{display:none}.course_category_tree .category>.info>.categoryname{padding:2px
18px;margin:3px}.course_category_tree .category>.content{padding-left:16px;overflow:hidden}.dir-rtl .course_category_tree .category>.content{padding-left:0;padding-right:16px}.course_category_tree .subcategories>.paging,.courses>.paging{margin:0;padding:5px;text-align:center}.courses > .paging.paging-morelink,
.course_category_tree .subcategories>.paging.paging-morelink{text-align:left}.dir-rtl .courses > .paging.paging-morelink,
.dir-rtl .course_category_tree .subcategories>.paging.paging-morelink{text-align:right}#page-course-info .generalbox.info,
#page-enrol-index
.generalbox.info{border:none}.path-course
.clearfloat{float:none;clear:both;height:0px}.section
.spinner{height:16px;width:16px}.section .activity
.spinner{margin:4px;left:100%;position:absolute}.dir-rtl .section .activity
.spinner{left:auto;right:100%}.sitetopic .section .activity form.activityinstance,
.course-content .section .activity
form.activityinstance{display:inline;vertical-align:middle}span.editinstructions{position:absolute;top:0px;margin-top:-22px;margin-left:30px;line-height:16px;font-size: .85em;padding: .1em .4em;background-color:#ffc;color:#000;text-decoration:none;z-index:9999;box-shadow:2px 2px 5px 1px #ccc;border:1px
solid #ddd}.dir-rtl
span.editinstructions{left:auto;right:32px}input.titleeditor{vertical-align:text-bottom}.editing .course-content .section .activity.editor_displayed
.activityinstance{padding-right:initial}.dir-rtl.editing .course-content .section .activity.editor_displayed
.activityinstance{padding-left:initial}#dndupload-status{width:40%;margin:0
30%;padding:6px;border:1px
solid #ddd;top:-5px;text-align:center;background:#ffc;position:absolute;left:0;box-shadow:2px 2px 5px 1px #ccc;border-radius:0px 0px 8px 8px;z-index:0}.dndupload-preview{color:#909090;border:1px
dashed #909090;list-style:none;margin-top: .2em;padding: .3em;line-height:16px}.dndupload-preview
img.icon{vertical-align:text-bottom;padding:0}.dndupload-progress-outer{width:70px;border:1px
solid black;border-radius:4px;height:10px;display:inline-block;margin:0;padding:0;overflow:hidden;position:relative}.dndupload-progress-inner{width:0%;height:100%;background-color:green;display:inline-block;margin:0;padding:0;float:left;box-shadow:0 0 4px #229b15;border-radius:2px;background-repeat:repeat-x;background-position:top;background-image:url(/sunguru/theme/image.php/archaius/theme_base/1531975376/progress)}.dndupload-hidden{display:none}#course-category-listings{background-color:#fff;border:1px
solid #e1e1e8;margin-bottom:200px}#course-category-listings.columns-2>#category-listing>div{border-right:1px solid #e1e1e8}.dir-rtl #course-category-listings.columns-2>#category-listing>div{border-left:1px solid #e1e1e8;border-right:0}#course-category-listings.columns-2>#course-listing>div{border-left:1px solid #e1e1e8;margin-left:-1px}#course-category-listings.columns-2.viewmode-courses.course-selected>#course-listing>div{border-right:1px solid #e1e1e8;margin-right:-1px}#course-category-listings.columns-2>#course-detail>div{border-left:1px solid #e1e1e8}#course-category-listings.columns-3 #category-listing>div{border-right:1px solid #DDD}#course-category-listings.columns-3 #course-listing>div{border-right:1px solid #e1e1e8;border-left:1px solid #e1e1e8;margin-right:-1px;margin-left:-1px}#course-category-listings.columns-3 #course-detail>div{border-left:1px solid #DDD}#course-category-listings>div{}#course-category-listings>div>div{min-height:300px}#course-category-listings
h3{margin:0;padding:0.6em 1em 0.5em;text-align:left;background-color:#f7f7f9;border-bottom:1px solid #e1e1e8}#course-category-listings
h4{margin:1em
0 0;padding:0.6em 1em 0.5em;text-align:left}.dir-rtl #course-category-listings h3,
.dir-rtl #course-category-listings
h4{text-align:right}.coursecat-management-header .moodle-actionmenu,
#course-category-listings .moodle-actionmenu{white-space:nowrap}#course-category-listings .listing-actions{text-align:center;padding:0.4em 0.3em 0.3em}#course-category-listings .listing-actions>*{display:inline-block;line-height:2.2em}#course-category-listings .listing-actions>.moodle-actionmenu{display:inline-block}.coursecat-management-header .moodle-actionmenu[data-enhanced].show .menu a,
#course-category-listings .listing-actions > .moodle-actionmenu .menu
a{padding:4px
1em}#course-category-listings .listing-actions
.iconsmall{margin-left:0.5em}#course-category-listings
ul.ml{list-style:none;margin:1em
0}#course-category-listings ul.ml
ul.ml{margin:0}#course-category-listings
li{line-height:2.2em}#course-category-listings li>div{border-bottom:1px solid #fff;border-top:1px solid #fff}#course-category-listings li>div:hover{background-color:#fafafa}#course-category-listings
li.highlight{background-color:transparent}#course-category-listings li.highlight > div,
#category-listing li.highlight.listitem > div > .ba-checkbox,
#course-category-listings li.highlight > div:hover,
#course-category-listings li[data-selected='1'].highlight>div{background-color:#dfa}#course-category-listings li+li > div,
#course-category-listings li:first-child>div{border-top-color:#f7f7f9}#course-category-listings li .tree-icon{margin-right:0.5em;width:12px;height:12px}.dir-rtl #course-category-listings li .tree-icon{margin-left:0.5em}#course-category-listings li[data-selected='1']>div{background-color:#FFFFD8;border-top-color:#e1e1e8;border-bottom-color:#f7f7f9}#course-category-listings li[data-selected='1'] li:first-of-type > div,
#course-category-listings li[data-selected='1'][data-expandable='0']+li>div{border-top-color:#e1e1e8}#course-category-listings li[data-selected='1']:last-of-type>div{border-bottom-color:#e1e1e8}#course-category-listings>div>div>ul.ml>li:first-child>div{border-top:0}#course-category-listings .moodle-actionmenu.show .menu
li{line-height:20px}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) li{line-height:normal}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) > .menubar li,
#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) > .menubar a,
#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) > .menu .menu-action-text{display:inline-block}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) > .menubar
a{color:inherit}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) > .menubar a > img,
#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) > .menubar
.caret{display:none}.jsenabled #course-category-listings .moodle-actionmenu[data-enhance] .toggle-display
img{width:auto}.jsenabled #course-category-listings .moodle-actionmenu[data-enhance] .toggle-display.textmenu{padding-right:4px}.jsenabled #course-category-listings .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{vertical-align:text-top}#course-category-listings .item-actions{margin-right:1em;display:inline-block;display:initial}#course-category-listings .item-actions .menubar img,
#course-category-listings .item-actions > a
img{margin:0
4px;vertical-align:inherit}#course-category-listings .item-actions .menu
img{max-width:none;width:12px}#course-category-listings li .tree-icon{margin-left:0}#course-category-listings li li .tree-icon{margin-left:1em}#course-category-listings li li li .tree-icon{margin-left:2em}#course-category-listings li li li li .tree-icon{margin-left:3em}#course-category-listings li li li li li .tree-icon{margin-left:4em}#course-category-listings li li li li li li .tree-icon{margin-left:4.5em}#course-category-listings li li li li li li li .tree-icon{margin-left:5em}#course-category-listings li li li li li li li li .tree-icon{margin-left:5.5em}.dir-rtl #course-category-listings li .tree-icon{margin-right:0;margin-left:0.5em}.dir-rtl #course-category-listings li li .tree-icon{margin-right:1em}.dir-rtl #course-category-listings li li li .tree-icon{margin-right:2em}.dir-rtl #course-category-listings li li li li .tree-icon{margin-right:3em}.dir-rtl #course-category-listings li li li li li .tree-icon{margin-right:4em}.dir-rtl #course-category-listings li li li li li li .tree-icon{margin-right:4.5em}.dir-rtl #course-category-listings li li li li li li li .tree-icon{margin-right:5em}.dir-rtl #course-category-listings li li li li li li li li .tree-icon{margin-right:5.5em}#course-listing .listitem .drag-handle{display:none}.jsenabled #course-listing .listitem .drag-handle{margin-right:0.5em;display:inline-block;cursor:pointer}#course-listing .listitem
.categoryname{display:inline-block;margin-left:1em;color:#a1a1a8}#course-listing .listitem
.coursename{display:inline-block}#category-listing .course-count{color:#a1a1a8;margin-right:2em;min-width:3.5em;display:inline-block}#category-listing .listitem.collapsed>ul.ml{display:none}#category-listing .course-count
.smallicon{width:0.8em;height:0.8em;margin:0
0.3em}.dir-rtl #category-listing .course-count{margin-left:2em;margin-right:0}#category-listing .listitem>div>.ba-checkbox{vertical-align:middle;width:2.2em;text-align:center;margin:-1px 0;padding-top:2px;margin-right:0.5em}.dir-rtl #category-listing .listitem>div>.ba-checkbox{margin-left:0.5em;margin-right:0.5em}#category-listing .listitem[data-selected='1']>div>.ba-checkbox{margin:0
0.5em 0 0;padding:0}.dir-rtl #category-listing .listitem[data-selected='1']>div>.ba-checkbox{margin-left:0.5em}.category-bulk-actions{margin:0
0.5em 0.5em}#course-category-listings .listitem
.idnumber{color:#a1a1a8;margin-right:2em}#course-category-listings .listitem>div>.float-left{float:left}#course-category-listings .listitem>div>.float-right{float:right;text-align:right}.dir-rtl #course-category-listings .listitem>div>.float-left{float:right}.dir-rtl #course-category-listings .listitem>div>.float-right{float:left;text-align:left}#course-category-listings .listitem[data-visible="0"],
#course-category-listings .listitem[data-visible="0"]>div>a{color:#AAA}#course-category-listings .listitem > div .item-actions .action-hide,
#course-category-listings .listitem[data-visible="0"] > div .item-actions .action-show{display:inline}#course-category-listings .listitem > div .item-actions .action-show,
#course-category-listings .listitem[data-visible="0"] > div .item-actions .action-hide,
#category-listing .listitem:first-child > div .item-actions .action-moveup,
#category-listing .listitem:last-child > div .item-actions .action-movedown,
#course-listing > .firstpage .listitem:first-child > div .item-actions .action-moveup,
#course-listing > .lastpage .listitem:last-child > div .item-actions .action-movedown{display:none}#course-category-listings .listitem > div a.without-actions{color:#333}#course-listing li>div{padding-left:1em}#course-category-listings .detail-pair{border-bottom:1px solid #e1e1e8;margin:0
1em}#course-category-listings .detail-pair>*{display:inline-block;line-height:2.2em}#course-category-listings .detail-pair .pair-key{font-weight:bold;text-align:left}.dir-rtl #course-category-listings .detail-pair .pair-key{text-align:right}#course-category-listings .detail-pair .pair-key
span{margin-right:1em;display:block}.dir-rtl #course-category-listings .detail-pair .pair-key
span{margin-right:0}#course-category-listings .detail-pair:last-child{border-bottom-width:0}#course-category-listings .bulk-actions .detail-pair>*{display:block;width:100%}#course-category-listings .bulk-actions .detail-pair .pair-value{margin-left:2.2em}.dir-rtl #course-category-listings .bulk-actions .detail-pair .pair-value{margin-left:0;margin-right:2.2em}#course-category-listings .select-a-category .notifymessage,
#course-category-listings .select-a-category
.alert{margin:1em}.dir-rtl.jsenabled .moodle-actionmenu[data-enhanced] .menu.align-tr-br{right:inherit}.coursecat-management-header{vertical-align:middle}.coursecat-management-header
h2{display:inline-block;text-align:left}.coursecat-management-header>div{display:inline-block;float:right}.coursecat-management-header>div>div{display:inline-block;margin-left:1em}.dir-rtl .coursecat-management-header
h2{text-align:right}.dir-rtl .coursecat-management-header>div{float:left;margin-right:1em;margin-left:0}.coursecat-management-header .view-mode-selector .moodle-actionmenu{display:inline-block}.coursecat-management-header .view-mode-selector
img{margin-left:0.5em;vertical-align:baseline}.coursecat-management-header
select{max-width:300px;white-space:nowrap}.listing-pagination,.listing-pagination-totals{text-align:center}.listing-pagination .yui3-button{background-color:#FFF;border:0;margin:0.4em 0.2em 0.45em;font-size:10.4px}.listing-pagination .yui3-button.active-page{background-color:#E5EFFD}.listing-pagination-totals.dimmed{color:#999;margin:0.4em 1em 0.45em}#category-listing .bulk-action-checkbox{vertical-align:middle;margin:0
0 0.5em 3px}.dir-rtl #category-listing .bulk-action-checkbox{vertical-align:middle;margin:0
3px 0.5em 0}#course-listing .bulk-action-checkbox{margin-right:0.6em;vertical-align:middle;margin-bottom:0.5em}@media (min-width: 1200px) and (max-width: 1600px){#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-3 #category-listing,
#course-category-listings.columns-3 #course-listing{width:50%}#course-category-listings.columns-3 #category-listing > div,
#course-category-listings.columns-3 #course-listing > div,
#course-category-listings.columns-3 #course-detail{border:1px
solid #e1e1e8;background-color:#FFF}#course-category-listings.columns-3 #course-detail>div{border:0}#course-category-listings.columns-3 #course-detail{width:100%;margin-top:1em}}@media (max-width: 1199px){#course-category-listings.columns-2,#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-2 #category-listing,
#course-category-listings.columns-2 #course-listing,
#course-category-listings.columns-2 #course-detail,
#course-category-listings.columns-3 #category-listing,
#course-category-listings.columns-3 #course-listing,
#course-category-listings.columns-3 #course-detail{width:100%;margin-bottom:1em}#course-category-listings.columns-2 #category-listing > div,
#course-category-listings.columns-2 #course-listing > div,
#course-category-listings.columns-2 #course-detail > div,
#course-category-listings.columns-3 #category-listing > div,
#course-category-listings.columns-3 #course-listing > div,
#course-category-listings.columns-3 #course-detail>div{border:1px
solid #e1e1e8;background-color:#FFF}}.grid-col{display:inline-block;zoom:1;*display:inline;letter-spacing:normal;word-spacing:normal;vertical-align:top;text-rendering:auto}.grid-col-1{display:block}.grid-col-1-2{width:50%}.grid-col-1-3{width:33.33333%}.grid-col-2-3{width:66.66667%}.grid-col-1-4{width:25%}.grid-col-3-4{width:75%}.grid-col-1-5{width:20%}.grid-col-2-5{width:40%}.grid-col-3-5{width:60%}.grid-col-4-5{width:80%}.grid-col-1-6{width:16.66667%}.grid-col-5-6{width:83.33333%}.grid-col-1-7{width:14.28571%}.grid-col-2-7{width:28.57143%}.grid-col-3-7{width:42.85714%}.grid-col-4-7{width:57.14286%}.grid-col-5-7{width:71.42857%}.grid-col-6-7{width:85.71429%}.grid-col-1-8{width:12.5%}.grid-col-3-8{width:37.5%}.grid-col-5-8{width:62.5%}.grid-col-7-8{width:87.5%}.grid-col-1-9{width:11.11111%}.grid-col-2-9{width:22.22222%}.grid-col-4-9{width:44.44444%}.grid-col-5-9{width:55.55556%}.grid-col-6-9{width:66.66667%}.grid-col-7-9{width:77.77778%}.grid-col-8-9{width:88.88889%}.grid-col-1-10{width:10%}.grid-col-3-10{width:30%}.grid-col-7-10{width:70%}.grid-col-9-10{width:90%}.grid-col-1-11{width:9.09091%}.grid-col-2-11{width:18.18182%}.grid-col-3-11{width:27.27273%}.grid-col-4-11{width:36.36364%}.grid-col-5-11{width:45.45455%}.grid-col-6-11{width:54.54545%}.grid-col-7-11{width:63.63636%}.grid-col-8-11{width:72.72727%}.grid-col-9-11{width:81.81818%}.grid-col-10-11{width:90.90909%}.grid-col-1-12{width:8.33333%}.grid-col-5-12{width:41.66667%}.grid-col-7-12{width:58.33333%}.grid-col-9-12{width:75%}.grid-col-11-12{width:91.66667%}.grid-row-r{letter-spacing:-0.31em;*letter-spacing:normal;word-spacing:-0.43em}.opera-only :-o-prefocus,.grid-row-r{word-spacing:-0.43em}.grid-row-r
img{max-width:100%}@media (min-width:980px){.grid-visible-phone{display:none}.grid-visible-tablet{display:none}.grid-visible-desktop{}.grid-hidden-phone{}.grid-hidden-tablet{}.grid-hidden-desktop{display:none}}@media (max-width:480px){.grid-row-r > [class ^= "grid-col"]{width:100%}}@media (max-width:767px){.grid-row-r > [class ^= "grid-col"]{width:100%}.grid-visible-phone{}.grid-hidden-phone{display:none}.grid-hidden-desktop{}.grid-visible-desktop{display:none}}@media (min-width:768px) and (max-width:979px){.grid-visible-tablet{}.grid-hidden-tablet{display:none}.grid-hidden-desktop{}.grid-visible-desktop{display:none}}.allcoursegrades{width:100%;text-align:right;padding:4px
0px 5px 0px}.core_grades_notices
.singlebutton{display:inline-block}.path-grade-edit
.buttons{text-align:center}.path-grade-edit-tree
.idnumber{margin-left:15px}.path-grade-edit-tree
.movetarget{position:relative;width:80px;height:16px}.path-grade-edit-tree .setup-grades{width:100%}.path-grade-edit-tree .setup-grades thead
th{text-align:left}.path-grade-edit-tree .setup-grades .column-rowspan{padding:0;width:24px;min-width:24px;max-width:24px}.path-grade-edit-tree .setup-grades .category td.column-name{padding-left:0}.path-grade-edit-tree .setup-grades td.column-name{padding-left:24px}.path-grade-edit-tree .setup-grades .column-name h4
img.icon{padding-left:0}.path-grade-edit-tree .setup-grades .column-name
img.smallicon{margin:0
.3em}.path-grade-edit-tree .setup-grades .category input[type="text"],
.path-grade-edit-tree .setup-grades .category .column-range,
.path-grade-edit-tree .setup-grades .categoryitem,
.path-grade-edit-tree .setup-grades
.courseitem{font-weight:bold}.path-grade-edit-tree .setup-grades
.emptyrow{display:none}.path-grade-edit-tree .setup-grades.generaltable
.levelodd{background-color:#f0f0f0}.path-grade-edit-tree .setup-grades.generaltable
.leveleven{background-color:#fafafa}.path-grade-edit-tree .setup-grades .column-weight.level3{padding-left:37px}.path-grade-edit-tree .setup-grades .column-weight.level4{padding-left:66px}.path-grade-edit-tree .setup-grades .column-weight.level5{padding-left:95px}.path-grade-edit-tree .setup-grades .column-weight.level6{padding-left:124px}.path-grade-edit-tree .setup-grades .column-weight.level7{padding-left:153px}.path-grade-edit-tree .setup-grades .column-weight.level8{padding-left:182px}.path-grade-edit-tree .setup-grades .column-weight.level9{padding-left:211px}.path-grade-edit-tree .setup-grades .column-weight.level10{padding-left:240px}.path-grade-edit-tree .setup-grades .column-range.level2{padding-left:37px}.path-grade-edit-tree .setup-grades .column-range.level3{padding-left:66px}.path-grade-edit-tree .setup-grades .column-range.level4{padding-left:95px}.path-grade-edit-tree .setup-grades .column-range.level5{padding-left:124px}.path-grade-edit-tree .setup-grades .column-range.level6{padding-left:153px}.path-grade-edit-tree .setup-grades .column-range.level7{padding-left:182px}.path-grade-edit-tree .setup-grades .column-range.level8{padding-left:211px}.path-grade-edit-tree .setup-grades .column-range.level9{padding-left:240px}.path-grade-edit-tree .setup-grades .column-range.level10{padding-left:269px}.dir-rtl.path-grade-edit-tree .setup-grades thead
th{text-align:right}.dir-rtl.path-grade-edit-tree .setup-grades .category td.column-name{padding-right:0}.dir-rtl.path-grade-edit-tree .setup-grades td.column-name{padding-right:24px}.dir-rtl.path-grade-edit-tree .setup-grades .column-name h4
img.icon{padding-left:4px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight input[type="checkbox"]{margin-right:0;margin-left:7px}.dir-rtl.path-grade-edit-tree .setup-grades .column-select input[type="checkbox"]{margin-right:0}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level3{padding-left:0;padding-right:37px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level4{padding-left:0;padding-right:66px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level5{padding-left:0;padding-right:95px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level6{padding-left:0;padding-right:124px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level7{padding-left:0;padding-right:153px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level8{padding-left:0;padding-right:182px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level9{padding-left:0;padding-right:211px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level10{padding-left:0;padding-right:240px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level2{padding-left:0;padding-right:37px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level3{padding-left:0;padding-right:66px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level4{padding-left:0;padding-right:95px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level5{padding-left:0;padding-right:124px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level6{padding-left:0;padding-right:153px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level7{padding-left:0;padding-right:182px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level8{padding-left:0;padding-right:211px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level9{padding-left:0;padding-right:240px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level10{padding-left:0;padding-right:269px}#grade-report-toggles{text-align:center}#grade-aggregation-help
dt{margin-top:15px}#grade-aggregation-help
dd.example{margin-top:7px}#grade-aggregation-help
code{display:block;margin-top:7px}.gradeexportlink{padding:2em;text-align:center}.gradetreebox{margin-top:10px;overflow-x:auto;overflow-y:hidden}.gradetreebox
#gradetreesubmit{margin-bottom:1em;text-align:center}#page-grade-grading-manage
#activemethodselector{text-align:center;margin-bottom:1em}#page-grade-grading-manage #activemethodselector
select{margin:0px
1em}#page-grade-grading-manage
.actions{text-align:center}#page-grade-grading-manage
.action{display:inline-block;width:150px;background-color:#EEE;border:2px
solid #CCC;margin:0.5em;padding:0.5em;text-align:center;-moz-border-radius:5px}#page-grade-grading-manage .action:hover{text-decoration:none;background-color:#F6F6F6}#page-grade-grading-manage
#actionresultmessagebox{background-color:#D2EBFF;width:60%;margin:1em
auto 1em auto;text-align:center;padding:0.5em;border:2px
solid #CCC;-moz-border-radius:5px;position:relative}#page-grade-grading-manage #actionresultmessagebox
span{position:absolute;right:0px;top:-1.2em;color:#666;font-size:80%}#page-grade-grading-manage .definition-name
.status{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE;-moz-border-radius:5px}#page-grade-grading-manage .definition-name
.status.ready{background-color:#e7f1c3;border-color:#AEA}#page-grade-grading-manage .definition-name
.status.draft{background-color:#f3f2aa;border-color:#EE2}#page-grade-grading-manage .definition-preview{width:50%;margin:1em
auto;border:1px
solid #EEE;padding:1em}#page-grade-grading-pick
.templatesearchform{}#page-grade-grading-pick .template-name{clear:both;padding:3px;background-color:#F6F6F6}#page-grade-grading-pick .template-name
.type{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE;-moz-border-radius:5px}#page-grade-grading-pick .template-name
.type.shared{background-color:#e7f1c3;border-color:#AEA}#page-grade-grading-pick .template-name
.type.ownform{background-color:#d2ebff;border-color:#ACE}#page-grade-grading-pick .template-description{margin-bottom:1em;padding:0px
2em 0px 0px;margin-right:51%}#page-grade-grading-pick .template-preview{width:50%;float:right;border:1px
solid #EEE;padding:1em;margin-bottom:1em}#page-grade-grading-pick .template-actions{margin-bottom:1em;padding:0px
2em 0px 0px;margin-right:51%}#page-grade-grading-pick .template-actions
.action{display:inline-block;margin:0.25em;padding:0.25em;border:2px
solid transparent}#page-grade-grading-pick .template-actions
.action.pick{background-color:#EEE;border:2px
solid #CCC;-moz-border-radius:3px}#page-grade-grading-pick .template-actions .action:hover{text-decoration:none;background-color:#F6F6F6;border:2px
solid #CCC;-moz-border-radius:3px}#page-grade-grading-pick .template-actions .action .action-text{display:inline}#page-grade-grading-pick .template-actions .action .action-icon{margin:0px
3px}#page-grade-grading-pick .template-preview-confirm{width:50%;margin:1em
auto;border:1px
solid #EEE;padding:1em}#page-grade-grading-pick .singlebutton,
.path-grade-report-user
h2{clear:both}#page-grade-edit-outcome-course
.courseoutcomes{margin-left:auto;margin-right:auto;width:100%}#page-grade-edit-outcome-course .courseoutcomes
td{text-align:center}.path-grade-edit-tree table.setup-grades .column-weight{white-space:nowrap}.path-grade-edit-tree table.setup-grades
.gradeitemdescription{padding-left:24px;font-weight:normal}.path-grade-report-user .user-grade{border-color:black}.path-grade-report-user .user-grade.generaltable
.levelodd{background-color:#f0f0f0}.path-grade-report-user .user-grade.generaltable
.leveleven{background-color:#fafafa}.has_dock.path-grade-report-grader .gradeparent .sideonly.floating > .cell,
.has_dock.path-grade-report-grader .gradeparent .sideonly.floating > .cell,
.has_dock.path-grade-report-grader .gradeparent .sideonly.floating>.cell{padding-left:35px}.path-grade-report-grader .gradeparent
.clickable{cursor:pointer}.dir-rtl.has_dock.path-grade-report-grader .gradeparent .sideonly.floating > .cell,
.dir-rtl.has_dock.path-grade-report-grader .gradeparent .sideonly.floating > .cell,
.dir-rtl.has_dock.path-grade-report-grader .gradeparent .sideonly.floating>.cell{padding-left:5px;padding-right:35px}.content-only.path-grade-report-grader .gradeparent
table{margin-left:30px}.dir-rtl.content-only.path-grade-report-grader .gradeparent
table{margin-left:0;margin-right:30px}.message-discussion-noframes
h1{font-size:1em}.message-discussion-noframes #userinfo
.commands{font-size:0.8em}.message
.noframesjslink{font-size:0.8em}.message
.link{font-size:0.8em}.message
.heading{font-size:1.0em;font-weight:bold;clear:both}.message
.author{font-weight:bold}.message
.time{font-style:italic}.message
.text{}#page-message-user .commands
span{font-size:0.7em}#page-message-user
.name{font-weight:bold;font-size:1.1em}table.message_search_results
td{border-color:#DDD}.message
.time{color:#999}.message.me
.author{color:#999}.message.other
.author{color:#88C}#page-message-messages{padding:10px}#page-message-send
.notifysuccess{padding:1px}#page-message-send
td.fixeditor{text-align:center}.message
.note{padding:10px}table.message .searchresults
td{padding:5px}.message
.contactselector{width:24%;float:left}.dir-rtl .message
.contactselector{float:right}.message .contactselector
.paging{z-index:1;position:relative}.message .message-contacts{list-style-type:none;margin:0}.message .message-contacts
li{clear:both;position:relative}.message .message-contacts li
.pix{left:0;position:absolute}.dir-rtl .message .message-contacts li
.pix{left:auto;right:0}.message .message-contacts li
.contact{margin:0
24% 0 25px;text-align:left}.dir-rtl .message .message-contacts li
.contact{text-align:right;margin:0
25px 0 24%}.message .message-contacts li
.contact.nolinks{margin-right:5px}.dir-rtl .message .message-contacts li
.contact.nolinks{margin-left:5px;margin-right:25px}.message .message-contacts li
.link{float:right;max-width:30%}.dir-rtl .message .message-contacts li
.link{float:left}.message
.messagearea{padding-left:1%;border-left:1px solid LightGrey;width:74%;float:right;min-height:200px}.message .messagearea
.messagehistorytype{clear:both;padding-bottom:20px}.message .messagearea .messagehistory
.user{vertical-align:top;width:32%;min-width:100px;float:left}.message .messagearea .messagehistory .user:first-child{margin-left:13%}.message .messagearea .messagehistory .user:last-child{margin-right:13%}.dir-rtl .message .messagearea .messagehistory .user:first-child{margin-right:13%;margin-left:0}.dir-rtl .message .messagearea .messagehistory .user:last-child{margin-left:13%;margin-right:0}.message .messagearea .messagehistory .user>div{text-align:center;border:none}.message .messagearea .messagehistory
.between{float:left;width:16px;margin:0
3%;padding-top:40px}.dir-rtl .message .messagearea .messagehistory .between,
.dir-rtl .message .messagearea .messagehistory
.user{float:right}.message .messagearea .messagehistory .heading,
.message .messagearea .messagehistory
h3{width:100%;clear:both}.message .messagearea .messagehistory
.left{position:relative;margin-bottom:10px;width:50%;float:left;clear:both}.dir-rtl .message .messagearea .messagehistory
.left{float:right}.message .messagearea .messagehistory
.right{position:relative;margin-bottom:10px;width:50%;float:right;clear:both}.dir-rtl .message .messagearea .messagehistory
.right{float:left}.dir-ltr .message .messagearea .messagehistory
.message{margin-right:20px}.dir-ltr .message .messagearea .messagehistory .right
.message{margin-left:20px}.dir-rtl .message .messagearea .messagehistory
.message{margin-left:20px}.dir-rtl .message .messagearea .messagehistory .right
.message{margin-right:20px}.message .messagearea .messagehistory
.messageactive{background-color:#F5F5F5}.message .messagearea .messagehistory .messagecontent
.deleteicon{width:20px;position:absolute;top:-2px}.dir-ltr .message .messagearea .messagehistory .messagecontent
.deleteicon{right:0}.dir-rtl .message .messagearea .messagehistory .messagecontent
.deleteicon{left:0}.message .messagearea .messagehistory
.notification{padding:10px;background-color:#EEE;margin-top:5px}.message .messagearea
.messagesend{padding-top:20px;clear:both}.message .messagearea .messagesend
.messagesendbox{width:100%}.message .messagearea .messagesend
fieldset{padding:0px;margin:0}.message .messagearea
.messagerecent{text-align:left;width:100%}.message .messagearea .messagerecent
.singlemessage{border-bottom:1px solid #D3D3D3;padding:10px}.message .messagearea .messagerecent .singlemessage .otheruser
span{padding:5px}.message .messagearea .messagerecent .singlemessage
.messagedate{float:right}.message
.hiddenelement{display:none}.message
.visible{display:inline}.message #usergroupselector.fieldset, .message
#viewing{width:100%}.messagesearchresults{margin-bottom:40px}.messagesearchresults
td{padding:0px
10px 0px 20px}.messagesearchresults td
span{white-space:nowrap}.messagesearchresults td
img.userpicture{padding-right: .45em;vertical-align:text-bottom}.dir-rtl .messagesearchresults td
img.userpicture{padding-left: .45em;padding-right:0}.messagesearchresults td span
img{padding:0
0 0 .45em;vertical-align:text-bottom}.dir-rtl .messagesearchresults td span
img{padding:0
.45em 0 0}#newmessageoverlay{background-color:LightGrey;border:1px
solid black;padding:20px;position:fixed;bottom:0;right:0}#newmessageoverlay
#usermessage{padding:10px}.ie6
#newmessageoverlay{position:static}.core_message-messenger-sendmessage-hidden{display:none}.core_message-messenger-sendmessage
.message.actions{position:relative}.core_message-messenger-sendmessage .message-area{height:240px;max-height:100%;position:relative;margin-bottom:10px}.core_message-messenger-sendmessage .message-input{width:100%;height:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.core_message-messenger-sendmessage .message-send{margin:0;float:right}.core_message-messenger-sendmessage .message-notice-area{display:table;position:absolute;top:0;left:0;bottom:0;right:0;width:100%;height:100%}.core_message-messenger-sendmessage .message-notice{display:table-cell;vertical-align:middle;text-align:center}.core_message-messenger-sendmessage .message-notice>div{background:#eee;padding:5px;font-size:12px}.core_message-messenger-sendmessage .message-footer{margin-top:3px;line-height:20px}.core_message-messenger-sendmessage .message-history{position:absolute;bottom:0}.dir-rtl .core_message-messenger-sendmessage .message-send{float:left}.questionbank
h2{margin-top:0}.questioncategories
h3{margin-top:0}#chooseqtypebox{margin-top:1em}#chooseqtype
h3{margin:0
0 0.3em}#chooseqtype
.instruction{display:none}#chooseqtype
.fakeqtypes{border-top:1px solid silver}#chooseqtype
.qtypeoption{margin-bottom:0.5em}#chooseqtype
label{display:block}#chooseqtype .qtypename
img{padding:0
0.3em}#chooseqtype
.qtypesummary{display:block;margin:0
2em}#chooseqtype
.submitbuttons{margin:0.7em 0;text-align:center}#qtypechoicecontainer{display:none}#qtypechoicecontainer_c.yui-panel-container.shadow
.underlay{background:none}#qtypechoicecontainer.yui-panel
.hd{color:#333;letter-spacing:1px;text-shadow:1px 1px 1px #FFF;border-radius:10px 10px 0 0;border:1px
solid #CCC;border-bottom:1px solid #BBB;background:-webkit-gradient(linear, left top, left bottom,from(#FFFFFF),to(#CCCCCC));background:-moz-linear-gradient(top,#FFFFFF,#CCCCCC)}#qtypechoicecontainer{font-size:12px;color:#333;background:#F2F2F2;border-radius:10px;border:1px
solid #CCC;border-top:0 none;-webkit-box-shadow:5px 5px 20px 0px #666;-moz-box-shadow:5px 5px 20px 0px #666;box-shadow:5px 5px 20px 0px #666}#qtypechoicecontainer
#chooseqtype{width:35em}#qtypechoicecontainer #chooseqtypehead
h3{margin:0;font-weight:normal}#qtypechoicecontainer #chooseqtype
.qtypes{position:relative;border-bottom:1px solid #BBB;padding:0.24em 0}#qtypechoicecontainer #chooseqtype
.alloptions{overflow-x:hidden;overflow-y:auto;max-height:400px;max-height:calc(100vh - 8em);width:60%}#qtypechoicecontainer #chooseqtype
.qtypeoption{margin-bottom:0;padding:0.3em 0 0.3em 1.6em}#qtypechoicecontainer #chooseqtype .qtypeoption
img{vertical-align:text-bottom;padding-left:1em;padding-right:0.5em}#qtypechoicecontainer #chooseqtype
.selected{background-color:#FFF;box-shadow:0px 0px 10px 0px #CCC;-webkit-box-shadow:0px 0px 10px 0px #CCC;-moz-box-shadow:0px 0px 10px 0px #CCC}#qtypechoicecontainer #chooseqtype .instruction,
#qtypechoicecontainer #chooseqtype
.qtypesummary{display:none;position:absolute;top:0;right:0;left:60%;margin:0;bottom:0;overflow-x:hidden;overflow-y:auto;padding:1.5em 1.6em;background-color:#FFF}#qtypechoicecontainer #chooseqtype .instruction,
#qtypechoicecontainer #chooseqtype .selected
.qtypesummary{display:block}#categoryquestions{margin:0}#categoryquestions td,
#categoryquestions
th{padding:0
0.2em}#categoryquestions
th{text-align:left;font-weight:normal}.dir-rtl #categoryquestions
th{text-align:right}.questionbank
.singleselect{margin:0}#page-question-addquestion #chooserdialogue,
#page-question-addquestion
#choosertitle{display:block}#combinedfeedbackhdr
div.fhtmleditor{padding:0}#combinedfeedbackhdr
div.fcheckbox{margin-bottom:1em}#multitriesheader
div.fitem_feditor{margin-top:1em}#multitriesheader
div.fitem_fgroup{margin-bottom:1em}#multitriesheader div.fitem_fgroup fieldset.felement
label{margin-left:0.3em;margin-right:0.3em}body.path-question-type .fitem_fgroup
.accesshide{font:inherit;left:0;position:static;padding-right:.3em}.que{clear:left;text-align:left;margin:0
auto 1.8em auto}.dir-rtl
.que{text-align:right}.que
.info{float:left;width:7em;padding:0.5em;margin-bottom:1.8em;background:#eee}.que
h3.no{margin:0;font-size:0.8em;line-height:1}.que
span.qno{font-size:1.5em;font-weight:bold}.que .info>div{font-size:0.8em;margin-top:0.7em}.que .info
.questionflag.editable{cursor:pointer}.que .info .editquestion img,
.que .info .questionflag img,
.que .info .questionflag
input{vertical-align:bottom}.que
.content{margin:0
0 0 8.5em}.que .formulation,
.que .outcome,
.que .comment,
.que
.history{padding:0.5em;margin:0
0 0.5em}.que
.formulation{background:#e4f1fa}.que
.outcome{background:#fff3bf}.que
.comment{background:#e0ffe0}.que
.history{background:#eee}.que
.ablock{margin:0.7em 0 0.3em 0}.que .im-controls{margin-top:0.5em;text-align:left}.dir-rtl .que .im-controls{text-align:right}.que .specificfeedback,
.que .generalfeedback,
.que .rightanswer,
.que .im-feedback,
.que .feedback,
.que
p{margin:0
0 0.5em}.que
.qtext{margin-bottom:1.5em}.que
.correct{background-color:#afa}.que .notanswered,
.que
.incorrect{background-color:#faa}.que
.partiallycorrect{background-color:#ff9}.que
.validationerror{color:#a00}.que .grading,
.que .comment,
.que .commentlink,
.que
.history{margin-top:0.5em}.que .history
h3{margin:0
0 0.2em;font-size:1em}.que .history
table{width:100%;margin:0}.que .history
.current{font-weight:bold}.que
.questioncorrectnessicon{vertical-align:text-bottom}.que
input.questionflagimage{padding-right:3px}.dir-rtl .que
input.questionflagimage{padding-left:3px;padding-right:0}.importerror{margin-top:10px;border-bottom:1px solid #555}.mform .que.comment
.fitemtitle{width:20%}#page-question-preview
#techinfo{margin:1em
0}#page-mod-quiz-edit #categoryquestions
.header{background:none}.path-question-type #id_answerhdr .fitem_feditor
.felement{margin-left:0px;margin-right:0px}@media (min-width: 1200px){.path-question-type #id_answerhdr .fitem_feditor
.felement{margin-left:16%;margin-right:0px}body#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{padding-left:0;padding-right:0}.dir-rtl.path-question-type #id_answerhdr .fitem_feditor
.felement{margin-right:16%;margin-left:0px}body.dir-rtl#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{padding-left:0;padding-right:0}}.dir-rtl #qtypechoicecontainer #chooseqtype .instruction,
.dir-rtl #qtypechoicecontainer #chooseqtype
.qtypesummary{right:60%;left:0%;border-left:0;border-right:1px solid grey}#qtypechoicecontainer #chooseqtype
.qtypeoption{padding-right:0.3em}body.path-question-type .mform
fieldset.hidden{padding:0;margin:0.7em 0 0}.userprofile
.fullprofilelink{text-align:center;margin:10px}.userprofile
.profilepicture{float:left;margin-right:20px}.userprofile
.description{margin-bottom:20px}.userprofile
dl{margin-top:10px;margin-left:0;width:100%}.userprofile dl dt, .userprofile dl
dd{padding-top:3px;padding-bottom:3px}.userprofile dl
dt{margin:0;font-weight:bold;display:block;float:left;width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.userprofile dl
dd{margin:0;margin-left:120px}.userprofile
.profile_tree{column-count:2;-webkit-column-count:2;-moz-column-count:2}.userprofile .profile_tree
section{display:inline-block;width:100%}.user-box{margin:8px;width:115px;height:160px;text-align:center;float:left;clear:none}.userlist .action-icon
img{vertical-align:middle}.userlist
#showall{margin:10px
0px}.userlist
.buttons{text-align:center}.userlist .buttons
label{padding:0
3px}.userlist
table#participants{text-align:center}.userlist table#participants td,
.userlist table#participants
th{vertical-align:middle;text-align:left;padding:4px}.userlist
table.controls{width:100%}.userlist table.controls
tr{vertical-align:top}.userlist table.controls td.right,
.userlist table.controls
td.left{padding:4px}.userlist table.controls
.right{text-align:right}.userinfobox{width:100%;border:1px
solid;border-collapse:separate;padding:10px}.userinfobox .left,
.userinfobox
.side{width:100px;vertical-align:top}.userinfobox
.userpicture{width:100px;height:100px}.userinfobox
.content{vertical-align:top}.userinfobox
.links{width:100px;padding:5px;vertical-align:bottom}.userinfobox .links
a{display:block}.userinfobox .list
td{padding:3px}.userinfobox
.username{padding-bottom:20px;font-weight:bold}.userinfobox
td.label{text-align:right;white-space:nowrap;vertical-align:top;font-weight:bold}.groupinfobox{border:1px
solid}.groupinfobox
.left{padding:10px;width:100px;vertical-align:top}.course-participation
#showall{text-align:center;margin:10px
0px}#user-policy
.noticebox{text-align:center;margin-left:auto;margin-right:auto;margin-bottom:10px;width:80%;height:250px}#user-policy
#policyframe{width:100%;height:100%}.iplookup
#map{margin:auto}.userselector
select{width:100%}.userselector
div{margin-top:0.2em}.userselector div
label{margin-right:0.3em}.userselector .userselector-infobelow{font-size:0.8em}#userselector_options{padding:0.3em 0}#userselector_options
.collapsibleregioncaption{font-weight:bold}#userselector_options
p{margin:0.2em 0;text-align:left}.dir-rtl #userselector_options
p{text-align:right}#page-user-profile
.messagebox{text-align:center;margin-left:auto;margin-right:auto}#page-course-view-weeks
.messagebox{text-align:center;margin-left:auto;margin-right:auto}.dir-rtl .userprofile
.profilepicture{float:right;margin-left:20px;margin-right:0px}.dir-rtl .userlist table#participants td,
.dir-rtl .userlist table#participants
th{text-align:right}.dir-rtl .userlist
table#participants{margin:0
auto}.dir-rtl .userprofile dl
dt{float:right;width:110px;margin-left:10px}.dir-rtl .userprofile dl
dd{margin-right:120px}#page-my-index.dir-rtl .block
h3{text-align:right}#groupeditform .groups,
#groupeditform
.members{width:49%;float:left;text-align:left;min-width:175px}#groupeditform .groups select,
#groupeditform .members
select{min-width:175px}.dir-rtl #groupeditform .groups,
.dir-rtl #groupeditform
.members{float:right;text-align:right}.tabtree
ul{text-align:center}.tabtree
li{list-style:none;margin:0;padding:0}.tabtree
.tabrow0{width:100%;margin:1em
0}.tabtree .tabrow0
li.here{font-weight:bold}.tabtree .tabrow0 li.here
a{position:relative;z-index:102}.tabtree .tabrow0 li
a{background:#f7f7f7;padding:8px
10px 5px;border-width:2px 2px 0;border-style:solid;border-color:#ddd;margin:0
1px 0 0}.tabtree .tabrow0 .here
a{background-color:#fff}.tabtree .tabrow0 li a:hover{background-color:#fff}.tabtree .tabrow0 ul,
.tabtree .tabrow0
div{font-weight:normal;border-top:2px solid #ddd;padding:0.25em 0;margin:0}.tabtree .tabrow0 li.here
.empty{display:block;height:1px;overflow:hidden;padding:0;position:absolute;width:100%;bottom:-5px}.tabtree .tabrow0
.tabrow1{padding:5px
0 2px;margin-top:1px}.tabtree .tabrow1 li a,
.tabtree .tabrow1 li a:link,
.tabtree .tabrow1 li a:hover,
.tabtree .tabrow1 li a span,
.tabtree .tabrow1 li a:link span,
.tabtree .tabrow1 li a:hover
span{padding:0
10px;border:0
none}.tabtree a.nolink,
.tabtree a.nolink:hover,
.tabtree .here ul a.nolink,
.tabtree .here ul a.nolink:hover{color:#888;text-decoration:none}.tabtree .here a.nolink,
.tabtree .here a.nolink:hover,
.tabtree .here ul .here a.nolink,
.tabtree .here ul .here a.nolink:hover{color:#000;text-decoration:none}.filemanager,.file-picker{font-size:11px;color:#555;letter-spacing:.2px}.filemanager a, .file-picker
a{color:#555}.filemanager a:hover, .file-picker a:hover{color:#555;text-decoration:none}.filemanager select, .filemanager input, .filemanager button, .filemanager textarea,
.file-picker select, .file-picker input, .file-picker button, .file-picker
textarea{color:#555;letter-spacing:.2px}.filemanager input[type="text"], .file-picker input[type="text"]{border:1px
solid #BBB;width:265px;height:18px;padding:1px
6px}.filemanager select, .file-picker
select{height:22px;padding:2px
1px}.fp-content-center{height:100%;width:100%;display:table-cell;vertical-align:middle}.fp-content-hidden{visibility:hidden}.yui3-panel-focused{outline:none}#filesskin .yui3-panel-content{padding-bottom:20px;background:#F2F2F2;border-radius:8px;border:1px
solid #FFF;display:inline-block;-webkit-box-shadow:5px 5px 20px 0px #666;-moz-box-shadow:5px 5px 20px 0px #666;box-shadow:5px 5px 20px 0px #666}#filesskin .yui3-widget-hd{border-radius:10px 10px 0px 0px;border-bottom:1px solid #BBB;padding:5px
5px 5px 5px;text-align:center;font-size:12px;letter-spacing:1px;color:#333;text-shadow:1px 1px 1px #FFF;filter:dropshadow(color=#FFFFFF, offx=1, offy=1);background:#E2E2E2;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#FFFFFF', endColorstr='#CCCCCC');background:-webkit-gradient(linear, left top, left bottom,from(#FFFFFF),to(#CCCCCC));background:-moz-linear-gradient(top,#FFFFFF,#CCCCCC)}.fp-panel-button{background:#FFF;padding:3px
20px 2px 20px;text-align:center;margin:10px;border-radius:10px;display:inline-block;-webkit-box-shadow:2px 2px 3px .1px #999;-moz-box-shadow:2px 2px 3px .1px #999;box-shadow:2px 2px 3px .1px #999}.moodle-dialogue-base .filepicker .moodle-dialogue-wrap .moodle-dialogue-bd{padding:0px}#filesskin .file-picker.fp-generallayout{width:859px;background:#FFF;border-radius:10px;border:1px
solid #CCC;position:relative}.file-picker .fp-repo-area{width:180px;overflow:auto;float:left;height:525px;border-right:1px solid #BBB}.dir-rtl .file-picker .fp-repo-area{border-left:1px solid #BBB;border-right:none;float:right}.file-picker .fp-repo-items{overflow:hidden}.file-picker .fp-navbar{background:#F2F2F2;min-height:40px;border-bottom:1px solid #BBB}.file-picker .fp-content{background:#FFF;clear:both;overflow:auto;height:452px}.filepicker.moodle-dialogue-fullscreen .file-picker .fp-content{width:100%}.file-picker .fp-content-loading{height:100%;width:100%;display:table;text-align:center}.file-picker .fp-content .fp-object-container{width:98%;height:98%}.dir-rtl .file-picker .fp-list{text-align:right}.dir-rtl .file-picker .fp-toolbar{padding:0}.dir-rtl .file-picker .fp-list{text-align:right}.dir-rtl .file-picker .fp-repo-name{display:inline}.dir-rtl .file-picker .fp-pathbar{text-align:right;display:block;border-top:none}.dir-rtl .file-picker
div.bd{text-align:right}.dir-rtl #filemenu
.yuimenuitemlabel{text-align:right}.dir-rtl .filepicker .yui-layout-unit-left{left:500px}.dir-rtl .filepicker .yui-layout-unit-center{left:0px}.dir-rtl .filepicker.moodle-dialogue-fullscreen .file-picker .fp-repo-items{float:none}.dir-rtl .filemanager-toolbar
a{padding:0px}.file-picker .fp-list{list-style-type:none;padding:0;float:left;width:100%;margin:0}.dir-rtl .file-picker .fp-list{text-align:right;float:left}.file-picker .fp-list .fp-repo
a{display:block;padding:.5em .7em}.file-picker .fp-list .fp-repo.active{background:#F2F2F2}.file-picker .fp-list .fp-repo-icon{padding:0
7px 0 5px;vertical-align:text-bottom}.fp-toolbar{display:block;line-height:22px;float:left}.dir-rtl .fp-toolbar{float:right}.fp-toolbar.empty{display:none}.fp-toolbar
.disabled{display:none}.file-picker .fp-toolbar div, .fp-navbar .filemanager-toolbar .fp-toolbar
div{float:left;margin:4px
0 4px 4px}.fp-toolbar .fp-btn-add, .fp-toolbar .fp-btn-download, .fp-toolbar .fp-btn-mkdir, .fp-toolbar .fp-tb-help, .fp-toolbar .fp-tb-manage, .fp-toolbar .fp-tb-logout, .fp-toolbar .fp-tb-refresh{background:#FFF;border:1px
solid #CCC;border-bottom:1px solid #B3B3B3;border-radius:4px;width:30px;height:30px}.file-picker .fp-toolbar .fp-tb-message{background:inherit;border:0;border-bottom:0;border-radius:0;width:300px;height:32px}.fp-toolbar
div{display:block}.fp-toolbar
a{display:block;height:30px;width:30px}.fp-toolbar a:hover{background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%);background-color:#ebebeb}.fp-toolbar a:active{background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%);background-color:#dfdfdf}.dir-rtl .fp-navbar .filemanager-toolbar .fp-toolbar
div{margin:4px
4px 4px 0}.file-picker .fp-toolbar
div.disabled{display:none}.fp-toolbar
img{vertical-align:-15%;margin:7px}.file-picker .fp-toolbar .fp-tb-search{height:30px}.file-picker .fp-toolbar .fp-tb-search .fp-def-search{border:0;background:transparent;margin:0;padding:0}.fp-toolbar .fp-tb-search
input{background:#fff url('/sunguru/theme/image.php/archaius/core/1531975376/a/search') no-repeat 7px 7px;padding:2px
6px 1px 27px;width:200px;height:27px;border:1px
solid #bbb;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.dir-rtl .fp-toolbar
img{vertical-align:-35%}.dir-rtl .file-picker .fp-viewbar, .dir-rtl .fp-navbar .filemanager-toolbar .fp-viewbar{float:left}.file-picker .fp-viewbar, .fp-navbar .filemanager-toolbar .fp-viewbar{float:right;margin:4px;background:white;border:1px
solid #CCC;border-radius:4px;border-bottom:1px solid #B3B3B3;height:30px}.fp-viewbar .fp-vb-icons, .fp-viewbar .fp-vb-details, .fp-viewbar .fp-vb-tree{width:30px;height:30px;display:block;float:left;border-right:1px solid #CCC}.fp-viewbar a.fp-vb-icons{border-radius:4px 0 0 4px}.fp-viewbar .fp-vb-tree{border-right:0;border-radius:0 4px 4px 0}.fp-viewbar a
img{margin:7px}.fp-viewbar a.checked:hover, .fp-viewbar a:hover{background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%);background-color:#ebebeb}.fp-viewbar a.checked, .fp-viewbar a:active{background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%);background-color:#dfdfdf}.fp-viewbar.disabled
a{opacity:.45;background:none;cursor:default}.file-picker .fp-clear-left{clear:left}.dir-rtl .fp-vb-details a:hover{background:none;border:20px
solid black}.dir-rtl .fp-vb-details.checked a:hover{background:none;border:40px
solid black}.dir-rtl .fp-vb-tree a:hover{background:none;border:30px
solid black}.dir-rtl .fp-vb-tree.checked a:hover{background:none;border:50px
solid black}.file-picker .fp-pathbar{display:table-row}.fp-pathbar.empty{display:none}.fp-pathbar .fp-path-folder{background:url('/sunguru/theme/image.php/archaius/theme/1531975376/fp/path_folder') no-repeat 0 0;width:27px;height:12px;margin-left:4px}.dir-rtl .fp-pathbar .fp-path-folder{background:url('/sunguru/theme/image.php/archaius/theme/1531975376/fp/path_folder_rtl') no-repeat right top;width:auto;height:12px;margin-left:4px}.dir-rtl .fp-pathbar
span{display:inline-block;float:right;margin-left:32px}.fp-pathbar .fp-path-folder-name{margin-left:32px;line-height:20px}.dir-rtl .fp-pathbar .fp-path-folder-name{margin-right:32px;line-height:20px}.fp-iconview .fp-file{float:left;text-align:center;position:relative;margin:10px
10px 35px}.fp-iconview .fp-thumbnail{min-width:110px;min-height:110px;line-height:110px;text-align:center;border:1px
solid #FFF;display:block}.fp-iconview .fp-thumbnail
img{border:1px
solid #DDD;padding:3px;vertical-align:middle;-webkit-box-shadow:1px 1px 2px 0px #CCC;-moz-box-shadow:1px 1px 2px 0px #CCC;box-shadow:1px 1px 2px 0px #CCC}.fp-iconview .fp-thumbnail:hover{background:#FFF;border:1px
solid #DDD;-webkit-box-shadow:inset 0px 0px 10px 0px #CCC;-moz-box-shadow:inset 0px 0px 10px 0px #CCC;box-shadow:inset 0px 0px 10px 0px #CCC}.fp-iconview .fp-filename-field{height:33px;word-wrap:break-word;overflow:hidden;position:absolute}.fp-iconview .fp-filename-field:hover{overflow:visible;z-index:1000}.fp-iconview .fp-filename-field .fp-filename{background:#FFF;padding-top:5px;padding-bottom:12px;min-width:112px}.dir-rtl .fp-iconview .fp-file{float:right}.file-picker .yui3-datatable
table{border:0px
solid #BBB;width:100%}#filesskin .file-picker .yui3-datatable-header{background:#FFF;border-bottom:1px solid #CCC;border-left:0 solid #FFF;color:#555}#filesskin .file-picker .yui3-datatable-odd .yui3-datatable-cell{background-color:#F6F6F6;border-left:0px solid #F6F6F6}#filesskin .file-picker .yui3-datatable-even .yui3-datatable-cell{background-color:#FFF;border-left:0px solid #FFF}.dir-rtl .file-picker .yui3-datatable-header{text-align:right}.file-picker .ygtvtn, .filemanager
.ygtvtn{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tn') 0px 0px no-repeat;width:17px;height:22px}.dir-rtl .file-picker .ygtvtn, .dir-rtl .filemanager
.ygtvtn{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tn_rtl') 0px 0px no-repeat}.file-picker .ygtvtm, .filemanager
.ygtvtm{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tm') 0px 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvtmh, .filemanager
.ygtvtmh{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tm') 0px 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvtp, .filemanager
.ygtvtp{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tp') 0px 10px no-repeat;width:13px;height:12px;cursor:pointer}.dir-rtl .file-picker .ygtvtp, .dir-rtl .filemanager
.ygtvtp{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tp_rtl') 0px 10px no-repeat}.file-picker .ygtvtph, .filemanager
.ygtvtph{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tp') 0px 10px no-repeat;width:13px;height:22px;cursor:pointer}.dir-rtl .file-picker .ygtvtph, .dir-rtl .filemanager
.ygtvtph{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/tp_rtl') 0px 10px no-repeat}.file-picker .ygtvln, .filemanager
.ygtvln{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/ln') 0px 0px no-repeat;width:17px;height:22px}.dir-rtl .file-picker .ygtvln, .dir-rtl .filemanager
.ygtvln{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/ln_rtl') 0px 0px no-repeat}.file-picker .ygtvlm, .filemanager
.ygtvlm{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/lm') 0px 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvlmh, .filemanager
.ygtvlmh{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/lm') 0px 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvlp, .filemanager
.ygtvlp{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/lp') 0px 10px no-repeat;width:13px;height:12px;cursor:pointer}.dir-rtl .file-picker .ygtvlp, .dir-rtl .filemanager
.ygtvlp{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/lp_rtl') 0px 10px no-repeat}.file-picker .ygtvlph, .filemanager
.ygtvlph{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/lp') 0px 10px no-repeat;width:13px;height:12px;cursor:pointer}.dir-rtl .file-picker .ygtvlph, .dir-rtl .filemanager
.ygtvlph{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/lp_rtl') 0px 10px no-repeat}.file-picker .ygtvloading, .filemanager
.ygtvloading{background:transparent url('/sunguru/theme/image.php/archaius/core/1531975376/y/loading') 0 0 no-repeat;width:16px;height:22px}.file-picker .ygtvdepthcell, .filemanager
.ygtvdepthcell{background:url('/sunguru/theme/image.php/archaius/core/1531975376/y/vline') 0 0 no-repeat;width:17px;height:32px}.file-picker .ygtvblankdepthcell, .filemanager
.ygtvblankdepthcell{width:17px;height:22px}a.ygtvspacer:hover{color:transparent;text-decoration:none}.ygtvlabel,.ygtvlabel:link,.ygtvlabel:visited,.ygtvlabel:hover{background-color:transparent;cursor:pointer;margin-left:2px;text-decoration:none}.file-picker .ygtvfocus, .filemanager
.ygtvfocus{background-color:#EEE}.fp-filename-icon{margin-top:10px;display:block;position:relative}.fp-icon{float:left;margin-top:-7px;width:24px;height:24px;margin-right:10px;text-align:center;line-height:24px}.dir-rtl .fp-icon{float:right;margin-left:10px;margin-right:0}.fp-icon
img{max-height:24px;max-width:24px;vertical-align:middle}.fp-filename{padding-right:10px}.dir-rtl .fp-filename{padding-left:10px;padding-right:0}.file-picker .fp-login-form{height:100%;width:100%;display:table}.file-picker .fp-login-form
table{margin:0
auto}.file-picker .fp-login-form
p{text-align:center;margin-top:3em}.file-picker .fp-login-form .fp-login-input
.label{text-align:right;vertical-align:middle}.file-picker .fp-login-form .fp-login-input
.input{text-align:left}.file-picker .fp-login-form input[type="checkbox"]{width:15px;height:15px}.file-picker .fp-upload-form{height:100%;width:100%;display:table}.file-picker .fp-upload-form
table{margin:0
auto}.file-picker .fp-upload-btn{margin:2em}.file-picker.fp-dlg{text-align:center}.file-picker.fp-dlg .fp-dlg-text{padding:30px
20px 10px;font-size:12px}.file-picker.fp-dlg .fp-dlg-buttons{margin:0
20px}.file-picker.fp-msg{text-align:center}.file-picker.fp-msg .fp-msg-text{padding:40px
20px 10px 20px;min-width:200px;max-width:500px;max-height:300px;overflow:auto;font-size:12px}.file-picker.fp-msg.fp-msg-error .fp-msg-text{padding:40px
20px 10px 20px;font-size:12px}.file-picker .fp-content-error{height:100%;width:100%;display:table;text-align:center}.file-picker .fp-content-error .fp-error{height:100%;width:100%;display:table-cell;vertical-align:middle;padding:40px
20px 10px 20px;font-size:12px}.file-picker .fp-nextpage{clear:both}.file-picker .fp-nextpage .fp-nextpage-loading{display:none}.file-picker .fp-nextpage.loading .fp-nextpage-link{display:none}.file-picker .fp-nextpage.loading .fp-nextpage-loading{display:block;text-align:center;height:100px;padding-top:50px}.fp-select
form{padding:20px
20px 0}.fp-select .fp-select-loading{text-align:center;margin-top:20px}.fp-select .fp-hr{clear:both;height:1px;background-color:#FFF;border-bottom:1px solid #BBB;width:auto;margin:10px
0}.fp-select
table{padding:0
0 10px}.fp-select table .mdl-right{min-width:84px}.fp-select .fp-reflist .mdl-right{vertical-align:top}.fp-select .fp-select-buttons{float:right}.fp-select .fp-info{display:block;clear:both;padding:1px
20px 0}.fp-select .fp-thumbnail{float:left;min-width:110px;min-height:110px;line-height:110px;text-align:center;margin:10px
10px 0 0;background:#FFF;border:1px
solid #DDD;-webkit-box-shadow:inset 0 0 10px 0 #CCC;-moz-box-shadow:inset 0 0 10px 0 #CCC;box-shadow:inset 0 0 10px 0 #CCC}.fp-select .fp-thumbnail
img{border:1px
solid #DDD;padding:3px;vertical-align:middle;margin:10px}.fp-select .fp-fileinfo{display:inline-block;margin-top:10px}.file-picker.fp-select .fp-fileinfo{max-width:240px}.fp-select .fp-fileinfo
div{padding-bottom:5px}.file-picker.fp-select
.uneditable{display:none}.file-picker.fp-select .fp-select-loading{display:none}.file-picker.fp-select.loading .fp-select-loading{display:block}.file-picker.fp-select.loading
form{display:none}.fp-select .fp-dimensions.fp-unknown{display:none}.fp-select .fp-size.fp-unknown{display:none}.filemanager-loading{display:none}.jsenabled .filemanager-loading{display:block;margin-top:100px}.filemanager.fm-loading .filemanager-toolbar,
.filemanager.fm-loading .fp-pathbar,
.filemanager.fm-loading .filemanager-container{display:none}.filemanager.fm-loaded .filemanager-loading{display:none}.filemanager.fm-maxfiles .fp-btn-add{display:none}.filemanager.fm-maxfiles .dndupload-message{display:none}.filemanager.fm-noitems .fp-btn-download{display:none}.filemanager .fm-empty-container{display:none}.filemanager.fm-noitems .filemanager-container .fp-content{display:none}.filemanager .filemanager-updating{display:none;text-align:center}.filemanager.fm-updating .filemanager-updating{display:block;margin-top:37px}.filemanager.fm-updating .fm-content-wrapper{display:none}.filemanager.fm-nomkdir .fp-btn-mkdir{display:none}.fitem.disabled .filemanager .filemanager-toolbar,
.fitem.disabled .filemanager .fp-pathbar,
.fitem.disabled .filemanager .fp-restrictions,
.fitem.disabled .filemanager .fm-content-wrapper{display:none}.filemanager .fp-img-downloading{display:none;padding-top:3px}.filemanager .fp-restrictions{text-align:right}.filemanager .fp-navbar{background:#F2F2F2;border-top:1px solid #BBB;border-left:1px solid #BBB;border-right:1px solid #BBB}.filemanager-toolbar{min-height:40px}.fp-pathbar{border-top:1px solid #BBB;padding:5px
8px 1px;min-height:20px}.filemanager .fp-pathbar.empty{display:none}.filepicker-filelist,.filemanager-container{background:#FFF;clear:both;overflow:auto;border:1px
solid #BBB;min-height:140px;position:relative}.filemanager .fp-content{overflow:auto;max-height:472px;min-height:157px}.filemanager-container,.filepicker-filelist{overflow:hidden}.fitem.disabled .filepicker-filelist, .fitem.disabled .filemanager-container{background-color:#EBEBE4}.fitem.disabled .fp-btn-choose{color:graytext}.fitem.disabled .filepicker-filelist .filepicker-filename{display:none}.fp-iconview .fp-reficons1{position:absolute;height:100%;width:100%;top:0;left:0}.fp-iconview .fp-reficons2{position:absolute;height:100%;width:100%;top:0;left:0}.fp-iconview .fp-file.fp-hasreferences .fp-reficons1{background:url('/sunguru/theme/image.php/archaius/theme/1531975376/fp/link') no-repeat;background-position:bottom right}.fp-iconview .fp-file.fp-isreference .fp-reficons2{background:url('/sunguru/theme/image.php/archaius/theme/1531975376/fp/alias') no-repeat;background-position:bottom left}.filemanager .fp-iconview .fp-file.fp-originalmissing .fp-thumbnail
img{display:none}.filemanager .fp-iconview .fp-file.fp-originalmissing .fp-thumbnail{background:url(/sunguru/theme/image.php/archaius/core/1531975376/s/dead) no-repeat;background-position:center center}.filemanager .yui3-datatable
table{border:0px
solid #BBB;width:100%}.filemanager .yui3-datatable-header{background:#FFFFFF!important;border-bottom:1px solid #CCCCCC!important;border-left:0 solid #FFFFFF!important;color:#555555!important}.filemanager .yui3-datatable-odd .yui3-datatable-cell{background-color:#F6F6F6!important;border-left:0px solid #F6F6F6}.filemanager .yui3-datatable-even .yui3-datatable-cell{background-color:#FFFFFF!important;border-left:0px solid #FFF}.filemanager .fp-filename-icon.fp-hasreferences .fp-reficons1{background:url('/sunguru/theme/image.php/archaius/theme/1531975376/fp/link_sm') no-repeat 0 0;height:100%;width:100%;position:absolute;top:8px;left:17px;z-index:1000}.filemanager .fp-filename-icon.fp-isreference .fp-reficons2{background:url('/sunguru/theme/image.php/archaius/theme/1531975376/fp/alias_sm') no-repeat 0 0;height:100%;width:100%;position:absolute;top:9px;left:-6px;z-index:1001}.filemanager .fp-contextmenu{display:none}.filemanager .fp-iconview .fp-folder.fp-hascontextmenu .fp-contextmenu{display:block;position:absolute;right:7px;bottom:5px}.filemanager .fp-treeview .fp-folder.fp-hascontextmenu .fp-contextmenu,
.filemanager .fp-tableview .fp-folder.fp-hascontextmenu .fp-contextmenu{display:inline;position:absolute;left:14px;margin-right:-20px;top:6px}.dir-rtl .filemanager .fp-iconview .fp-folder.fp-hascontextmenu .fp-contextmenu{left:7px;right:inherit}.dir-rtl .filemanager .fp-treeview .fp-folder.fp-hascontextmenu .fp-contextmenu,
.dir-rtl .filemanager .fp-tableview .fp-folder.fp-hascontextmenu .fp-contextmenu{left:inherit;right:16px;margin-right:0}.filepicker-filelist .filepicker-container,
.filemanager.fm-noitems .fm-empty-container{display:block;position:absolute;top:10px;bottom:10px;left:10px;right:10px;border:2px
dashed #BBB;padding-top:85px;text-align:center}.filepicker-filelist .dndupload-target,
.filemanager-container .dndupload-target{background:#FFF;position:absolute;top:10px;bottom:10px;left:10px;right:10px;border:2px
dashed #fb7979;padding-top:85px;text-align:center;-webkit-box-shadow:0px 0px 0px 10px #FFF;-moz-box-shadow:0px 0px 0px 10px #FFF;box-shadow:0px 0px 0px 10px #FFF}.filepicker-filelist.dndupload-over .dndupload-target,
.filemanager-container.dndupload-over .dndupload-target{background:#FFF;position:absolute;top:10px;bottom:10px;left:10px;right:10px;border:2px
dashed #6c8cd3;padding-top:85px;text-align:center}.dndupload-message{display:none}.dndsupported .dndupload-message{display:inline}.dnduploadnotsupported-message{display:none}.dndnotsupported .dnduploadnotsupported-message{display:inline}.dndupload-target{display:none}.dndsupported .dndupload-ready .dndupload-target{display:block}.dndupload-uploadinprogress{display:none;text-align:center}.dndupload-uploading .dndupload-uploadinprogress{display:block}.dndupload-arrow{background:url(/sunguru/theme/image.php/archaius/theme/1531975376/fp/dnd_arrow) center no-repeat;width:100%;height:80px;position:absolute;top:5px}.fitem.disabled .filepicker-container, .fitem.disabled .fm-empty-container{display:none}.dndupload-progressbars{padding:10px;display:none}.dndupload-inprogress .dndupload-progressbars{display:block}.dndupload-inprogress .fp-content{display:none}.filemanager.fm-noitems .dndupload-inprogress .fm-empty-container{display:none}.filepicker-filelist.dndupload-inprogress .filepicker-container{display:none}.filepicker-filelist.dndupload-inprogress
a{display:none}.filemanager.fp-select .fp-select-loading{display:none}.filemanager.fp-select.loading .fp-select-loading{display:block}.filemanager.fp-select.loading
form{display:none}.filemanager.fp-select.fp-folder .fp-license, .filemanager.fp-select.fp-folder .fp-author,
.filemanager.fp-select.fp-file .fp-file-unzip,
.filemanager.fp-select.fp-folder .fp-file-unzip,
.filemanager.fp-select.fp-file .fp-file-zip,
.filemanager.fp-select.fp-zip .fp-file-zip{display:none}.filemanager.fp-select .fp-file-setmain,
.filemanager.fp-select .fp-file-setmain-help{display:none}.filemanager.fp-select.fp-cansetmain .fp-file-setmain,
.filemanager.fp-select.fp-cansetmain .fp-file-setmain-help{display:inline-block}.filemanager .fp-mainfile .fp-filename{font-weight:bold}.filemanager.fp-select.fp-folder .fp-file-download{display:none}.fm-operation{font-weight:bold}.filemanager.fp-select .fp-original.fp-unknown{display:none}.filemanager.fp-select .fp-original .fp-originloading{display:none}.filemanager.fp-select .fp-original.fp-loading .fp-originloading{display:inline}.filemanager.fp-select .fp-reflist.fp-unknown{display:none}.filemanager.fp-select .fp-reflist .fp-reflistloading{display:none}.filemanager.fp-select .fp-refcount{max-width:265px}.filemanager.fp-select .fp-reflist.fp-loading .fp-reflistloading{display:inline}.filemanager.fp-select .fp-reflist .fp-value{background:#F9F9F9;border:1px
solid #BBB;padding:8px
7px;margin:0px;max-width:265px;max-height:75px;overflow:auto}.filemanager.fp-select .fp-reflist .fp-value
li{padding-bottom:7px}.filemanager.fp-mkdir-dlg{text-align:center}.filemanager.fp-mkdir-dlg .fp-mkdir-dlg-text{text-align:left;margin:20px}.dir-rtl .filemanager .fp-mkdir-dlg
p{text-align:right}.filemanager.fp-dlg{text-align:center}.filemanager.fp-dlg .fp-dlg-text{padding:0px
10px;min-width:200px;max-width:340px;max-height:300px;overflow:auto;line-height:22px;margin:40px
20px 20px;font-size:12px}.file-picker
div.bd{text-align:left}.dir-rtl .file-picker
div.bd{text-align:right}.dir-rtl .file-picker .fp-pathbar{text-align:right}.dir-rtl .file-picker .fp-list{text-align:right}.dir-rtl .filepicker .yui-layout-unit-left{left:500px}.dir-rtl .filepicker .yui-layout-unit-center{left:0}.dir-rtl #filemenu
.yuimenuitemlabel{text-align:right}.dir-rtl .filemanager-container .yui3-skin-sam .yui3-datatable-header{text-align:right}.dir-rtl .filemanager .fp-restrictions{text-align:left}.dir-rtl .file-picker .fp-toolbar .fp-tb-search
input{background-position:208px 7px;padding:2px
30px 1px 3px}.dir-rtl .file-picker .fp-toolbar
div{float:right;margin-left:4px}.fp-formset{margin:0
auto;width:500px}.fp-formset
div{text-align:left}.fp-formset
.controls{text-align:left}.fp-formset
label{display:block;float:left;width:210px;text-align:right;margin:0
10px 0 0}.fp-formset .fp-popup{text-align:center}.fp-formset .fp-setlicense
select{width:280px}.fp-forminset{margin-bottom:10px}.fp-forminset
label{display:block;float:left;width:95px;text-align:right;margin:0
10px 0 0}.fp-forminset input[type="text"]{width:258px;margin:0}.fp-forminset
select{width:272px;margin:0}.fp-forminset
.controls{float:left}.fp-forminset label.control-radio{float:right;text-align:left;width:250px}.fp-forminset .controls.control-radio{margin-left:105px}.fp-forminset .controls.control-radio
input{margin-top:5px}.file-picker .fp-fileinfo .fp-value{display:inline-block;padding-left:5px}.dir-rtl .fp-forminset
label{display:block;float:right;width:95px;text-align:right;margin:0
0 0 10px}.dir-rtl .fp-forminset
.controls{float:right}.dir-rtl .fp-forminset .fp-select-buttons{float:left}.dir-rtl .fp-forminset .fp-setlicense select, .dir-rtl .fp-forminset .fp-license
select{width:272px}.dir-rtl .fp-forminset input[type="text"]{width:258px;margin:0}.dir-rtl .fp-forminset label.control-radio{float:left;text-align:right;width:250px;margin-left:0}.dir-rtl .fp-forminset .controls.control-radio{margin:0
100px 0 0}.dir-rtl .fp-select .fp-thumbnail{margin-right:0}.dir-rtl .file-picker .fp-fileinfo .fp-value{display:inline-block;padding:0
5px 0 0}.dir-rtl .fp-formset
div{text-align:right}.dir-rtl .fp-formset
label{float:right;text-align:left;margin:0
0 0 10px}@media (max-width:767px){.file-picker .fp-repo-area{width:100%;height:auto;max-height:220px;y-scroll:auto;float:none;border:0px}.file-picker .fp-repo-items{width:100%;float:none;margin-left:0}.file-picker .fp-login-form .fp-login-input
.label{text-align:left}.dir-rtl .file-picker .fp-login-form .fp-login-input
.label{text-align:right}.file-picker .fp-content form
td{display:block;width:100%;text-align:left}.dir-rtl .file-picker .fp-content form
td{text-align:right}.fp-content .mdl-right{text-align:left}.dir-rtl .fp-content .mdl-right{text-align:right}.fp-repo-items .fp-navbar{border-top:1px solid rgb(187,187,187)}.fp-formset,.fp-forminset{margin:0
10px;width:auto}.fp-formset label, .fp-forminset
label{float:none;width:210px;text-align:left;margin:5px
0}.dir-rtl .fp-formset label, .dir-rtl .fp-forminset
label{text-align:right;float:none}.dir-rtl .filepicker.moodle-dialogue-fullscreen .file-picker .fp-repo-items{float:right}}.row-fluid{width:100%}.row-fluid::before{display:table;content:"";line-height:0}.row-fluid::after{display:table;content:"";line-height:0;clear:both}.row-fluid [class*="span"]{float:left;margin-left:1%;margin-right:0}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid
.span4{width:32.666666667%}.row-fluid
.span8{width:66%}.dir-rtl .row-fluid [class*="span"]{float:right;margin-left:0;margin-right:1%}.dir-rtl .row-fluid [class*="span"]:first-child{margin-right:0}.columns-autoflow-1to1to1{-moz-column-count:3;-webkit-column-count:3;column-count:3;-moz-column-gap:20px;-webkit-column-gap:20px;column-gap:20px}@media (max-width: 767px){.row-fluid [class*="span"]{width:100%;float:none;margin-left:0;margin-right:0}.dir-rtl .row-fluid [class*="span"]{margin-right:0}.columns-autoflow-1to1to1{-moz-column-count:1;-webkit-column-count:1;column-count:1;-moz-column-gap:0;-webkit-column-gap:0;column-gap:0}}.form-autocomplete-selection{margin:0.2em;min-height:21px}.form-autocomplete-multiple [role=listitem].label{cursor:pointer}.form-autocomplete-selection [role=listitem].label{color:#333;background-color:#00E;border:4px
solid #00E;color:#FFF;font-weight:bold;border-radius:3px;display:inline-block;margin-bottom:3px}.form-autocomplete-suggestions{position:absolute;background-color:white;border:2px
solid #EEE;border-radius:3px;min-width:206px;max-height:20em;overflow:auto;margin:0px;padding:0px;margin-top:-0.2em;z-index:1}.form-autocomplete-suggestions
li{list-style-type:none;padding:0.2em;margin:0;cursor:pointer;color:#333}.form-autocomplete-suggestions li:hover{background-color:#00E;color:#FFF}.form-autocomplete-suggestions li[aria-selected=true]{background-color:#555;color:#FFF}.form-autocomplete-downarrow{position:relative;top:-0.1em;left:-1.5em;cursor:pointer;color:#000}.dir-rtl .form-autocomplete-downarrow{right:-1.5em;left:inherit}.form-autocomplete-selection:focus{outline:none}.form-autocomplete-selection [data-active-selection=true]{padding:0.5em;font-size:large}.search-results
.result{margin-left:0;margin-right:0}.dir-rtl .search-results
.result{margin-right:15px;margin-left:0}.search-results .result .result-content{margin:7px
0}.search-results .result
.filename{font-style:italic}.main-content{max-width:1200px;width:90% !important;margin:20px
auto 0px auto;padding:5px}#page{background-color:#fff;margin:20px
auto 50px auto;min-height:65vh}h1.main,h2.main,h3.main,h4.main,h5.main,h6.main{text-align:center}.generalbox{padding:10px;margin-bottom:15px}.filemanager input[type="submit"],
.filemanager button,
.file-picker input[type="submit"],
.file-picker
button{color:white}table{width:100%}#tablecontainer{overflow:scroll}#notice.generalbox,.generaltable,.userinfobox{margin-left:auto;margin-right:auto}.notifyproblem,.notifysuccess{padding:10px}.notifyproblem{color:#600}.notifysuccess{background-color:#B8D9BA;border-radius:5px;color:#222;border:1px
solid #8CA383}.notifyproblem,.notifysuccess,.paging{text-align:center}.tabtree{position:relative;margin-bottom:3.5em}.tabtree
.tabrow0{text-align:center;width:100%;margin:1em
0px}.tabtree .tabrow0
li{display:inline;margin-right:-4px}.tabtree .tabrow0 li.here
a{position:relative;z-index:102}.tabtree .tabrow0 li
a{background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/tab/left);padding-left:14px;padding-top:10px;background-repeat:no-repeat;padding-bottom:3px;margin-bottom:-1px}.tabtree .tabrow0 li a:hover{background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/tab/left_hover)}.tabtree .tabrow0 li a:hover
span{background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/tab/right_hover)}.tabtree .tabrow0 li a
span{background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/tab/right);background-repeat:no-repeat;background-position:100% 0%;padding-right:14px;padding-top:10px;padding-bottom:3px}.tabtree .tabrow0 ul,
.tabtree .tabrow0
div{background-image:url(/sunguru/theme/image.php/archaius/theme/1531975376/tab/tabrow1);background-position:0% 50%;position:absolute;width:100%;border-top:1px solid #aaa;padding:0.25em 0px;top:100%;margin:0px}.tabtree .tabrow0
.empty{height:1px;overflow:hidden;padding:0px;position:absolute}.tabtree .tabrow1 li a,
.tabtree .tabrow1 li a span,
.tabtree .tabrow1 li a:hover,
.tabtree .tabrow1 li a:hover
span{background-image:none}.groupmanagementtable{width:90%}.groupmanagementtable
td{vertical-align:top;border-width:0px}.groupmanagementtable td
p{margin:0px}#page-admin-theme-index
.generalbox{border:0
none;background:none}.theme_screenshot{float:left;width:300px}.theme_screenshot
img{width:275px}.theme_screenshot
h2{font-size:2em;margin-top:0}.theme_screenshot
h3{font-size:0.9em;margin:1em
0 0}.theme_screenshot
p{font-size:0.9em;margin:0
0 1em}.theme_description{margin-left:300px}.theme_description
h2{padding-top:0.5em}@-ms-viewport{width:device-width}@font-face{font-family:'OpenSans';src:url(/sunguru/theme/font.php/archaius/theme/1531975376/OpenSans-Regular.ttf);font-weight:normal;font-style:normal}@font-face{font-family:'OpenSans';src:url(/sunguru/theme/font.php/archaius/theme/1531975376/OpenSans-Bold.ttf);font-weight:bold;font-style:normal}html,body{font-family:'OpenSans';color:#222;background:#FFF7F4;height:100%}a{color:#08C}a:link,a:visited{color:#08C}a:hover{text-decoration:underline}h3.page-subtitle{margin:10px
0px 10px 10px}span.error{color:red}input[type=text],input[type=password],textarea{max-width:100%;margin-bottom:10px}#page-header{top:0;background:#FFF7F4;color:#000;width:100%;float:none;margin-bottom:0px;//Jack-gap between top menu and slideshow
overflow: auto}#page-header a:link,
#page-header a:visited{color:blue}#page-header
h1.headermain{color:#000;font-weight:bold;font-size:2em;margin:2px}#page-header div.menu-icon{cursor:pointer;width:35px;height:35px;float:right;margin:2px
0px;padding:0;z-index:999;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:none}#page-header div.menu-icon.active{background:#FFF7F4}#page-header div.menu-icon.deactive{background:#FFF7F4}#page-header div.menu-icon .icon-bar{display:block;width:37px;margin:5px
auto;height:7px;background-color:#FFF7F4}#page-header .page-header-inner{margin:0
auto;padding-top:10px;max-width:1200px;min-height:110px;width:90%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}#logo,#mobile-logo{width:45%;height:100%;float:left;max-height:150px;cursor:pointer;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}#logo img,
#mobile-logo
img{max-height:70px;margin:0px
0px 0px 10px;cursor:pointer;height:auto;width:auto}#mobile-logo{display:none}.page-header-info-container{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;float:left;width:48%;color:#000}div.top-inner{margin:0
auto;padding-top:10px;max-width:1200px;min-height:110px}div.top-inner
div.langmenu{float:right;width:60%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:0px
10px;text-align:right}.headermenu{margin-top:1px;margin-right:0;float:right;width:100%}.navbar{margin:10px
10px 0px 0;padding:5px;background:whitesmoke;border:1px
solid #ccc}.navbar ul[role="navigation"] a{font-weight:bold;padding:5px;color:#222}img.icon{display:block}div.singlebutton{padding:5px}.navbutton input[type="submit"]{padding:0px
3px}table
tr{border:1px
solid #efefef;padding:5px}table tr:nth-child(odd) td{background-color:#f5f5f5}table tr:nth-child(even) td{background-color:white}#page-content{min-height:500px;min-width:0px}.page-content.report-page{overflow-x:hidden;margin-top:20px}.report-page .main-report-content{width:75%;float:right;margin-bottom:20px}.report-page .main-report-content.initial-left-region-hidden{width:100%}.report-page #report-region-pre{width:23%;float:left;max-width:200px}.report-page #report-region-pre.initial-hidden-region{margin-left:-220px}.block{border:none}.block
.content{background:#f5f5f5;padding:5px
10px;border:none;-webkit-border-radius:0px 0px 5px 5px;-moz-border-radius:0px 0px 5px 5px;-ms-border-radius:0px 0px 5px 5px;-o-border-radius:0px 0px 5px 5px;border-radius:0px 0px 5px 5px}.block .content
select{width:150px;background:transparent}.block .content
a{color:#222}#page-content #region-main div.header-tab{background:none repeat scroll 0 0 #FFF7F4;color:#f5f5f5;line-height:1;border-bottom:1px solid #FFF7F4;min-height:20px;-webkit-border-radius:5px;-moz-border-radius:5px;-ms-border-radius:5px;-o-border-radius:5px;border-radius:5px}#page-content #region-main div.header-tab
.commands{float:right;margin-top:-30px;margin-right:10px}#page-content #region-main .block
div.content{width:90%;margin:0
auto}#page-content #region-main
div.header{display:none}#page-content #region-main div.maincalendar div.heightcontainer
div.header{display:block}#page-content #region-main.initial-left-region-hidden{margin-left:0}#page-content #region-main.initial-left-region-hidden.not-hidden-right{margin-left:200px}#page-content #region-main.initial-right-region-hidden{margin-right:-200px}#page-content #region-main.initial-right-region-hidden.initial-left-region-hidden{margin-left:200px;margin-right:-200px}#page-content #region-pre.initial-hidden-region{left:-200px}#page-content #region-pre.initial-hidden-region.not-hidden-right,
#page-content #region-pre.initial-hidden-region.both{left:0}#page-content #region-post.initial-hidden-region{left:200px}div.region-content div.header-tab{background:none repeat scroll 0 0 #F90;line-height:1;border-bottom:1px solid whiteSmoke;cursor:pointer !important;min-height:20px;//jack-height of block headings
color: whiteSmoke}div.region-content .header-tab
.title{text-align:center}div.region-content .header-tab
h2{font-size:small;padding:5px}div.region-content div.header-tab
h2{cursor:pointer !important}#region-post div.region-content div.header-tab:first-child,
#report-region-pre div.region-content div.header-tab:first-child,
#region-pre div.region-content div.header-tab:first-child{-webkit-border-radius:5px 5px 0 0;-moz-border-radius:5px 5px 0 0;-ms-border-radius:5px 5px 0 0;-o-border-radius:5px 5px 0 0;border-radius:5px 5px 0 0}#region-post div.region-content .header h2,
#report-region-pre div.region-content .header h2,
#region-pre div.region-content .header
h2{display:none}#region-post div.region-content div.current,
#report-region-pre div.region-content div.current,
#region-pre div.region-content
div.current{background-color:#FF6823}#region-post div.region-content div.current h2,
#report-region-pre div.region-content div.current h2,
#region-pre div.region-content div.current
h2{color:whiteSmoke}#report-region-pre,
#region-post-box #region-pre,
#region-post-box #region-post{display:none}#report-region-pre.no-accordion,
#region-post-box #region-pre.no-accordion,
#region-post-box #region-post.no-accordion{display:block}#report-region-pre.no-accordion div.region-content div.header-tab,
#region-post-box #region-pre.no-accordion div.region-content div.header-tab,
#region-post-box #region-post.no-accordion div.region-content div.header-tab{-webkit-border-radius:5px 5px 0px 0px;-moz-border-radius:5px 5px 0px 0px;-ms-border-radius:5px 5px 0px 0px;-o-border-radius:5px 5px 0px 0px;border-radius:5px 5px 0px 0px}#report-region-pre.no-accordion div.region-content div.header-tab,
#region-post-box #region-pre.no-accordion div.region-content div.header-tab,
#region-post-box #region-post.no-accordion div.region-content div.header-tab,
#report-region-pre.no-accordion div.region-content div.header-tab h2,
#region-post-box #region-pre.no-accordion div.region-content div.header-tab h2,
#region-post-box #region-post.no-accordion div.region-content div.header-tab
h2{cursor:initial !important}#report-region-pre div.region-content .header,
#region-pre div.region-content .header,
#region-post div.region-content
.header{background-color:#f5f5f5;height:10px}#tabs-pre .block,
#tabs-post
.block{margin-bottom:0em}#tabs-pre .com,
#tabs-post
.com{text-align:center;background-color:#f5f5f5;border:1px
solid #ddd}#region-center-pre,#reion-center-post{clear:both;margin-bottom:20px}#regions-control{position:fixed;width:100%;z-index:0}#region-footer-left,#region-footer-center,#region-footer-right{float:left;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;width:33%;padding:20px}#region-footer-left .header-tab,
#region-footer-center .header-tab,
#region-footer-right .header-tab{display:none}#region-footer-left .menu-action,
#region-footer-center .menu-action,
#region-footer-right .menu-action{color:#222}#region-footer-left .content,
#region-footer-center .content,
#region-footer-right
.content{background-color:#FFF7F4;-webkit-border-radius:0px 0px 0px 0px;-moz-border-radius:0px 0px 0px 0px;-ms-border-radius:0px 0px 0px 0px;-o-border-radius:0px 0px 0px 0px;border-radius:0px 0px 0px 0px;text-align:left}#region-footer-left .block,
#region-footer-center .block,
#region-footer-right
.block{min-height:inherit}.move{background-color:#fff;cursor:pointer;height:40px;width:30px;margin:0px
10px 0 10px}#move-region-right{background:-10px url(/sunguru/theme/image.php/archaius/theme/1531975376/arrow_right);float:right}#move-region-right.hidden-region{background:-22px url(/sunguru/theme/image.php/archaius/theme/1531975376/arrow_left) !important}#move-region{background:-22px url(/sunguru/theme/image.php/archaius/theme/1531975376/arrow_left);float:left}#move-region.hidden-region{background:-10px url(/sunguru/theme/image.php/archaius/theme/1531975376/arrow_right) !important}.block_js_expansion
.block_tree{overflow:auto}.block_recent_activity h3.main,
.block_recent_activity
h2.main{font-size:1em;margin:0.5em 0}.block_calendar_month .content
h3.eventskey{font-size:1em;margin:0.25em 0}.block_action{border:none;background-color:#f5f5f5}.block_action
img{border:none}.block_action img.block-hider-hide{display:none}.minicalendar td,
.minicalendar
th{border-color:#f3f8ed}td.eventskey{padding:0
5px 3px}.block_comments
textarea{width:95%;margin-bottom:1em}.block_comments .comment-area
a{background:#fff;padding:5px;border:1px
solid #e5e5e5}.comment-delete-confirm{background:#fff}.block_messages
.content{font-size:0.95em}.block_messages
.footer{text-align:center}#searchforums{margin-left:10px}#region-main
.forumpost{border:none}#region-main .forumpost
div.header{background:#efefef !important;margin-bottom:5px;-webkit-box-shadow:1px 1px 2px 0px #888;-moz-box-shadow:1px 1px 2px 0px #888;box-shadow:1px 1px 2px 0px #888;display:block}.path-mod-forum
.forumheaderlist{border:1px
solid #ccc}.path-mod-forum .forumheaderlist
td{border:none}.path-mod-forum .forumheaderlist
.replies{text-align:center}.path-mod-forum .forumheaderlist .replies
.read{background:#fcffd8;padding:2px}.path-mod-forum .unread
.content{background:#f3f8ed}.forumpost{border:1px
dashed #ddd;padding:10px
10px}.forumpost
.starter{background:#efefef}.forumpost
.subject{font-size:1.2em;color:#222;margin-left:10px}.forumpost
.author{font-style:italic;color:#555;font-size:0.95em;margin-left:10px}.forumpost .author a:link,
.forumpost .author a:visited{text-decoration:underline}.forumpost .author a:hover{text-decoration:none}.forumpost .no-overflow,
.forumpost
.options{border:1px
solid #ccc;padding:5px
10px}.forumpost .content
.posting{padding:5px
10px}.forumaddnew,.forumnodiscuss{text-align:center;margin-bottom:15px}.path-course-view
.headingblock{text-align:center}.path-course-view .section .forum
.unread{margin-left:20px}.path-course-view .section .forum .unread a:visited,
.path-course-view .section .forum .unread a:link{color:#888;background:#fcffd8;font-size:small}.generalbox{border:none}#page-mod-forum-search
.generalbox{width:85%}#page-mod-forum-search
.searchbox{margin:25px
auto}#page-mod-forum-search .searchbox
.submit{padding-top:20px;text-align:center}#page-footer{padding-top:2px;background:#FFF7F4;color:#000;min-height:50px;width:100%}#page-footer
a{color:blue}#page-footer
.logininfo{margin:2px
auto 2px auto}#page-footer .sitelink,
#page-footer
.helplink{clear:both}#page-footer .sitelink
img{width:auto !important;height:auto !important}#page-footer #page-footer-bottom{text-align:center;margin:2px
10%}#page-mod-assignment-view
.singlebutton{margin:15px}#page-mod-assignment-view
#online{margin:10px
auto;width:90%}#page-mod-assignment-view #online fieldset
.fitem{width:100%}#page-mod-assignment-view #online fieldset .fitem
.fitemtitle{width:15%}.performanceinfo
span{display:block}.validators{margin-top:40px;padding-top:5px;border-top:1px dotted gray}.validators
ul{margin:0px;padding:0px;list-style-type:none}.validators ul
li{display:inline;margin-right:10px;margin-left:10px}.myclear{clear:both}#custommenu{background-color:#D62100;//Jack-maroon color
padding: 1px;min-height:36px}#custommenu ul,
#custommenu li,
#custommenu a,
#custommenu .yui3-menu-content{border:none !important}#custommenu .custommenu-inner{width:90%;margin:0
auto}#custommenu .custom_menu_submenu
li{border-right:0px;min-width:150px}#custommenu .custom_menu_submenu .yui3-menu-label-active,
#custommenu .custom_menu_submenu .yui3-menu-label-menuvisible{background-color:#028784}#custommenu .yui3-menu .yui3-menu .yui3-menuitem-active .yui3-menuitem-content,
#custommenu .yui3-menuitem-content:hover,
#custommenu .yui3-menu-label-menuvisible:hover{background-color:#028784}#custommenu .custom_menu_submenu .yui3-menu-content,
#custommenu .yui3-menu-label-active,
#custommenu .yui3-menu-label-menuvisible{background-color:#02786E}#custommenu .yui3-menu-horizontal .yui3-menu-content ul ul,
#custommenu .yui3-menu-horizontal.javascript-disabled .yui3-menu-content ul
ul{padding-bottom:3px}#custommenu .yui3-menu-horizontal .yui3-menu-content li
a{cursor:pointer;color:white;padding:10px}#custommenu .yui3-menu-horizontal .yui3-menu-content li.yui3-menuitem-active a,
#custommenu a.yui3-menu-label-active,
#custommenu a.yui3-menu-label-menuvisible{color:white !important}#custommenu .yui3-skin-sam .yui3-menu li,
#custommenu .yui3-skin-sam .yui3-menu .yui3-menu
li{background-color:#02786E !important}#custommenu
#custom_menu_1{max-width:1200px;width:100%;margin:0
auto}#custommenu.collapsed{display:none}#custommenu.stuck{position:fixed;top:0;width:100%;z-index:999}#custommenu div.custommenu-inner>div>div>ul:first-child>li:last-child{float:left;margin-right:0}.arrow{width:0;height:0;margin-top:3px}.arrow-right{width:0;height:0;margin-top:3px;border-top:8px solid transparent;border-bottom:8px solid transparent;border-left:10px solid #697F6F}.arrow-up{width:0;height:0;margin-top:3px;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:10px solid #697F6F;margin:auto}#mobile-custommenu{background-color:#FFF7F4;padding:10px;clear:both;display:none;border-top:1px solid #888}#mobile-custommenu
a{display:block;text-decoration:none;padding:5px
5px}#mobile-custommenu a:hover{background-color:#028784;border-bottom:1px solid #888;border-top:1px solid #888}#mobile-custommenu a .hierarchy-mark{height:20px;width:10px;display:inline-block}#mobile-custommenu a .parent-item{border-left:1px solid #f5f5f5;border-bottom:1px solid #f5f5f5;display:inline-block;margin-right:5px}#mobile-custommenu.collapsed{display:none}.loginbox{border:1px
solid #ccc}.loginbox.twocolumns{border:0;background-color:#f5f5f5}.loginbox.twocolumns
.loginpanel{border:0}.loginbox .loginform .form-input{margin-bottom:5px;text-align:center;width:auto;float:none}.loginbox .loginform .form-input
#loginbtn{display:block;text-align:center;margin:5px
auto 0px auto}.loginbox .loginform .form-label{text-align:center;float:none;width:auto}.loginerrors{width:40%;margin:0
auto}.loginerrors
img.icon{float:left}.que
div.formulation{background-color:#f5f5f5}#page-mod-quiz-attempt .submitbtns,
#page-mod-quiz-review
div.submitbtns{text-align:center}#page-mod-quiz-edit input[type="submit"]{margin:5px}#page-mod-quiz-edit .questionbankwindow
div.header{background-color:#FFF7F4 !important;text-align:center;cursor:pointer;display:block}#page-mod-quiz-edit .questionbankwindow div.header
h2{font-size:small}#page-mod-quiz-edit
div.questionbank{background-color:#f5f5f5}#page-mod-quiz-edit div.question div.content
div.points{border-left:none;background-color:#F9F9F9;top:0}#page-mod-quiz-edit div.editq div.question
div.content{padding-bottom:15px}#expand-bank{color:white}table.minicalendar.calendartable
tr{border:none}div.calendar-controls{background-color:#f5f5f5}.day.hasevent.calendar_event_global{background-color:#D6F8CD}.day.hasevent.calendar_event_user{background-color:#DCE7EC}.day.hasevent.calendar_event_course{background-color:#FFD3BD}.day.hasevent{background-color:#D5FC87}input[type="submit"],button,.pretty-button,.delete-slide{color:#fff;text-shadow:0 -1px 0 rgba(0, 0, 0, 0.25);background-color:#363636;background-repeat:repeat-x;border-color:#222 #222222 #000;border-color:rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);background-image:-moz-linear-gradient(top, #444444, #222222);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#444444), to(#222222));background-image:-webkit-linear-gradient(top, #444444, #222222);background-image:-o-linear-gradient(top, #444444, #222222);background-image:linear-gradient(to bottom,#444444,#222222);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff#444444',endColorstr='#ff#222222',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);padding:3px;-webkit-border-radius:4px;-moz-border-radius:4px;-ms-border-radius:4px;-o-border-radius:4px;border-radius:4px;cursor:pointer;word-wrap:break-word;max-width:100%}.btn-danger{color:#fff;text-shadow:0 -1px 0 rgba(0, 0, 0, 0.25);background-color:#da4f49;background-image:-moz-linear-gradient(top, #ee5f5b, #bd362f);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#ee5f5b), to(#bd362f));background-image:-webkit-linear-gradient(top, #ee5f5b, #bd362f);background-image:-o-linear-gradient(top, #ee5f5b, #bd362f);background-image:linear-gradient(to bottom, #ee5f5b, #bd362f);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff#ee5f5b',endColorstr='#ff#bd362f',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);background-repeat:repeat-x;border-color:#bd362f #bd362f #802420;border-color:rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0,0,0,0.25)}.btn-warning{color:#fff;text-shadow:0 -1px 0 rgba(0, 0, 0, 0.25);background-color:#faa732;background-image:-moz-linear-gradient(top, #fbb450, #f89406);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fbb450), to(#f89406));background-image:-webkit-linear-gradient(top, #fbb450, #f89406);background-image:-o-linear-gradient(top, #fbb450, #f89406);background-image:linear-gradient(to bottom, #fbb450, #f89406);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff#fbb450',endColorstr='#ff#f89406',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);background-repeat:repeat-x;border-color:#f89406 #f89406 #ad6704;border-color:rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0,0,0,0.25)}.btn{display:inline-block;padding:4px
12px;margin-bottom:0;line-height:20px;text-align:center;vertical-align:middle;cursor:pointer;-webkit-box-shadow:inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);-moz-box-shadow:inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);box-shadow:inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);-webkit-border-radius:4px;-moz-border-radius:4px;-ms-border-radius:4px;-o-border-radius:4px;border-radius:4px}#admindeviceselector
img{width:100%}@media screen and (max-width: 768px){input[type=text],input[type=password],textarea{width:95%}table{max-width:100%}table.generaltable{width:95%}table.generaltable thead,
table.generaltable tbody,
table.generaltable th,
table.generaltable td,
table.generaltable
tr{display:block}table.generaltable thead
tr{position:absolute;top:-9999px;left:-9999px}table.generaltable
tr{border:1px
solid #ccc}table.generaltable
td{border:none;border-bottom:1px solid #eee;position:relative}table.generaltable td:before{position:absolute;top:6px;left:6px;width:45%;padding-right:10px;white-space:nowrap}.main-content{width:95% !important}.main-content
img{max-width:100%}.navbar{margin-bottom:30px}#regions-control{display:none}#region-main-box,#region-main-wrap,#region-post-box,#region-main,#region-pre,#report-region-pre,#region-footer-left,#region-footer-center,#region-footer-right,#region-post,.generalbox{float:none !important;left:0 !important;right:0 !important;width:100% !important;margin:0
!important}.report-page #report-region-pre{max-width:none}#mobile-logo{margin-left:20px;display:block;width:30%}#mobile-logo
img.sitelogo{height:auto;max-width:80%}#logo{display:none}#page-header
.headermenu{clear:both;float:left;position:relative;background-color:#FFF7F4;margin:0;padding:0;z-index:999;top:0;right:0;min-height:40px;width:80%}#page-header #top-page-header{display:none}#page-header .page-header-inner{width:100%}#page-header
div.langmenu{padding-bottom:10px}#page-header
div.logininfo{margin-bottom:0;padding-bottom:10px;float:left;width:70%}#page-header #header-wrap{background-color:#FFF7F4}#page-header .page-header-info-container{padding-right:20px;width:60%;float:left}#page-header div.menu-icon{display:block}#page-header #social-icons{display:none}#adminsettings .form-item .form-label{width:100%;float:none;text-align:left}#adminsettings .form-item .form-setting,
#adminsettings .form-item .form-description{margin-left:0}.loginbox.twocolumns .loginpanel,
.loginbox.twocolumns
.signuppanel{float:none;width:100%}.loginbox.twocolumns
.signuppanel{border-top:1px solid #888}.coursebox > .info > .coursename,
.coursebox .content .teachers,
.coursebox .content .courseimage,
.coursebox .content
.coursefile{float:none !important;width:100% !important}.coursebox .content
.summary{width:95% !important;border-left:0 !important}.questionbankwindow.block,
#page-mod-quiz-edit
div.quizcontents{float:none;width:100%;clear:both}.editq{min-height:100px;margin-bottom:20px}.page-content.report-page{overflow-x:visible}.page-content.report-page .main-report-content{width:100%;float:none}.page-content.report-page table#user-grades{width:100%}.tabtree .tabrow0
li{display:block;margin:5px;float:left}}html.no-media-queries{}html.no-media-queries input[type=text],
html.no-media-queries input[type=password],
html.no-media-queries
textarea{width:95%}html.no-media-queries
table{max-width:100%}html.no-media-queries
table.generaltable{width:95%}html.no-media-queries table.generaltable thead,
html.no-media-queries table.generaltable tbody,
html.no-media-queries table.generaltable th,
html.no-media-queries table.generaltable td,
html.no-media-queries table.generaltable
tr{display:block}html.no-media-queries table.generaltable thead
tr{position:absolute;top:-9999px;left:-9999px}html.no-media-queries table.generaltable
tr{border:1px
solid #ccc}html.no-media-queries table.generaltable
td{border:none;border-bottom:1px solid #eee;position:relative}html.no-media-queries table.generaltable td:before{position:absolute;top:6px;left:6px;width:45%;padding-right:10px;white-space:nowrap}html.no-media-queries .main-content{width:95% !important}html.no-media-queries .main-content
img{max-width:100%}html.no-media-queries
.navbar{margin-bottom:30px}html.no-media-queries #regions-control{display:none}html.no-media-queries #region-main-box,
html.no-media-queries #region-main-wrap,
html.no-media-queries #region-post-box,
html.no-media-queries #region-main,
html.no-media-queries #region-pre,
html.no-media-queries #report-region-pre,
html.no-media-queries #region-footer-left,
html.no-media-queries #region-footer-center,
html.no-media-queries #region-footer-right,
html.no-media-queries #region-post,
html.no-media-queries
.generalbox{float:none !important;left:0 !important;right:0 !important;width:100% !important;margin:0
!important}html.no-media-queries .report-page #report-region-pre{max-width:none}html.no-media-queries #mobile-logo{margin-left:20px;display:block;width:30%}html.no-media-queries #mobile-logo
img.sitelogo{height:auto;max-width:80%}html.no-media-queries
#logo{display:none}html.no-media-queries #page-header
.headermenu{clear:both;float:left;position:relative;background-color:#FFF7F4;margin:0;padding:0;z-index:999;top:0;right:0;min-height:40px;width:80%}html.no-media-queries #page-header #top-page-header{display:none}html.no-media-queries #page-header .page-header-inner{width:100%}html.no-media-queries #page-header
div.langmenu{padding-bottom:10px}html.no-media-queries #page-header
div.logininfo{margin-bottom:0;padding-bottom:10px;float:left;width:70%}html.no-media-queries #page-header #header-wrap{background-color:#FFF7F4}html.no-media-queries #page-header .page-header-info-container{padding-right:20px;width:60%;float:left}html.no-media-queries #page-header div.menu-icon{display:block}html.no-media-queries #page-header #social-icons{display:none}html.no-media-queries #adminsettings .form-item .form-label{width:100%;float:none;text-align:left}html.no-media-queries #adminsettings .form-item .form-setting,
html.no-media-queries #adminsettings .form-item .form-description{margin-left:0}html.no-media-queries .loginbox.twocolumns .loginpanel,
html.no-media-queries .loginbox.twocolumns
.signuppanel{float:none;width:100%}html.no-media-queries .loginbox.twocolumns
.signuppanel{border-top:1px solid #888}html.no-media-queries .coursebox > .info > .coursename,
html.no-media-queries .coursebox .content .teachers,
html.no-media-queries .coursebox .content .courseimage,
html.no-media-queries .coursebox .content
.coursefile{float:none !important;width:100% !important}html.no-media-queries .coursebox .content
.summary{width:95% !important;border-left:0 !important}html.no-media-queries .questionbankwindow.block,
html.no-media-queries #page-mod-quiz-edit
div.quizcontents{float:none;width:100%;clear:both}html.no-media-queries
.editq{min-height:100px;margin-bottom:20px}html.no-media-queries .page-content.report-page{overflow-x:visible}html.no-media-queries .page-content.report-page .main-report-content{width:100%;float:none}html.no-media-queries .page-content.report-page table#user-grades{width:100%}html.no-media-queries .tabtree .tabrow0
li{display:block;margin:5px;float:left}#page-course-category
.categorypicker{text-align:center;margin:10px
0 20px}.coursebox{width:auto;margin-bottom:15px;background-color:#f5f5f5;padding:20px}.coursebox
.info{width:100%}.coursebox .info
.name{width:100%}.coursebox .content
.teachers{margin-left:0.6em;font-size:0.95em;width:40%;float:left}.coursebox .content
.summary{width:50%;padding-left:10px;border-left:1px solid #ddd}.coursebox .content .summary .summary-title{margin-left:15px}.coursebox .content .summary .summary-title
p{color:#808080}.coursebox .content .summary .summary-title
span{color:#444;font-size:1.75em}.path-course-view .topics .topic-tab{border-bottom:1px solid #ccc;margin-bottom:10px;padding-top:10px;cursor:pointer;height:40px}.path-course-view .topics .topic-tab.current{background-color:whitesmoke;border:1px
solid #ccc}.path-course-view .topics .topic-tab.hidden{opacity:0.5}.categorybox{border:none}h2.headingblock{font-size:1.5em}.path-course-view .course-content ul.topics
li.section.main{background-color:#fff;display:none;padding-top:5px;list-style-type:none;margin-top:0;border:1px
dashed #ddd;border-top:0}.path-course-view .course-content ul.topics li.section.main
.side{padding:5px
0}.path-course-view .course-content ul.topics li.section.main ul
li{clear:both}.path-course-view .course-content ul.topics li.section.main
.sectionname.hidden{display:none}.path-course-view .course-content
.main{background:#f3f8ed}.path-course-view .course-content
.current{background-color:#fff}.path-course-view .course-content
.activity.label.modtype_label{margin:5px
auto}.path-course-view .course-content ul.topics li.section
.content{margin:0
10px}.path-course-view .course-content ul.weeks
li.section{border:1px
solid #ddd;padding:10px;background-color:#fff}.path-course-view .course-content ul.weeks
li.section.current{background-color:#f5f5f5}.path-course-view .course-content ul.weeks
li.section.main{display:block}#page-course-view-weeks
.weekdates{font-size:1em;font-weight:normal;color:#777;padding:2px}.triangle{width:0;height:0;border-top:5px solid transparent;border-left:7px solid #999;border-bottom:5px solid transparent;border-right:0;float:left;margin-right:5px;margin-top:5px;margin-left:5px}.current
.triangle{width:0;height:0;border-top:7px solid #999;border-left:5px solid transparent;border-bottom:0;border-right:5px solid transparent;float:left;margin-right:5px;margin-top:8px}.path-grade-report-grader
.gradeparent{overflow:scroll}#home-page{margin-bottom:20px;height:auto}#toggle-admin-menu{text-align:center;margin-top:10px;clear:both}.pretty-link-button{color:white !important;text-decoration:none !important;margin-bottom:10px}.admin-options{display:none;text-align:center}.admin-options tr,
.admin-options td,
.admin-options
th{border:1px
dashed #888}.admin-options table
img{max-width:100px;height:auto}h2.lonely-title{text-align:center;padding-bottom:10px;border-bottom:1px solid #ddd}#home-content{width:100%;height:310px}#content-left{float:left;width:60%}#site-description{float:right;width:40%}.delete-slide{margin-left:5px}.main-control{padding:10px;text-align:center}.main-control
a{margin-right:5px}.notice{color:#51a351;text-align:center}.rslides{margin:0
auto}.rslides
li{list-style:none;overflow:hidden;width:100%;height:246px}.rslides li
p{max-width:100%}.rslides li
img{width:auto;height:auto;max-width:100%;max-height:100%}.rslides_container{position:relative;width:100%;height:auto;visibility:hidden}.rslides_container.ready{visibility:visible}.centered-btns_nav:active{opacity:1.0}.centered-btns_nav.next{left:auto;background-position:right top;right:0}.large-btns_nav{z-index:3;position:absolute;-webkit-tap-highlight-color:rgba(0, 0, 0, 0);opacity:0.6;text-indent:-9999px;overflow:hidden;top:40%;bottom:0;left:0;background:#000 url(/sunguru/theme/image.php/archaius/theme/1531975376/slideshow/themes) no-repeat left 50%;width:38px;height:61px}.large-btns_nav:active{opacity:1.0}.large-btns_nav.next{left:auto;background-position:right 50%;right:0}.centered-btns_tabs,.transparent-btns_tabs,.large-btns_tabs{margin-top:10px;text-align:center;clear:both}.centered-btns_tabs:focus,.transparent-btns_tabs:focus,.large-btns_tabs:focus{outline:none}.centered-btns_tabs li,
.transparent-btns_tabs li,
.large-btns_tabs
li{display:inline;float:none;_float:left;*float:left;margin-right:5px}.centered-btns_tabs a,
.transparent-btns_tabs a,
.large-btns_tabs
a{text-indent:-9999px;overflow:hidden;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px;background:#ccc;background:rgba(0, 0, 0, 0.2);display:inline-block;_display:block;*display:block;-webkit-box-shadow:inset 0 0 2px 0 rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0 0 2px 0 rgba(0, 0, 0, 0.3);box-shadow:inset 0 0 2px 0 rgba(0, 0, 0, 0.3);width:9px;height:9px}.centered-btns_here a,
.transparent-btns_here a,
.large-btns_here
a{background:#222;background:rgba(0,0,0,0.8)}#button-pause-play.paused{background:transparent url(/sunguru/theme/image.php/archaius/theme/1531975376/slideshow/play)}#button-pause-play{background:transparent url(/sunguru/theme/image.php/archaius/theme/1531975376/slideshow/pause);width:16px;height:16px;margin:0
auto;cursor:pointer;clear:both}html,body,div,span,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,code,del,dfn,em,img,q,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td{margin:0;padding:0;border:0;font-weight:inherit;font-style:inherit;font-size:100%;font-family:inherit;vertical-align:baseline}body{line-height:1.5;margin:0}iframe{max-width:100%}caption,th,td{text-align:left;font-weight:400}blockquote:before,blockquote:after,q:before,q:after{content:""}blockquote,q{quotes:"" ""}a
img{border:none}input,textarea{margin:0}a{outline:none}.wrapper{display:inline-block}.wrapper:after{content:".";display:block;height:0;clear:both;visibility:hidden}* html
.wrapper{height:1%}.wrapper{display:block}body{font-size:85%}@font-face{font-family:'OpenSans';src:url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Regular.ttf) format('truetype'),
url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Regular.woff) format('woff'),
url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Regular.eot) format('embedded-opentype') ,
url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Regular.svg) format('svg');font-weight:normal;font-style:normal}@font-face{font-family:'OpenSans';src:url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Semibold.ttf) format('truetype'),
url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Semibold.woff) format('woff'),
url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Semibold.eot) format('embedded-opentype') ,
url(http://sunguru.suntecsbs.com/sunguru/theme/archaius/fonts/OpenSans-Semibold.svg) format('svg');font-weight:bold;font-style:normal}body,h1,h2,h3,h4,h5,h6,p,ul,ol,dl,input,textarea{font-family:'OpenSans',Helvetica,Arial,sans-serif}h1,h2,h3,h4,h5,h6{font-weight:normal;margin:0
0 20px 0}h1{font-size:2.25em;line-height:1;margin-bottom:0.5em}h2{font-size:1.75em;margin-bottom:0.5em}h3{font-size:1.5em;line-height:1;margin-bottom:1em}h4{font-size:1.2em;line-height:1.25;margin-bottom:0em;margin-top:1em}h5{font-size:1em;margin-bottom:1.5em}h6{font-size:1em}p{margin:0
0 1em}ul,ol{margin:0
1.5em 1.5em 1.5em}ul{list-style-type:circle}ol{list-style-type:decimal}dl{margin:0
0 1.5em 0}dl
dt{font-weight:bold}dl
dd{margin-left:1.5em}abbr,acronym{border-bottom:1px dotted #000}address{margin-top:1.5em;font-style:italic}del{color:#000}a{color:#009;text-decoration:none}a:hover{text-decoration:underline}blockquote{margin:1.5em}strong{font-weight:bold}em,dfn{font-style:italic}dfn{font-weight:bold}pre,code{margin:1.5em 0;white-space:pre}pre,code,tt{font:1.2em monospace;line-height:1.5}tt{display:block;margin:1.5em 0;line-height:1.5}table{border-collapse:collapse;border-spacing:0}th{border-bottom:2px solid #ddd;font-weight:bold}th,td{padding:4px;vertical-align:middle}tfoot{font-style:italic}caption{background:#ffc}.small{font-size: .8em;margin-bottom:1.875em;line-height:1.875em}.large{font-size:1.25em;line-height:1.5em;margin-bottom:1em}.quiet{color:#999}.hide{display:none}.highlight{background:#ffc}.top{margin-top:0;padding-top:0}.bottom{margin-bottom:0;padding-bottom:0}label{font-weight:bold}fieldset{padding:1.4em;margin:0
0 1.5em 0;border:1px
solid #ddd}legend{padding:0
.4em;font-weight:bold;font-size:1.2em}textarea{margin:0.5em 0.5em 0 0}textarea{padding: .4em}form.hform
p{margin:0
0 .5em}form.hform p
label{float:left;width:100px}form.hform p
input{width:200px}form.hform p
select{width:200px}form.hform p
input.button{width:auto}form.hform p
input.checkbox{width:auto}form.hform p
input.radio{width:auto}form.hform
p.checkbox{margin-left:100px}form.hform p.checkbox
label{float:none}form.hform p.checkbox
input{width:auto}form.vform
p{margin:0
0 .5em}form.vform p
label{display:block}form.vform p.checkbox
label{display:inline}